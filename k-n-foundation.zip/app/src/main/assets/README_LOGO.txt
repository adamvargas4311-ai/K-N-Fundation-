# APP LOGO & BRANDING ASSET PLACEHOLDER
Place your custom logo file here as `logo.png` (path: `assets/logo.png`).
The app is configured to load and prioritize `assets/logo.png` whenever present, without any overwrite by AI.
