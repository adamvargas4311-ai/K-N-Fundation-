package com.example.model

import com.google.firebase.firestore.PropertyName

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val photoURL: String = "",
    val organizationId: String = "kn_foundation",
    val role: String = "member", // member, admin, super_admin
    val permissions: List<String> = emptyList(),
    val status: String = "active", // active, inactive
    val totalCapitalContributed: Double = 0.0,
    val currentCapitalBalance: Double = 0.0,
    val profitSharePercentage: Double = 0.0,
    val joiningDate: String = "",
    val address: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    fun isAdmin(): Boolean = role == "admin" || role == "super_admin"
    fun isSuperAdmin(): Boolean = role == "super_admin"
    fun hasPermission(perm: String): Boolean = isSuperAdmin() || permissions.contains(perm)
}

data class CapitalContribution(
    val id: String = "",
    val memberId: String = "",
    val memberName: String = "",
    val memberPhone: String = "",
    val expectedAmount: Double = 0.0,
    val paidAmount: Double = 0.0,
    val dueAmount: Double = 0.0,
    val monthYear: String = "", // e.g. "সেপ্টেম্বর ২০২৬" or "2026-09"
    val paymentDate: String = "",
    val paymentMethod: String = "নগদ (Cash)", // নগদ, ব্যাংক, বিকাশ, নগদ অ্যাপ, রকেট
    val transactionId: String = "", // Bkash / Nagad / Rocket Trx ID
    val senderNumber: String = "", // Sender payment number
    val transactionNote: String = "",
    val organizationId: String = "kn_foundation",
    val status: String = "অনুমোদিত", // অনুমোদিত (Approved), প্রক্রিয়াধীন (Pending), বাতিল (Rejected)
    val approvedBy: String = "",
    val approvedAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

data class BusinessProject(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val category: String = "ব্যবসা", // ব্যবসা, ট্রেডিং, উৎপাদন, আমদানি-রপ্তানি, কৃষি, সেবা
    val imageUrl: String = "",
    val startDate: String = "",
    val location: String = "",
    val totalInvestment: Double = 0.0,
    val expectedProfit: Double = 0.0,
    val actualProfitLoss: Double = 0.0,
    val status: String = "চলমান", // চলমান (Ongoing), সম্পন্ন (Completed), বাতিল (Cancelled)
    val participants: List<String> = emptyList(),
    val organizationId: String = "kn_foundation",
    val createdAt: Long = System.currentTimeMillis()
)

data class OrganizationExpense(
    val id: String = "",
    val title: String = "",
    val category: String = "সাধারণ খরচ", // সাধারণ খরচ, প্রকল্প খরচ, অফিস ভাড়া, যাতায়াত, বিবিধ
    val amount: Double = 0.0,
    val date: String = "",
    val spentBy: String = "",
    val projectId: String = "",
    val receiptUrl: String = "",
    val note: String = "",
    val organizationId: String = "kn_foundation",
    val createdAt: Long = System.currentTimeMillis()
)

data class ProfitDistribution(
    val id: String = "",
    val title: String = "",
    val projectId: String = "",
    val projectName: String = "",
    val totalProfitAmount: Double = 0.0,
    val distributionDate: String = "",
    val memberShares: Map<String, Double> = emptyMap(), // memberUid -> amount
    val status: String = "সম্পন্ন", // খসড়া, সম্পন্ন
    val note: String = "",
    val organizationId: String = "kn_foundation",
    val createdAt: Long = System.currentTimeMillis()
)

data class NoticeItem(
    val id: String = "",
    val title: String = "",
    val content: String = "",
    val type: String = "নোটিশ", // নোটিশ, ঘোষণা, মিটিং, ইভেন্ট, প্রকল্প আপডেট
    val priority: String = "সাধারণ", // সাধারণ, জরুরি
    val date: String = "",
    val eventDate: String = "",
    val authorName: String = "",
    val organizationId: String = "kn_foundation",
    val createdAt: Long = System.currentTimeMillis()
)

data class ChatMessage(
    val id: String = "",
    val conversationId: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val text: String = "",
    val imageUrl: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val seen: Boolean = false
)

data class ConversationItem(
    val id: String = "",
    val participantIds: List<String> = emptyList(),
    val participantNames: Map<String, String> = emptyMap(),
    val participantPhotos: Map<String, String> = emptyMap(),
    val lastMessage: String = "",
    val lastTimestamp: Long = System.currentTimeMillis(),
    val unreadCount: Map<String, Int> = emptyMap()
)

data class AppNotification(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val body: String = "",
    val type: String = "সাধারণ", // message, notice, capital, profit, project
    val relatedId: String = "",
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis(),
    val organizationId: String = "kn_foundation"
)

data class FinancialOverview(
    val totalCapitalCollected: Double = 0.0,
    val extraFunds: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val currentBalance: Double = 0.0,
    val monthlyCapitalCollection: Double = 0.0,
    val monthlyExpenses: Double = 0.0,
    val currentMonthProfit: Double = 0.0, // 3. "Current Month's Total Profit" (চলতি মাসের মোট মুনাফা)
    val totalProfitDistributed: Double = 0.0,
    val totalMembers: Int = 0,
    val activeMembers: Int = 0,
    val ongoingProjectsCount: Int = 0,
    val completedProjectsCount: Int = 0,
    val lastUpdatedBy: String = "",
    val lastUpdatedAt: Long = 0L
)

data class PaymentSettings(
    val id: String = "payment_settings",
    val organizationId: String = "kn_foundation",
    val bkashNumber: String = "01950-515296",
    val isBkashActive: Boolean = true,
    val bkashActive: Boolean = isBkashActive,
    val bkashType: String = "Personal (ব্যক্তিগত)",
    val bkashInstruction: String = "বিকাশ অ্যাপ বা *247# ডায়াল করে Send Money করুন এবং Transaction ID সাবমিট করুন।",
    val bkashNote: String = bkashInstruction,

    val nagadNumber: String = "",
    val isNagadActive: Boolean = false,
    val nagadActive: Boolean = isNagadActive,
    val nagadType: String = "Personal (ব্যক্তিগত)",
    val nagadInstruction: String = "নগদ অ্যাপ বা *167# ডায়াল করে Send Money করুন এবং Transaction ID সাবমিট করুন।",
    val nagadNote: String = nagadInstruction,

    val rocketNumber: String = "",
    val isRocketActive: Boolean = false,
    val rocketActive: Boolean = isRocketActive,
    val rocketType: String = "Personal (ব্যক্তিগত)",
    val rocketInstruction: String = "রকেট অ্যাপ বা *322# ডায়াল করে Send Money করুন এবং Transaction ID সাবমিট করুন।",
    val rocketNote: String = rocketInstruction,

    val generalInstruction: String = "বিকাশ, নগদ বা রকেট অ্যাকাউন্টে টাকা পাঠিয়ে নিচের ফর্মে ট্রানজেকশন আইডি (TrxID) ও প্রেরক মোবাইল নম্বর সাবমিট করুন। অ্যাডমিন যাচাই করে তা অনুমোদন করবেন।",
    val lastUpdated: String = "",
    val updatedAt: Long = System.currentTimeMillis(),
    val updatedBy: String = ""
)

data class PollOption(
    val id: String = "",
    val text: String = "",
    val voteCount: Int = 0
)

data class VotingPoll(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val imageUrl: String = "",
    val options: List<PollOption> = listOf(
        PollOption("opt_1", "হ্যাঁ (Yes)", 0),
        PollOption("opt_2", "না (No)", 0)
    ),
    val votes: Map<String, String> = emptyMap(), // memberUid -> optionId
    val voterNames: Map<String, String> = emptyMap(), // memberUid -> memberName
    val deadlineTimestamp: Long = System.currentTimeMillis() + 86400000L * 3, // 3 days default
    val isClosedManually: Boolean = false,
    val authorId: String = "",
    val authorName: String = "",
    val organizationId: String = "kn_foundation",
    val createdAt: Long = System.currentTimeMillis()
) {
    fun isExpired(): Boolean = System.currentTimeMillis() >= deadlineTimestamp
    fun isVotingActive(): Boolean = !isClosedManually && !isExpired()
    fun hasVoted(userId: String): Boolean = votes.containsKey(userId)
    fun totalVotes(): Int = votes.size
    fun getUserVotedOptionId(userId: String): String? = votes[userId]
    fun getOptionVoteCount(optionId: String): Int = votes.values.count { it == optionId }
    fun getOptionPercentage(optionId: String): Int {
        val total = totalVotes()
        if (total == 0) return 0
        val count = getOptionVoteCount(optionId)
        return ((count.toDouble() / total) * 100).toInt()
    }
}

