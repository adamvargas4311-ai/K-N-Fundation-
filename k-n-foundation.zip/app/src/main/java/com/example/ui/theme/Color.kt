package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val IslamicGreen = Color(0xFF0C5A30)
val IslamicGreenDark = Color(0xFF083D20)
val IslamicGreenLight = Color(0xFF1E824C)
val IslamicGreenContainer = Color(0xFFE8F5E9)

val IslamicGold = Color(0xFFC59B27)
val IslamicGoldLight = Color(0xFFDFB748)
val IslamicGoldDark = Color(0xFF997517)
val IslamicGoldContainer = Color(0xFFFFF8E1)

val BackgroundLight = Color(0xFFFFFFFF)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceCard = Color(0xFFFFFFFF)
val BorderSubtle = Color(0xFFE2EBE5)

val TextPrimary = Color(0xFF14241B)
val TextSecondary = Color(0xFF4A5D52)
val TextMuted = Color(0xFF7D9085)

val SuccessGreen = Color(0xFF10B981)
val ErrorRed = Color(0xFFDC2626)
val PendingAmber = Color(0xFFF59E0B)
