package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.MainViewModel
import com.example.ui.components.OrganizationHeaderBar
import com.example.ui.theme.*

enum class DashboardTab(
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    HOME("হোম", Icons.Default.Home, Icons.Outlined.Home),
    CAPITAL("মূলধন", Icons.Default.Savings, Icons.Outlined.Savings),
    PROJECTS("প্রকল্প", Icons.Default.BusinessCenter, Icons.Outlined.BusinessCenter),
    NOTICES("নোটিশ", Icons.Default.Campaign, Icons.Outlined.Campaign),
    PROFILE("প্রোফাইল", Icons.Default.Person, Icons.Outlined.Person)
}

@Composable
fun MainDashboardScreen(
    viewModel: MainViewModel,
    onNavigateToAdmin: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onNavigateToChat: () -> Unit,
    onNavigateToAuth: () -> Unit,
    onSignOut: () -> Unit
) {
    var currentTab by remember { mutableStateOf(DashboardTab.HOME) }
    var showLogoDialog by remember { mutableStateOf(false) }
    val unreadNotificationsCount by viewModel.unreadNotificationsCount.collectAsState()
    val currentUser by viewModel.currentUserProfile.collectAsState()
    val isGuest = currentUser == null

    if (showLogoDialog) {
        com.example.ui.components.FullscreenLogoDialog(
            onDismiss = { showLogoDialog = false }
        )
    }

    Scaffold(
        topBar = {
            OrganizationHeaderBar(
                onNotificationsClick = onNavigateToNotifications,
                onMessagesClick = onNavigateToChat,
                unreadNotificationsCount = unreadNotificationsCount,
                isGuest = isGuest,
                onAuthClick = onNavigateToAuth,
                onLogoClick = { showLogoDialog = true }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                DashboardTab.values().forEach { tab ->
                    val isSelected = currentTab == tab
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentTab = tab },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                contentDescription = tab.title,
                                tint = if (isSelected) IslamicGreen else TextSecondary
                            )
                        },
                        label = {
                            Text(
                                text = tab.title,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) IslamicGreen else TextSecondary,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = IslamicGreenContainer
                        ),
                        modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                DashboardTab.HOME -> {
                    HomeScreen(
                        viewModel = viewModel,
                        onNavigateToCapital = { currentTab = DashboardTab.CAPITAL },
                        onNavigateToProjects = { currentTab = DashboardTab.PROJECTS },
                        onNavigateToNotices = { currentTab = DashboardTab.NOTICES },
                        onNavigateToAdminDashboard = onNavigateToAdmin,
                        onNavigateToAuth = onNavigateToAuth
                    )
                }
                DashboardTab.CAPITAL -> {
                    CapitalScreen(viewModel = viewModel)
                }
                DashboardTab.PROJECTS -> {
                    ProjectsScreen(viewModel = viewModel)
                }
                DashboardTab.NOTICES -> {
                    NoticesScreen(viewModel = viewModel)
                }
                DashboardTab.PROFILE -> {
                    ProfileScreen(
                        viewModel = viewModel,
                        onSignOut = onSignOut,
                        onNavigateToAuth = onNavigateToAuth
                    )
                }
            }
        }
    }
}
