package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.example.data.PdfReportGenerator
import com.example.model.CapitalContribution
import com.example.model.UserProfile
import com.example.ui.MainViewModel
import com.example.ui.components.AdminEditFinancialDialog
import com.example.ui.components.EmbossedButton
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateView
import com.example.ui.components.MemberDepositDialog
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CapitalScreen(
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    val myContributions by viewModel.myCapitalContributions.collectAsState()
    val allContributions by viewModel.allCapitalContributions.collectAsState()
    val overview by viewModel.financialOverview.collectAsState()
    val currentUser by viewModel.currentUserProfile.collectAsState()
    val membersList by viewModel.members.collectAsState()
    val paymentSettings by viewModel.paymentSettings.collectAsState()
    val projectsList by viewModel.projects.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = My, 1 = All, 2 = Summary, 3 = Share Tracker
    var showAddDialog by remember { mutableStateOf(false) }
    var showMemberDepositDialog by remember { mutableStateOf(false) }
    var showEditFinancialDialog by remember { mutableStateOf(false) }

    val currencyFormatter = remember { NumberFormat.getNumberInstance(Locale.US) }
    val isAdmin = currentUser?.isAdmin() == true

    Scaffold(
        floatingActionButton = {
            if (isAdmin) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = IslamicGreen,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_capital_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "মূলধন জমা এন্ট্রি")
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Tab Header
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IslamicGreen,
                edgePadding = 16.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("আমার জমাদান", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("সকলের জমাদান", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("আর্থিক সারসংক্ষেপ", fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("সদস্য শেয়ার ট্র্যাকার", fontWeight = if (selectedTab == 3) FontWeight.Bold else FontWeight.Normal) }
                )
            }

            when (selectedTab) {
                0 -> {
                    // My Contributions
                    val totalMyPaid = myContributions.filter { it.status == "অনুমোদিত" }.sumOf { it.paidAmount }
                    val totalPending = myContributions.filter { it.status == "প্রক্রিয়াধীন" }.sumOf { it.paidAmount }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            EmbossedCard(
                                modifier = Modifier.fillMaxWidth(),
                                backgroundColor = IslamicGreenContainer.copy(alpha = 0.6f)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(
                                                text = "আমার মোট অনুমোদিত মূলধন",
                                                fontSize = 12.sp,
                                                color = IslamicGreenDark,
                                                fontWeight = FontWeight.Medium
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "৳ ${currencyFormatter.format(totalMyPaid.toInt())}",
                                                fontSize = 24.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = IslamicGreenDark
                                            )
                                        }
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = MaterialTheme.colorScheme.surface
                                        ) {
                                            Text(
                                                text = "${myContributions.size} বার জমাদান",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = IslamicGreen,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            )
                                        }
                                    }

                                    if (totalPending > 0) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = Color(0xFFFFF3E0),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text = "অ্যাডমিন অনুমোদনের অপেক্ষায়: ৳ ${currencyFormatter.format(totalPending.toInt())}",
                                                fontSize = 11.sp,
                                                color = Color(0xFFE65100),
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                            )
                                        }
                                    }

                                    // Deposit Button for Members
                                    Button(
                                        onClick = { showMemberDepositDialog = true },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Send, contentDescription = "টাকা জমা দিন")
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("টাকা জমা দিন (বিকাশ / নগদ / রকেট)", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        if (myContributions.isEmpty()) {
                            item {
                                EmptyStateView(
                                    icon = Icons.Outlined.Savings,
                                    title = "কোনো মূলধন জমাদানের তথ্য পাওয়া যায়নি",
                                    subtitle = "আপনার নামে এখনো কোনো মূলধন জমা এন্ট্রি করা হয়নি। প্রশাসন হতে অনুমোদনের পর এখানে তা প্রদর্শিত হবে।"
                                )
                            }
                        } else {
                            items(myContributions) { item ->
                                CapitalContributionCard(item = item, formatter = currencyFormatter)
                            }
                        }
                    }
                }
                1 -> {
                    // All Contributions
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (allContributions.isEmpty()) {
                            item {
                                EmptyStateView(
                                    icon = Icons.Outlined.AccountBalanceWallet,
                                    title = "ফাউন্ডেশনের কোনো মূলধন রেকর্ড নেই",
                                    subtitle = "মূলধন জমাদানের নতুন তথ্য যুক্ত করা হলে এখানে প্রদর্শিত হবে।",
                                    actionButtonText = if (isAdmin) "নতুন মূলধন এন্ট্রি দিন" else null,
                                    onActionClick = { showAddDialog = true }
                                )
                            }
                        } else {
                            items(allContributions) { item ->
                                CapitalContributionCard(item = item, formatter = currencyFormatter)
                            }
                        }
                    }
                }
                2 -> {
                    // Financial Summary Breakdown
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Action Buttons: PDF Download & Admin Edit
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    PdfReportGenerator.generateAndShareMonthlyReport(
                                        context = context,
                                        overview = overview,
                                        members = membersList,
                                        projects = projectsList
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreenDark),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(imageVector = Icons.Default.PictureAsPdf, contentDescription = "PDF")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("মাসিক রিপোর্ট (PDF)", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }

                            if (isAdmin) {
                                OutlinedButton(
                                    onClick = { showEditFinancialDialog = true },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "হিসাব সম্পাদনা")
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("হিসাব সম্পাদনা", fontSize = 13.sp, color = IslamicGreenDark)
                                }
                            }
                        }

                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text(
                                    text = "শরীয়াহসম্মত আর্থিক হিসাব সারসংক্ষেপ",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = IslamicGreenDark
                                )
                                Divider(color = BorderSubtle)

                                SummaryRow("মোট সংগৃহীত মূলধন", "+ ৳ ${currencyFormatter.format(overview.totalCapitalCollected.toInt())}", IslamicGreen)
                                SummaryRow("অনুদানের অতিরিক্ত তহবিল", "+ ৳ ${currencyFormatter.format(overview.extraFunds.toInt())}", IslamicGreen)
                                SummaryRow("মোট প্রতিষ্ঠানের ব্যয়", "- ৳ ${currencyFormatter.format(overview.totalExpenses.toInt())}", ErrorRed)
                                SummaryRow("মোট বণ্টিত মুনাফা", "- ৳ ${currencyFormatter.format(overview.totalProfitDistributed.toInt())}", IslamicGold)

                                Divider(color = BorderSubtle)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "বর্তমান তহবিলের ব্যালেন্স",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "৳ ${currencyFormatter.format(overview.currentBalance.toInt())}",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 20.sp,
                                        color = IslamicGreenDark
                                    )
                                }
                            }
                        }

                        // Monthly snapshot (চলতি মাসের কার্যক্রম)
                        EmbossedCard(
                            modifier = Modifier.fillMaxWidth(),
                            backgroundColor = Color(0xFFF7FAF7)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "চলতি মাসের কার্যক্রম",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = IslamicGreenDark
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = IslamicGreenContainer
                                    ) {
                                        Text(
                                            text = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date()),
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = IslamicGreenDark,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                                Divider(color = BorderSubtle)

                                SummaryRow("১. চলতি মাসের মূলধন সংগ্রহ", "৳ ${currencyFormatter.format(overview.monthlyCapitalCollection.toInt())}", IslamicGreen)
                                SummaryRow("২. চলতি মাসের মোট ব্যয়", "৳ ${currencyFormatter.format(overview.monthlyExpenses.toInt())}", ErrorRed)
                                SummaryRow("৩. চলতি মাসের মোট মুনাফা", "৳ ${currencyFormatter.format(overview.currentMonthProfit.toInt())}", IslamicGold)
                            }
                        }
                    }
                }
                3 -> {
                    // MEMBER CAPITAL SHARE TRACKER (সদস্য শেয়ার ট্র্যাকার)
                    val totalCap = if (overview.totalCapitalCollected > 0) overview.totalCapitalCollected else 1.0
                    val sortedMembers = membersList.sortedByDescending { it.totalCapitalContributed }

                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            EmbossedCard(
                                modifier = Modifier.fillMaxWidth(),
                                backgroundColor = IslamicGreenContainer.copy(alpha = 0.5f)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(
                                        text = "সদস্য মূলধন শেয়ার ট্র্যাকার",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = IslamicGreenDark
                                    )
                                    Text(
                                        text = "যৌথ মূলধনের ব্যবসায়ীক নীতি অনুযায়ী প্রতিটি সদস্যের বিনিয়োগের পরিমাণ ও শতকরা অংশীদারিত্বের হিসাব:",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                    Divider(color = BorderSubtle)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "সর্বমোট বিনিয়োগ মূলধন:", fontSize = 13.sp, color = TextPrimary)
                                        Text(
                                            text = "৳ ${currencyFormatter.format(overview.totalCapitalCollected.toInt())}",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = IslamicGreenDark
                                        )
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(text = "মোট অংশীদার সদস্য:", fontSize = 13.sp, color = TextPrimary)
                                        Text(
                                            text = "${membersList.size} জন",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = IslamicGreen
                                        )
                                    }
                                }
                            }
                        }

                        items(sortedMembers) { member ->
                            val sharePercentage = (member.totalCapitalContributed / totalCap) * 100
                            val isMe = member.uid == currentUser?.uid

                            EmbossedCard(
                                modifier = Modifier.fillMaxWidth(),
                                backgroundColor = if (isMe) Color(0xFFF1F8F3) else MaterialTheme.colorScheme.surface
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Surface(
                                                shape = CircleShape,
                                                color = if (isMe) IslamicGreen else Color(0xFFE0E0E0),
                                                modifier = Modifier.size(36.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = member.name.take(1).uppercase(),
                                                        color = if (isMe) Color.White else Color.DarkGray,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                            Column {
                                                Row(
                                                    verticalAlignment = Alignment.CenterVertically,
                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                ) {
                                                    Text(
                                                        text = member.name.ifBlank { "সদস্য" },
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 15.sp,
                                                        color = TextPrimary
                                                    )
                                                    if (isMe) {
                                                        Surface(
                                                            shape = RoundedCornerShape(4.dp),
                                                            color = IslamicGreen
                                                        ) {
                                                            Text(
                                                                text = "আমি",
                                                                color = Color.White,
                                                                fontSize = 10.sp,
                                                                fontWeight = FontWeight.Bold,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                                Text(
                                                    text = member.phone.ifBlank { "মোবাইল দেওয়া হয়নি" },
                                                    fontSize = 12.sp,
                                                    color = TextSecondary
                                                )
                                            }
                                        }

                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = String.format(Locale.US, "%.2f%%", sharePercentage),
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = IslamicGreenDark
                                            )
                                            Text(
                                                text = "৳ ${currencyFormatter.format(member.totalCapitalContributed.toInt())}",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Medium,
                                                color = TextSecondary
                                            )
                                        }
                                    }

                                    // Visual Share Bar
                                    LinearProgressIndicator(
                                        progress = { (sharePercentage / 100f).toFloat().coerceIn(0f, 1f) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = if (isMe) IslamicGreenDark else IslamicGreen,
                                        trackColor = Color(0xFFE8E8E8)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Member Deposit Submission Dialog
        if (showMemberDepositDialog) {
            MemberDepositDialog(
                paymentSettings = paymentSettings,
                currentUser = currentUser,
                onDismiss = { showMemberDepositDialog = false },
                onSubmit = { deposit ->
                    viewModel.submitMemberDeposit(deposit) { res ->
                        if (res.isSuccess) {
                            showMemberDepositDialog = false
                            android.widget.Toast.makeText(context, "মূলধন জমা সফলভাবে সাবমিট হয়েছে। অ্যাডমিন পর্যালোচনার পর অনুমোদন করবেন।", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            android.widget.Toast.makeText(context, "সাবমিট ব্যর্থ: ${res.exceptionOrNull()?.message}", android.widget.Toast.LENGTH_LONG).show()
                        }
                    }
                }
            )
        }

        // Admin Edit Financial Overview Dialog
        if (showEditFinancialDialog) {
            AdminEditFinancialDialog(
                overview = overview,
                onDismiss = { showEditFinancialDialog = false },
                onSave = { updatedOverview ->
                    viewModel.updateFinancialOverview(updatedOverview) { res ->
                        if (res.isSuccess) {
                            showEditFinancialDialog = false
                            android.widget.Toast.makeText(context, "আর্থিক সারাংশ সফলভাবে হালনাগাদ করা হয়েছে", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }

        if (showAddDialog) {
            AddCapitalContributionDialog(
                members = membersList,
                onDismiss = { showAddDialog = false },
                onAdd = { newEntry ->
                    viewModel.addCapitalContribution(newEntry) { res ->
                        if (res.isSuccess) {
                            showAddDialog = false
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun SummaryRow(title: String, amount: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, fontSize = 14.sp, color = TextSecondary)
        Text(text = amount, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
fun CapitalContributionCard(
    item: CapitalContribution,
    formatter: NumberFormat
) {
    EmbossedCard(modifier = Modifier.fillMaxWidth()) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = IslamicGreenContainer,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.Payments,
                                contentDescription = null,
                                tint = IslamicGreen,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = item.memberName.ifBlank { "সদস্য" },
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = item.monthYear,
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "৳ ${formatter.format(item.paidAmount.toInt())}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = IslamicGreen
                    )
                    StatusBadge(status = item.status)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = BorderSubtle, thickness = 0.6.dp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "মাধ্যম: ${item.paymentMethod}",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Text(
                    text = "তারিখ: ${item.paymentDate}",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
            }

            if (item.dueAmount > 0) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "বকেয়া: ৳ ${formatter.format(item.dueAmount.toInt())}",
                    fontSize = 12.sp,
                    color = ErrorRed,
                    fontWeight = FontWeight.Medium
                )
            }

            if (item.transactionNote.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "নোট: ${item.transactionNote}",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddCapitalContributionDialog(
    members: List<UserProfile>,
    onDismiss: () -> Unit,
    onAdd: (CapitalContribution) -> Unit
) {
    var selectedMember by remember { mutableStateOf<UserProfile?>(members.firstOrNull()) }
    var expandedMemberDropdown by remember { mutableStateOf(false) }

    var expectedAmount by remember { mutableStateOf("") }
    var paidAmount by remember { mutableStateOf("") }
    var dueAmount by remember { mutableStateOf("") }
    var monthYear by remember {
        mutableStateOf(
            SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())
        )
    }
    var paymentDate by remember {
        mutableStateOf(
            SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
        )
    }
    var paymentMethod by remember { mutableStateOf("নগদ (Cash)") }
    var transactionNote by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "মূলধন জমাদান এন্ট্রি",
                fontWeight = FontWeight.Bold,
                color = IslamicGreenDark
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Member Selector
                ExposedDropdownMenuBox(
                    expanded = expandedMemberDropdown,
                    onExpandedChange = { expandedMemberDropdown = !expandedMemberDropdown }
                ) {
                    OutlinedTextField(
                        value = selectedMember?.name ?: "সদস্য নির্বাচন করুন",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("সদস্য") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedMemberDropdown) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedMemberDropdown,
                        onDismissRequest = { expandedMemberDropdown = false }
                    ) {
                        members.forEach { m ->
                            DropdownMenuItem(
                                text = { Text("${m.name} (${m.phone})") },
                                onClick = {
                                    selectedMember = m
                                    expandedMemberDropdown = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = paidAmount,
                    onValueChange = { paidAmount = it },
                    label = { Text("জমা দেওয়া পরিমাণ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = expectedAmount,
                    onValueChange = { expectedAmount = it },
                    label = { Text("প্রত্যাশিত পরিমাণ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = dueAmount,
                    onValueChange = { dueAmount = it },
                    label = { Text("বকেয়া পরিমাণ (৳) - প্রযোজ্য হলে") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = monthYear,
                    onValueChange = { monthYear = it },
                    label = { Text("মাস / বছর (যেমন: সেপ্টেম্বর ২০২৬)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = paymentDate,
                    onValueChange = { paymentDate = it },
                    label = { Text("পরিশোধের তারিখ (তারিখ/মাস/বছর)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = paymentMethod,
                    onValueChange = { paymentMethod = it },
                    label = { Text("পেমেন্ট পদ্ধতি (নগদ, ব্যাংক, বিকাশ, নগদ)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = transactionNote,
                    onValueChange = { transactionNote = it },
                    label = { Text("ট্রানজেকশন নোট / রেফারেন্স") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val member = selectedMember ?: return@Button
                    val paid = paidAmount.toDoubleOrNull() ?: 0.0
                    val exp = expectedAmount.toDoubleOrNull() ?: paid
                    val due = dueAmount.toDoubleOrNull() ?: 0.0

                    if (paid > 0) {
                        onAdd(
                            CapitalContribution(
                                memberId = member.uid,
                                memberName = member.name,
                                memberPhone = member.phone,
                                expectedAmount = exp,
                                paidAmount = paid,
                                dueAmount = due,
                                monthYear = monthYear.trim(),
                                paymentDate = paymentDate.trim(),
                                paymentMethod = paymentMethod.trim(),
                                transactionNote = transactionNote.trim()
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
