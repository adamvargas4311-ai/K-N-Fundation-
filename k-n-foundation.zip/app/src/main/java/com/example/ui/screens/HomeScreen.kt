package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CapitalContribution
import com.example.model.FinancialOverview
import com.example.model.NoticeItem
import com.example.model.UserProfile
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: MainViewModel,
    onNavigateToCapital: () -> Unit,
    onNavigateToProjects: () -> Unit,
    onNavigateToNotices: () -> Unit,
    onNavigateToAdminDashboard: () -> Unit,
    onNavigateToAuth: () -> Unit = {}
) {
    val overview by viewModel.financialOverview.collectAsState()
    val allContributions by viewModel.allCapitalContributions.collectAsState()
    val notices by viewModel.notices.collectAsState()
    val userProfile by viewModel.currentUserProfile.collectAsState()

    var showLogoDialog by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Dashboard, 1: Constitution & Rules

    val currencyFormatter = remember { NumberFormat.getNumberInstance(Locale.US) }

    if (showLogoDialog) {
        FullscreenLogoDialog(onDismiss = { showLogoDialog = false })
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        val isWideScreen = maxWidth >= 720.dp

        if (isWideScreen) {
            // Tablet / Landscape: Side-by-side Dual Pane ("হোম পেইজের একপাশে গঠনতন্ত্র ও নিয়ম")
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Left Pane: Financial & Business Dashboard
                Box(
                    modifier = Modifier
                        .weight(1.05f)
                        .fillMaxHeight()
                ) {
                    HomeDashboardList(
                        overview = overview,
                        allContributions = allContributions,
                        notices = notices,
                        userProfile = userProfile,
                        currencyFormatter = currencyFormatter,
                        onNavigateToCapital = onNavigateToCapital,
                        onNavigateToProjects = onNavigateToProjects,
                        onNavigateToNotices = onNavigateToNotices,
                        onNavigateToAdminDashboard = onNavigateToAdminDashboard,
                        onNavigateToAuth = onNavigateToAuth,
                        onLogoClick = { showLogoDialog = true },
                        onOpenConstitution = { selectedTab = 1 },
                        showConstitutionBanner = false
                    )
                }

                // Vertical Divider Line between panes
                VerticalDivider(
                    color = BorderSubtle,
                    thickness = 1.dp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )

                // Right Pane: Official Constitution & Policies directly on the side of the home page!
                Box(
                    modifier = Modifier
                        .weight(0.95f)
                        .fillMaxHeight()
                ) {
                    ConstitutionView(
                        onLogoClick = { showLogoDialog = true }
                    )
                }
            }
        } else {
            // Standard Mobile Screen: Top Tab Switcher & Rich Integration
            Column(modifier = Modifier.fillMaxSize()) {
                // Top Segmented Bar for easy switching between Dashboard and Constitution
                Surface(
                    color = Color.White,
                    shadowElevation = 2.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = Color.White,
                        contentColor = IslamicGreen,
                        indicator = { tabPositions ->
                            TabRowDefaults.SecondaryIndicator(
                                Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = IslamicGreen,
                                height = 3.dp
                            )
                        }
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Dashboard,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedTab == 0) IslamicGreen else TextSecondary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "ড্যাশবোর্ড",
                                        fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp,
                                        color = if (selectedTab == 0) IslamicGreen else TextSecondary
                                    )
                                }
                            }
                        )

                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.MenuBook,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = if (selectedTab == 1) IslamicGreen else TextSecondary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "গঠনতন্ত্র ও নিয়ম (১৬ ধারা)",
                                        fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 13.sp,
                                        color = if (selectedTab == 1) IslamicGreen else TextSecondary
                                    )
                                }
                            }
                        )
                    }
                }

                // Tab Content
                Box(modifier = Modifier.fillMaxSize()) {
                    if (selectedTab == 0) {
                        HomeDashboardList(
                            overview = overview,
                            allContributions = allContributions,
                            notices = notices,
                            userProfile = userProfile,
                            currencyFormatter = currencyFormatter,
                            onNavigateToCapital = onNavigateToCapital,
                            onNavigateToProjects = onNavigateToProjects,
                            onNavigateToNotices = onNavigateToNotices,
                            onNavigateToAdminDashboard = onNavigateToAdminDashboard,
                            onNavigateToAuth = onNavigateToAuth,
                            onLogoClick = { showLogoDialog = true },
                            onOpenConstitution = { selectedTab = 1 },
                            showConstitutionBanner = true
                        )
                    } else {
                        ConstitutionView(
                            onLogoClick = { showLogoDialog = true }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeDashboardList(
    overview: FinancialOverview,
    allContributions: List<CapitalContribution>,
    notices: List<NoticeItem>,
    userProfile: UserProfile?,
    currencyFormatter: NumberFormat,
    onNavigateToCapital: () -> Unit,
    onNavigateToProjects: () -> Unit,
    onNavigateToNotices: () -> Unit,
    onNavigateToAdminDashboard: () -> Unit,
    onNavigateToAuth: () -> Unit,
    onLogoClick: () -> Unit,
    onOpenConstitution: () -> Unit,
    showConstitutionBanner: Boolean
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Header Card with Logo & Foundation Identity
        item {
            EmbossedCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = MaterialTheme.colorScheme.surface
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Ornate Logo Container with Double Rings and Tap Effect
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(82.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(
                                        listOf(IslamicGoldContainer, Color.White)
                                    )
                                )
                                .clickable(onClick = onLogoClick)
                        ) {
                            Surface(
                                shape = CircleShape,
                                border = BorderStroke(2.5.dp, IslamicGold),
                                shadowElevation = 6.dp,
                                modifier = Modifier.size(76.dp)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.org_logo),
                                    contentDescription = "খতমে নবুয়াত ফাউন্ডেশন লোগো",
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .clip(CircleShape)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "খতমে নবুয়াত ফাউন্ডেশন",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = IslamicGreenDark
                            )
                            Text(
                                text = "K N Foundation",
                                style = MaterialTheme.typography.labelMedium,
                                color = IslamicGold,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = IslamicGreenContainer.copy(alpha = 0.5f),
                                onClick = onLogoClick
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ZoomIn,
                                        contentDescription = null,
                                        tint = IslamicGreen,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "লোগো দেখুন",
                                        fontSize = 11.sp,
                                        color = IslamicGreenDark,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "“সর্বশেষ নবী মুহাম্মদ ﷺ উনার পরে আর কোন নবী আসবে না”",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = IslamicGoldDark
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "যৌথ মূলধনের মাধ্যমে শরীয়াসম্মত ব্যবসায়ীক কার্যক্রম পরিচালনা উদ্দেশ্যে গঠিত সংগঠন",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )

                    if (userProfile == null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = IslamicGoldContainer.copy(alpha = 0.6f),
                            border = BorderStroke(1.dp, IslamicGold.copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Info,
                                        contentDescription = null,
                                        tint = IslamicGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "অতিথি হিসেবে ব্রাউজ করছেন",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        color = TextPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "যৌথ মূলধনে অংশ নিতে এবং ব্যক্তিগত লভ্যাংশ দেখতে আপনার অ্যাকাউন্ট তৈরি বা লগইন করুন।",
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    lineHeight = 16.sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = onNavigateToAuth,
                                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                    modifier = Modifier.height(36.dp)
                                ) {
                                    Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("অ্যাকাউন্ট তৈরি বা লগইন করুন", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    if (userProfile != null && userProfile.isAdmin()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = IslamicGreenContainer,
                            onClick = onNavigateToAdminDashboard,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.AdminPanelSettings,
                                        contentDescription = null,
                                        tint = IslamicGreen,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (userProfile.isSuperAdmin()) "সুপার অ্যাডমিন কন্ট্রোল প্যানেল" else "অ্যাডমিন ম্যানেজমেন্ট প্যানেল",
                                        color = IslamicGreenDark,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 13.sp
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.ChevronRight,
                                    contentDescription = null,
                                    tint = IslamicGreen,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Constitution Quick Access Banner (On Mobile view)
        if (showConstitutionBanner) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White,
                    border = BorderStroke(1.5.dp, IslamicGold.copy(alpha = 0.5f)),
                    shadowElevation = 3.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(onClick = onOpenConstitution)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = IslamicGreenContainer,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = IslamicGreen,
                                    modifier = Modifier.size(26.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "গঠনতন্ত্র ও পরিচালনা নীতিমালা",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = IslamicGreenDark
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "১৬টি পূর্ণাঙ্গ ধারা • শরীয়াহ নীতি • লাভ-লোকসান ও কিস্তি নিয়মাবলি",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        }

                        IconButton(onClick = onOpenConstitution) {
                            Icon(
                                imageVector = Icons.Default.ArrowForwardIos,
                                contentDescription = "Open Constitution",
                                tint = IslamicGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // Financial Balance Card (Neumorphic Islamic Green Gradient)
        item {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(4.dp, RoundedCornerShape(18.dp)),
                shape = RoundedCornerShape(18.dp),
                color = Color.Transparent
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    IslamicGreenDark,
                                    IslamicGreen,
                                    IslamicGreenLight
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ফাউন্ডেশনের বর্তমান ব্যালেন্স",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = IslamicGold
                            ) {
                                Text(
                                    text = "শরীয়াহসম্মত তহবিল",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "৳ ${currencyFormatter.format(overview.currentBalance.toInt())}",
                            color = Color.White,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        HorizontalDivider(color = Color.White.copy(alpha = 0.2f), thickness = 0.8.dp)

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "মোট সংগৃহীত মূলধন",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "৳ ${currencyFormatter.format(overview.totalCapitalCollected.toInt())}",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "মোট প্রতিষ্ঠান ব্যয়",
                                    color = Color.White.copy(alpha = 0.8f),
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "৳ ${currencyFormatter.format(overview.totalExpenses.toInt())}",
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Quick Stats Row (3 Metrics)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Total Members
                EmbossedCard(
                    modifier = Modifier.weight(1f),
                    backgroundColor = MaterialTheme.colorScheme.surface
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Icon(
                            imageVector = Icons.Default.Groups,
                            contentDescription = null,
                            tint = IslamicGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${overview.totalMembers}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "মোট সদস্য",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                // Ongoing Projects
                EmbossedCard(
                    modifier = Modifier.weight(1f),
                    backgroundColor = MaterialTheme.colorScheme.surface,
                    onClick = onNavigateToProjects
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Icon(
                            imageVector = Icons.Default.BusinessCenter,
                            contentDescription = null,
                            tint = IslamicGold,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${overview.ongoingProjectsCount}",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "চলমান প্রকল্প",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                // Monthly Capital
                EmbossedCard(
                    modifier = Modifier.weight(1.2f),
                    backgroundColor = MaterialTheme.colorScheme.surface,
                    onClick = onNavigateToCapital
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                        Icon(
                            imageVector = Icons.Default.Savings,
                            contentDescription = null,
                            tint = IslamicGreen,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "৳ ${currencyFormatter.format(overview.monthlyCapitalCollection.toInt())}",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "চলতি মাসের মূলধন",
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Recent Capital Contributions Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "সাম্প্রতিক মূলধন জমাদান",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                TextButton(onClick = onNavigateToCapital) {
                    Text("সব দেখুন", color = IslamicGreen, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        val recentContributions = allContributions.take(4)
        if (recentContributions.isEmpty()) {
            item {
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    EmptyStateView(
                        icon = Icons.Outlined.AccountBalanceWallet,
                        title = "কোনো মূলধন জমাদানের তথ্য পাওয়া যায়নি",
                        subtitle = "ফাউন্ডেশনের মূলধন রেকর্ড সম্পন্ন হলে এখানে প্রদর্শিত হবে।"
                    )
                }
            }
        } else {
            items(recentContributions) { item ->
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = IslamicGreenContainer,
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = IslamicGreen,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = item.memberName.ifBlank { "সম্মানিত সদস্য" },
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "${item.monthYear} | ${item.paymentMethod}",
                                    fontSize = 12.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "+ ৳${currencyFormatter.format(item.paidAmount.toInt())}",
                                color = IslamicGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                            StatusBadge(status = item.status)
                        }
                    }
                }
            }
        }

        // Recent Notices Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "সাম্প্রতিক নোটিশ ও ঘোষণা",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                TextButton(onClick = onNavigateToNotices) {
                    Text("সব নোটিশ", color = IslamicGreen, fontWeight = FontWeight.SemiBold)
                }
            }
        }

        val recentNotices = notices.take(3)
        if (recentNotices.isEmpty()) {
            item {
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    EmptyStateView(
                        icon = Icons.Outlined.Campaign,
                        title = "কোনো নতুন নোটিশ নেই",
                        subtitle = "ফাউন্ডেশনের সাম্প্রতিক সিদ্ধান্ত ও নোটিশ এখানে দেখতে পাবেন।"
                    )
                }
            }
        } else {
            items(recentNotices) { notice ->
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusBadge(status = notice.type)
                            if (notice.priority == "জরুরি") {
                                StatusBadge(status = "জরুরি")
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = notice.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = notice.content,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 2
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "প্রকাশক: ${notice.authorName.ifBlank { "প্রশাসন" }}",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                            Text(
                                text = notice.date,
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
