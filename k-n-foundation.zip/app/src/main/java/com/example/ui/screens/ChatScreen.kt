package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.ChatMessage
import com.example.model.ConversationItem
import com.example.model.UserProfile
import com.example.ui.MainViewModel
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateView
import com.example.ui.components.ImagePickerAndUploader
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val conversations by viewModel.conversations.collectAsState()
    val members by viewModel.members.collectAsState()
    val currentUser by viewModel.currentUserProfile.collectAsState()

    var activeConversationId by remember { mutableStateOf<String?>(null) }
    var activeRecipient by remember { mutableStateOf<UserProfile?>(null) }
    var showStartChatDialog by remember { mutableStateOf(false) }

    if (activeConversationId != null && activeRecipient != null) {
        ChatDetailView(
            conversationId = activeConversationId!!,
            recipient = activeRecipient!!,
            viewModel = viewModel,
            onBack = {
                activeConversationId = null
                activeRecipient = null
            }
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = "বার্তা আদান-প্রদান",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = IslamicGreenDark
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "ফিরে যান", tint = IslamicGreenDark)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
                )
            },
            floatingActionButton = {
                FloatingActionButton(
                    onClick = { showStartChatDialog = true },
                    containerColor = IslamicGreen,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.AddComment, contentDescription = "নতুন বার্তা")
                }
            }
        ) { paddingValues ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                if (conversations.isEmpty()) {
                    EmptyStateView(
                        icon = Icons.Outlined.Chat,
                        title = "কোনো পূর্ববর্তী বার্তা নেই",
                        subtitle = "ফাউন্ডেশনের সদস্য বা প্রশাসনের সাথে যোগাযোগ করতে নিচের বাটনে ক্লিক করুন।",
                        actionButtonText = "নতুন বার্তা শুরু করুন",
                        onActionClick = { showStartChatDialog = true }
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(conversations) { item ->
                            val otherUid = item.participantIds.firstOrNull { it != currentUser?.uid } ?: ""
                            val otherName = item.participantNames[otherUid] ?: "সদস্য"

                            EmbossedCard(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = {
                                    activeConversationId = item.id
                                    activeRecipient = members.find { it.uid == otherUid }
                                        ?: UserProfile(uid = otherUid, name = otherName)
                                }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = IslamicGreenContainer,
                                            modifier = Modifier.size(46.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.Person, contentDescription = null, tint = IslamicGreen)
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = otherName,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 15.sp,
                                                color = TextPrimary
                                            )
                                            Text(
                                                text = item.lastMessage.ifBlank { "বার্তা পাঠান..." },
                                                fontSize = 13.sp,
                                                color = TextSecondary,
                                                maxLines = 1
                                            )
                                        }
                                    }
                                    val unread = item.unreadCount[currentUser?.uid] ?: 0
                                    if (unread > 0) {
                                        Surface(
                                            shape = CircleShape,
                                            color = IslamicGreen,
                                            modifier = Modifier.size(20.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Text(
                                                    text = "$unread",
                                                    color = Color.White,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showStartChatDialog) {
            val otherMembers = members.filter { it.uid != currentUser?.uid }
            AlertDialog(
                onDismissRequest = { showStartChatDialog = false },
                title = { Text("কাকে বার্তা পাঠাতে চান?", fontWeight = FontWeight.Bold, color = IslamicGreenDark) },
                text = {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 350.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(otherMembers) { m ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        val myUid = currentUser?.uid.orEmpty()
                                        val otherUid = m.uid
                                        val convId = if (myUid < otherUid) "${myUid}_${otherUid}" else "${otherUid}_${myUid}"
                                        activeConversationId = convId
                                        activeRecipient = m
                                        showStartChatDialog = false
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.AccountCircle, contentDescription = null, tint = IslamicGreen)
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(m.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Text(
                                            if (m.isAdmin()) "প্রশাসন (${m.role})" else "সদস্য",
                                            fontSize = 11.sp,
                                            color = TextMuted
                                        )
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showStartChatDialog = false }) { Text("বাতিল") }
                }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailView(
    conversationId: String,
    recipient: UserProfile,
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val messagesFlow = remember(conversationId) { viewModel.observeMessages(conversationId) }
    val messages by messagesFlow.collectAsState(initial = emptyList())
    val currentUser by viewModel.currentUserProfile.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var attachedImageUrl by remember { mutableStateOf("") }
    var showImagePickerDialog by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(conversationId) {
        viewModel.markMessagesAsSeen(conversationId)
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = IslamicGreenContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = IslamicGreen)
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = recipient.name.ifBlank { "সদস্য" },
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = IslamicGreenDark
                            )
                            Text(
                                text = if (recipient.isAdmin()) "প্রশাসন" else "সদস্য",
                                style = MaterialTheme.typography.labelSmall,
                                color = IslamicGold
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "ফিরে যান", tint = IslamicGreenDark)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 4.dp
            ) {
                Column(modifier = Modifier.navigationBarsPadding()) {
                    if (attachedImageUrl.isNotBlank()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Image, contentDescription = null, tint = IslamicGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("ছবি সংযুক্ত করা হয়েছে", fontSize = 12.sp, color = IslamicGreen)
                            }
                            IconButton(onClick = { attachedImageUrl = "" }) {
                                Icon(Icons.Default.Close, contentDescription = "বাদ দিন", tint = ErrorRed, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showImagePickerDialog = true }) {
                            Icon(Icons.Default.AttachFile, contentDescription = "ছবি যোগ করুন", tint = IslamicGreen)
                        }

                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            placeholder = { Text("বার্তা লিখুন...") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(24.dp),
                            singleLine = false,
                            maxLines = 4
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        IconButton(
                            onClick = {
                                if (inputText.isNotBlank() || attachedImageUrl.isNotBlank()) {
                                    val textToSend = inputText.trim()
                                    val imgToSend = attachedImageUrl.trim()
                                    inputText = ""
                                    attachedImageUrl = ""
                                    viewModel.sendMessage(
                                        conversationId = conversationId,
                                        receiverId = recipient.uid,
                                        receiverName = recipient.name,
                                        text = textToSend,
                                        imageUrl = imgToSend
                                    )
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = IslamicGreen,
                                contentColor = Color.White
                            ),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "পাঠান", modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    val isMe = msg.senderId == currentUser?.uid
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = if (isMe) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Surface(
                            shape = RoundedCornerShape(
                                topStart = 14.dp,
                                topEnd = 14.dp,
                                bottomStart = if (isMe) 14.dp else 2.dp,
                                bottomEnd = if (isMe) 2.dp else 14.dp
                            ),
                            color = if (isMe) IslamicGreen else MaterialTheme.colorScheme.surface,
                            shadowElevation = 1.dp,
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                if (msg.imageUrl.isNotBlank()) {
                                    AsyncImage(
                                        model = msg.imageUrl,
                                        contentDescription = null,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(150.dp)
                                            .clip(RoundedCornerShape(8.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                }

                                if (msg.text.isNotBlank()) {
                                    Text(
                                        text = msg.text,
                                        color = if (isMe) Color.White else TextPrimary,
                                        fontSize = 14.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    modifier = Modifier.align(Alignment.End),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    val timeStr = remember(msg.timestamp) {
                                        java.text.SimpleDateFormat("hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(msg.timestamp))
                                    }
                                    Text(
                                        text = timeStr,
                                        fontSize = 10.sp,
                                        color = if (isMe) Color.White.copy(alpha = 0.7f) else TextMuted
                                    )
                                    if (isMe) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(
                                            imageVector = if (msg.seen) Icons.Default.DoneAll else Icons.Default.Done,
                                            contentDescription = null,
                                            tint = if (msg.seen) IslamicGoldLight else Color.White.copy(alpha = 0.7f),
                                            modifier = Modifier.size(12.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showImagePickerDialog) {
            AlertDialog(
                onDismissRequest = { showImagePickerDialog = false },
                title = { Text("ছবি সংযুক্ত করুন", fontWeight = FontWeight.Bold) },
                text = {
                    ImagePickerAndUploader(
                        currentImageUrl = attachedImageUrl,
                        onImageUrlSelected = {
                            attachedImageUrl = it
                            showImagePickerDialog = false
                        }
                    )
                },
                confirmButton = {},
                dismissButton = {
                    TextButton(onClick = { showImagePickerDialog = false }) { Text("বন্ধ করুন") }
                }
            )
        }
    }
}
