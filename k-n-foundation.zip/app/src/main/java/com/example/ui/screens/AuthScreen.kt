package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.ui.MainViewModel
import com.example.ui.components.EmbossedButton
import com.example.ui.components.EmbossedCard
import com.example.ui.components.ImagePickerAndUploader
import com.example.ui.theme.*
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch

@Composable
fun AuthScreen(
    viewModel: MainViewModel,
    onAuthSuccess: () -> Unit,
    onContinueAsGuest: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Login, 1 = Register

    var loginEmail by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }
    var loginPasswordVisible by remember { mutableStateOf(false) }

    var regName by remember { mutableStateOf("") }
    var regEmail by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }
    var regPhotoUrl by remember { mutableStateOf("") }
    var regPasswordVisible by remember { mutableStateOf(false) }

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top action bar with skip to guest button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onContinueAsGuest) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "ফিরে যান",
                        tint = IslamicGreenDark
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = IslamicGreenContainer.copy(alpha = 0.8f),
                    border = BorderStroke(1.dp, IslamicGreen.copy(alpha = 0.3f)),
                    modifier = Modifier.clickable { onContinueAsGuest() }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "অতিথি হিসেবে অ্যাপ দেখুন",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IslamicGreenDark
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = null,
                            tint = IslamicGreenDark,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Organization Logo with Ornate Golden Border
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(IslamicGoldContainer, Color.White)
                        )
                    )
            ) {
                Surface(
                    shape = CircleShape,
                    border = BorderStroke(2.5.dp, IslamicGold),
                    shadowElevation = 6.dp,
                    modifier = Modifier.size(90.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.org_logo),
                        contentDescription = "K N Foundation Logo",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "খতমে নবুয়াত ফাউন্ডেশন",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = IslamicGreenDark,
                textAlign = TextAlign.Center
            )

            Text(
                text = "“সর্বশেষ নবী মুহাম্মদ ﷺ উনার পরে আর কোন নবী আসবে না”",
                style = MaterialTheme.typography.labelSmall,
                color = IslamicGoldDark,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "যৌথ মূলধনের মাধ্যমে শরীয়াসম্মত ব্যবসায়ীক কার্যক্রম",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Google Sign-In / Account Creation Button
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .clickable(enabled = !isLoading) {
                        coroutineScope.launch {
                            try {
                                isLoading = true
                                errorMessage = null
                                val credentialManager = CredentialManager.create(context)
                                val googleIdOption = GetGoogleIdOption.Builder()
                                    .setFilterByAuthorizedAccounts(false)
                                    .setServerClientId("187601267865-9hp8uoianvvis9q66nv49ubkc95o5aie.apps.googleusercontent.com")
                                    .setAutoSelectEnabled(false)
                                    .build()
                                val request = GetCredentialRequest.Builder()
                                    .addCredentialOption(googleIdOption)
                                    .build()
                                val result = credentialManager.getCredential(context, request)
                                val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(result.credential.data)
                                viewModel.signInWithGoogle(googleIdTokenCredential.idToken) { authRes ->
                                    isLoading = false
                                    if (authRes.isSuccess) {
                                        Toast.makeText(context, "Google এর মাধ্যমে সফলভাবে সাইন ইন হয়েছে", Toast.LENGTH_SHORT).show()
                                        onAuthSuccess()
                                    } else {
                                        errorMessage = authRes.exceptionOrNull()?.localizedMessage ?: "Google সাইন ইন ব্যর্থ হয়েছে"
                                    }
                                }
                            } catch (e: Exception) {
                                isLoading = false
                                if (e !is GetCredentialCancellationException) {
                                    errorMessage = "Google সাইন ইন করা যায়নি: ${e.localizedMessage ?: "অনুগ্রহ করে আবার চেষ্টা করুন"}"
                                }
                            }
                        }
                    }
                    .testTag("google_signin_button"),
                shape = RoundedCornerShape(12.dp),
                color = Color.White,
                border = BorderStroke(1.2.dp, BorderSubtle),
                shadowElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_google_logo),
                        contentDescription = "Google Logo",
                        modifier = Modifier.size(22.dp),
                        tint = Color.Unspecified
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Google অ্যাকাউন্ট দিয়ে এগিয়ে যান",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                }
            }

            // Divider
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HorizontalDivider(modifier = Modifier.weight(1f), color = BorderSubtle)
                Text(
                    text = " অথবা ইমেইল দিয়ে ",
                    fontSize = 12.sp,
                    color = TextMuted,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
                HorizontalDivider(modifier = Modifier.weight(1f), color = BorderSubtle)
            }

            // Tab Selector
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFFF1F5F2),
                modifier = Modifier.fillMaxWidth()
            ) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = Color.Transparent,
                    indicator = {},
                    divider = {}
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = {
                            selectedTab = 0
                            errorMessage = null
                        },
                        text = {
                            Text(
                                "লগইন (Login)",
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 0) IslamicGreen else TextMuted
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = {
                            selectedTab = 1
                            errorMessage = null
                        },
                        text = {
                            Text(
                                "সদস্য নিবন্ধন (Register)",
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                color = if (selectedTab == 1) IslamicGreen else TextMuted
                            )
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (errorMessage != null) {
                Surface(
                    color = ErrorRed.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, ErrorRed.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.ErrorOutline,
                            contentDescription = null,
                            tint = ErrorRed,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = ErrorRed,
                            fontSize = 13.sp
                        )
                    }
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            if (selectedTab == 0) {
                // LOGIN FORM
                EmbossedCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = Color.White
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "আপনার অ্যাকাউন্টে প্রবেশ করুন",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        OutlinedTextField(
                            value = loginEmail,
                            onValueChange = { loginEmail = it },
                            label = { Text("ইমেইল (Email)") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Email, contentDescription = null, tint = IslamicGreen)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_email_input")
                        )

                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it },
                            label = { Text("পাসওয়ার্ড (Password)") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Lock, contentDescription = null, tint = IslamicGreen)
                            },
                            trailingIcon = {
                                IconButton(onClick = { loginPasswordVisible = !loginPasswordVisible }) {
                                    Icon(
                                        imageVector = if (loginPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (loginPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("login_password_input")
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        EmbossedButton(
                            text = "লগইন করুন",
                            onClick = {
                                if (loginEmail.isBlank() || loginPassword.isBlank()) {
                                    errorMessage = "দয়া করে ইমেইল এবং পাসওয়ার্ড প্রদান করুন।"
                                    return@EmbossedButton
                                }
                                isLoading = true
                                errorMessage = null
                                viewModel.signIn(loginEmail, loginPassword) { result ->
                                    isLoading = false
                                    if (result.isSuccess) {
                                        onAuthSuccess()
                                    } else {
                                        errorMessage = result.exceptionOrNull()?.localizedMessage ?: "লগইন ব্যর্থ হয়েছে"
                                    }
                                }
                            },
                            isLoading = isLoading,
                            icon = Icons.Default.Login,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "login_submit_button"
                        )
                    }
                }
            } else {
                // REGISTRATION FORM
                EmbossedCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = Color.White
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "নতুন সদস্য আবেদন ফরম",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        Text(
                            text = "সকল নতুন ব্যবহারকারী সদস্য (Member) হিসেবে অন্তর্ভুক্ত হবেন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = IslamicGold
                        )

                        OutlinedTextField(
                            value = regName,
                            onValueChange = { regName = it },
                            label = { Text("পূর্ণ নাম (Full Name)") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Person, contentDescription = null, tint = IslamicGreen)
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("reg_name_input")
                        )

                        OutlinedTextField(
                            value = regEmail,
                            onValueChange = { regEmail = it },
                            label = { Text("ইমেইল (Email)") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Email, contentDescription = null, tint = IslamicGreen)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier.fillMaxWidth().testTag("reg_email_input")
                        )

                        OutlinedTextField(
                            value = regPhone,
                            onValueChange = { regPhone = it },
                            label = { Text("মোবাইল নম্বর (Phone)") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Phone, contentDescription = null, tint = IslamicGreen)
                            },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.fillMaxWidth().testTag("reg_phone_input")
                        )

                        OutlinedTextField(
                            value = regPassword,
                            onValueChange = { regPassword = it },
                            label = { Text("পাসওয়ার্ড (Password)") },
                            leadingIcon = {
                                Icon(Icons.Outlined.Lock, contentDescription = null, tint = IslamicGreen)
                            },
                            trailingIcon = {
                                IconButton(onClick = { regPasswordVisible = !regPasswordVisible }) {
                                    Icon(
                                        imageVector = if (regPasswordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = null
                                    )
                                }
                            },
                            visualTransformation = if (regPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth().testTag("reg_password_input")
                        )

                        ImagePickerAndUploader(
                            currentImageUrl = regPhotoUrl,
                            onImageUrlSelected = { regPhotoUrl = it },
                            label = "প্রোফাইল ছবি (Profile Photo)"
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        EmbossedButton(
                            text = "নিবন্ধন সম্পন্ন করুন",
                            onClick = {
                                if (regName.isBlank() || regEmail.isBlank() || regPassword.isBlank() || regPhone.isBlank()) {
                                    errorMessage = "দয়া করে নাম, ইমেইল, ফোন এবং পাসওয়ার্ড পূরণ করুন।"
                                    return@EmbossedButton
                                }
                                if (regPassword.length < 6) {
                                    errorMessage = "পাসওয়ার্ড অন্তত ৬ অক্ষরের হতে হবে।"
                                    return@EmbossedButton
                                }
                                isLoading = true
                                errorMessage = null
                                viewModel.signUp(
                                    name = regName,
                                    email = regEmail,
                                    pass = regPassword,
                                    phone = regPhone,
                                    photoUrl = regPhotoUrl
                                ) { result ->
                                    isLoading = false
                                    if (result.isSuccess) {
                                        onAuthSuccess()
                                    } else {
                                        errorMessage = result.exceptionOrNull()?.localizedMessage ?: "নিবন্ধন ব্যর্থ হয়েছে"
                                    }
                                }
                            },
                            isLoading = isLoading,
                            icon = Icons.Default.PersonAdd,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "reg_submit_button"
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Guest browse option button
            OutlinedButton(
                onClick = onContinueAsGuest,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, IslamicGreen.copy(alpha = 0.5f))
            ) {
                Icon(
                    imageVector = Icons.Default.Visibility,
                    contentDescription = null,
                    tint = IslamicGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "অ্যাকাউন্ট ছাড়া অতিথি হিসেবে অ্যাপ ঘুরে দেখুন",
                    color = IslamicGreen,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "K N Foundation © 2026 | শরীয়াহসম্মত ব্যবসায়ীক অংশীদারিত্ব",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                textAlign = TextAlign.Center
            )
        }
    }
}
