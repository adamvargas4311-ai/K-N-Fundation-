package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.PollOption
import com.example.model.VotingPoll
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun VotingPollCard(
    poll: VotingPoll,
    currentUserId: String,
    isAdmin: Boolean,
    onVote: (optionId: String) -> Unit,
    onClosePoll: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isExpired = poll.isExpired()
    val isActive = poll.isVotingActive()
    val hasVoted = poll.hasVoted(currentUserId)
    val userVotedOptionId = poll.getUserVotedOptionId(currentUserId)
    val totalVotes = poll.totalVotes()

    var selectedOptionId by remember { mutableStateOf<String?>(null) }
    var showVotersList by remember { mutableStateOf(false) }

    // Remaining time formatter
    val timeLeftText = remember(poll.deadlineTimestamp, isExpired) {
        if (isExpired || poll.isClosedManually) {
            "ভোটগ্রহণ সমাপ্ত"
        } else {
            val diffMs = poll.deadlineTimestamp - System.currentTimeMillis()
            val hours = (diffMs / (1000 * 60 * 60)).toInt()
            val days = hours / 24
            val remHours = hours % 24
            when {
                days > 0 -> "বাকি আছে: $days দিন $remHours ঘণ্টা"
                hours > 0 -> "বাকি আছে: $hours ঘণ্টা"
                else -> "বাকি আছে: ৩০ মিনিটের কম"
            }
        }
    }

    EmbossedCard(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .animateContentSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Status Badge & Expiration Timer
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isActive) IslamicGreen else Color.Gray)
                    )
                    Text(
                        text = if (isActive) "চলমান ভোট" else "ভোটগ্রহণ সমাপ্ত",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isActive) IslamicGreenDark else Color.Gray
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = if (isActive) Icons.Outlined.Timer else Icons.Default.Lock,
                        contentDescription = "সময়",
                        tint = if (isActive) Color(0xFFE65100) else Color.Gray,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = timeLeftText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (isActive) Color(0xFFE65100) else Color.Gray
                    )
                }
            }

            // Image Announcement if present
            if (poll.imageUrl.isNotBlank()) {
                AsyncImage(
                    model = poll.imageUrl,
                    contentDescription = poll.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(170.dp)
                        .clip(RoundedCornerShape(8.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            // Title & Description
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = poll.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                if (poll.description.isNotBlank()) {
                    Text(
                        text = poll.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        lineHeight = 20.sp
                    )
                }
            }

            Divider(color = BorderSubtle)

            // Voted Status / Strict Notice
            if (hasVoted) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFE8F5E9),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "ভোট গৃহীত",
                            tint = IslamicGreenDark,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "আপনার ভোট গৃহীত হয়েছে। ভোট পরিবর্তন বা প্রত্যাহারযোগ্য নয়।",
                            fontSize = 12.sp,
                            color = IslamicGreenDark,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else if (!isActive) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF5F5F5),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "তথ্য",
                            tint = Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "সময়সীমা উত্তীর্ণ হওয়ায় ভোটগ্রহণ সমাপ্ত হয়েছে।",
                            fontSize = 12.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }

            // Options List
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                poll.options.forEach { option ->
                    val isUserSelection = userVotedOptionId == option.id
                    val isOptionSelected = selectedOptionId == option.id
                    val voteCount = poll.getOptionVoteCount(option.id)
                    val percentage = poll.getOptionPercentage(option.id)
                    val showResults = hasVoted || !isActive

                    if (showResults) {
                        // Results Progress Bar View
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isUserSelection) Color(0xFFE8F5E9) else Color(0xFFF5F7F6))
                                .border(
                                    width = if (isUserSelection) 1.5.dp else 1.dp,
                                    color = if (isUserSelection) IslamicGreen else Color(0xFFE0E0E0),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .padding(12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    if (isUserSelection) {
                                        Icon(
                                            imageVector = Icons.Default.CheckCircle,
                                            contentDescription = "আপনার পছন্দ",
                                            tint = IslamicGreen,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    Text(
                                        text = option.text,
                                        fontWeight = if (isUserSelection) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isUserSelection) IslamicGreenDark else TextPrimary,
                                        fontSize = 14.sp
                                    )
                                }
                                Text(
                                    text = "$percentage% ($voteCount ভোট)",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUserSelection) IslamicGreenDark else TextSecondary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { (percentage / 100f).coerceIn(0f, 1f) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = if (isUserSelection) IslamicGreen else Color(0xFF81C784),
                                trackColor = Color(0xFFE0E0E0)
                            )
                        }
                    } else {
                        // Interactive Voting Option (User has not yet voted)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .border(
                                    width = if (isOptionSelected) 1.5.dp else 1.dp,
                                    color = if (isOptionSelected) IslamicGreen else Color(0xFFE0E0E0),
                                    shape = RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedOptionId = option.id }
                                .padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            RadioButton(
                                selected = isOptionSelected,
                                onClick = { selectedOptionId = option.id },
                                colors = RadioButtonDefaults.colors(selectedColor = IslamicGreen)
                            )
                            Text(
                                text = option.text,
                                fontSize = 14.sp,
                                fontWeight = if (isOptionSelected) FontWeight.Bold else FontWeight.Normal,
                                color = TextPrimary
                            )
                        }
                    }
                }
            }

            // Submit Vote Button (If active and not yet voted)
            if (isActive && !hasVoted) {
                Button(
                    onClick = {
                        selectedOptionId?.let { optId ->
                            onVote(optId)
                        }
                    },
                    enabled = selectedOptionId != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cast_vote_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.HowToVote, contentDescription = "ভোট দিন")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = "ভোট প্রদান করুন (একবারই প্রযোজ্য)", fontWeight = FontWeight.Bold)
                }
            }

            // Footer info & Admin controls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "মোট ভোট: $totalVotes টি",
                    fontSize = 12.sp,
                    color = TextSecondary,
                    fontWeight = FontWeight.Medium
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (isAdmin && poll.voterNames.isNotEmpty()) {
                        TextButton(onClick = { showVotersList = !showVotersList }) {
                            Text(
                                text = if (showVotersList) "তালিকা লুকান" else "ভোটার তালিকা",
                                fontSize = 11.sp,
                                color = IslamicGreenDark
                            )
                        }
                    }

                    if (isAdmin && isActive) {
                        TextButton(
                            onClick = onClosePoll,
                            colors = ButtonDefaults.textButtonColors(contentColor = ErrorRed)
                        ) {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = "বন্ধ করুন", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ভোট বন্ধ করুন", fontSize = 11.sp)
                        }
                    }
                }
            }

            // Voter names list for Admin transparency
            if (showVotersList && isAdmin && poll.voterNames.isNotEmpty()) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF9FBF9),
                    border = androidx.compose.foundation.BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "ভোট প্রদানকারী সদস্যগণ:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = IslamicGreenDark
                        )
                        poll.voterNames.forEach { (_, name) ->
                            Text(text = "• $name", fontSize = 11.sp, color = TextSecondary)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateVotingPollDialog(
    onDismiss: () -> Unit,
    onCreate: (VotingPoll) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var imageUrl by remember { mutableStateOf("") }
    var option1 by remember { mutableStateOf("হ্যাঁ (Yes)") }
    var option2 by remember { mutableStateOf("না (No)") }
    var option3 by remember { mutableStateOf("") }
    var option4 by remember { mutableStateOf("") }

    // Deadlines in hours
    val deadlineOptions = listOf(
        Pair("১২ ঘণ্টা", 12L),
        Pair("২৪ ঘণ্টা (১ দিন)", 24L),
        Pair("৩ দিন", 72L),
        Pair("৭ দিন (১ সপ্তাহ)", 168L),
        Pair("১৫ দিন", 360L)
    )
    var selectedDeadlineHours by remember { mutableLongStateOf(72L) }
    var expandedDeadlineDropdown by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "নতুন ভোট ও সিদ্ধান্ত গ্রহণ তৈরি করুন",
                fontWeight = FontWeight.Bold,
                color = IslamicGreenDark
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("ভোটের বিষয় / শিরোনাম *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("বিস্তারিত বিবরণ / ঘোষণা") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = imageUrl,
                    onValueChange = { imageUrl = it },
                    label = { Text("ঘোষণা/ছবি URL (ঐচ্ছিক)") },
                    placeholder = { Text("https://example.com/banner.jpg") },
                    modifier = Modifier.fillMaxWidth()
                )

                Divider(color = BorderSubtle)

                Text(
                    text = "ভোটের বিকল্পসমূহ (Options):",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = TextPrimary
                )

                OutlinedTextField(
                    value = option1,
                    onValueChange = { option1 = it },
                    label = { Text("বিকল্প ১ *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = option2,
                    onValueChange = { option2 = it },
                    label = { Text("বিকল্প ২ *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = option3,
                    onValueChange = { option3 = it },
                    label = { Text("বিকল্প ৩ (ঐচ্ছিক)") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = option4,
                    onValueChange = { option4 = it },
                    label = { Text("বিকল্প ৪ (ঐচ্ছিক)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Divider(color = BorderSubtle)

                // Expiry / Deadline Selector
                Text(
                    text = "ভোটের সময়সীমা (Expiration Deadline):",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = TextPrimary
                )

                ExposedDropdownMenuBox(
                    expanded = expandedDeadlineDropdown,
                    onExpandedChange = { expandedDeadlineDropdown = !expandedDeadlineDropdown }
                ) {
                    OutlinedTextField(
                        value = deadlineOptions.firstOrNull { it.second == selectedDeadlineHours }?.first ?: "৩ দিন",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("সময়সীমা নির্ধারণ করুন") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDeadlineDropdown) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedDeadlineDropdown,
                        onDismissRequest = { expandedDeadlineDropdown = false }
                    ) {
                        deadlineOptions.forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt.first) },
                                onClick = {
                                    selectedDeadlineHours = opt.second
                                    expandedDeadlineDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank() || option1.isBlank() || option2.isBlank()) return@Button
                    val opts = mutableListOf<PollOption>()
                    opts.add(PollOption(id = "opt_1", text = option1.trim(), voteCount = 0))
                    opts.add(PollOption(id = "opt_2", text = option2.trim(), voteCount = 0))
                    if (option3.isNotBlank()) {
                        opts.add(PollOption(id = "opt_3", text = option3.trim(), voteCount = 0))
                    }
                    if (option4.isNotBlank()) {
                        opts.add(PollOption(id = "opt_4", text = option4.trim(), voteCount = 0))
                    }

                    val deadlineMs = System.currentTimeMillis() + (selectedDeadlineHours * 3600 * 1000)
                    val newPoll = VotingPoll(
                        title = title.trim(),
                        description = description.trim(),
                        imageUrl = imageUrl.trim(),
                        options = opts,
                        deadlineTimestamp = deadlineMs
                    )
                    onCreate(newPoll)
                },
                enabled = title.isNotBlank() && option1.isNotBlank() && option2.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("ভোট প্রকাশ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
