package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import com.example.model.NoticeItem
import com.example.model.VotingPoll
import com.example.ui.MainViewModel
import com.example.ui.components.CreateVotingPollDialog
import com.example.ui.components.EmbossedCard
import com.example.ui.components.EmptyStateView
import com.example.ui.components.StatusBadge
import com.example.ui.components.VotingPollCard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NoticesScreen(
    viewModel: MainViewModel
) {
    val context = LocalContext.current
    val notices by viewModel.notices.collectAsState()
    val votingPolls by viewModel.votingPolls.collectAsState()
    val currentUser by viewModel.currentUserProfile.collectAsState()

    var primaryTab by remember { mutableIntStateOf(0) } // 0 = Notices, 1 = Voting & Decision Making
    var selectedFilter by remember { mutableStateOf("সকল") }
    var showAddNoticeDialog by remember { mutableStateOf(false) }
    var showCreatePollDialog by remember { mutableStateOf(false) }

    val isAdmin = currentUser?.isAdmin() == true
    val activePollsCount = votingPolls.count { it.isVotingActive() }

    val filteredNotices = when (selectedFilter) {
        "নোটিশ" -> notices.filter { it.type == "নোটিশ" || it.type == "ঘোষণা" }
        "মিটিং ও ইভেন্ট" -> notices.filter { it.type == "মিটিং" || it.type == "ইভেন্ট" }
        "প্রকল্প আপডেট" -> notices.filter { it.type == "প্রকল্প আপডেট" }
        else -> notices
    }

    Scaffold(
        floatingActionButton = {
            if (isAdmin) {
                FloatingActionButton(
                    onClick = {
                        if (primaryTab == 0) showAddNoticeDialog = true else showCreatePollDialog = true
                    },
                    containerColor = IslamicGreen,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_notice_or_poll_fab")
                ) {
                    Icon(
                        imageVector = if (primaryTab == 0) Icons.Default.Add else Icons.Default.HowToVote,
                        contentDescription = if (primaryTab == 0) "নোটিশ প্রকাশ" else "ভোট তৈরি"
                    )
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Main Top Tabs
            TabRow(
                selectedTabIndex = primaryTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IslamicGreen
            ) {
                Tab(
                    selected = primaryTab == 0,
                    onClick = { primaryTab = 0 },
                    text = {
                        Text(
                            "নোটিশ ও ঘোষণা",
                            fontWeight = if (primaryTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = primaryTab == 1,
                    onClick = { primaryTab = 1 },
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                "ভোট ও সিদ্ধান্ত গ্রহণ",
                                fontWeight = if (primaryTab == 1) FontWeight.Bold else FontWeight.Normal
                            )
                            if (activePollsCount > 0) {
                                Surface(
                                    shape = CircleShape,
                                    color = IslamicGreenDark
                                ) {
                                    Text(
                                        text = "$activePollsCount",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                )
            }

            if (primaryTab == 0) {
                // NOTICES TAB
                // Filter Bar
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.surface,
                    shadowElevation = 1.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("সকল", "নোটিশ", "মিটিং ও ইভেন্ট", "প্রকল্প আপডেট").forEach { filter ->
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = IslamicGreen,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (filteredNotices.isEmpty()) {
                        item {
                            EmptyStateView(
                                icon = Icons.Outlined.Campaign,
                                title = "কোনো নোটিশ বা ঘোষণা নেই",
                                subtitle = "ফাউন্ডেশনের সাধারণ সভা, নোটিশ ও ইভেন্টের বিবরণ এখানে দেখতে পাবেন।",
                                actionButtonText = if (isAdmin) "নতুন নোটিশ প্রকাশ করুন" else null,
                                onActionClick = { showAddNoticeDialog = true }
                            )
                        }
                    } else {
                        items(filteredNotices) { notice ->
                            NoticeCard(notice = notice)
                        }
                    }
                }
            } else {
                // VOTING & DECISION MAKING TAB
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = IslamicGreenContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.HowToVote,
                                        contentDescription = null,
                                        tint = IslamicGreenDark,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "যৌথ ব্যবসায় গণতান্ত্রিক সিদ্ধান্ত গ্রহণ",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = IslamicGreenDark
                                    )
                                }
                                Text(
                                    text = "প্রতিটি সক্রিয় ভোটে একজন সদস্য কেবল একবারই ভোট দিতে পারবেন। ভোট প্রদান করার পর তা পরিবর্তন বা প্রত্যাহার করা যাবে না। সময়সীমা উত্তীর্ণ হলে ফলাফল স্বয়ংক্রিয়ভাবে লক হয়ে যাবে।",
                                    fontSize = 12.sp,
                                    color = TextSecondary,
                                    lineHeight = 18.sp
                                )
                            }
                        }
                    }

                    if (votingPolls.isEmpty()) {
                        item {
                            EmptyStateView(
                                icon = Icons.Outlined.HowToVote,
                                title = "কোনো সক্রিয় ভোট বা সিদ্ধান্ত প্রস্তাব নেই",
                                subtitle = "প্রশাসনের পক্ষ থেকে গুরুত্বপূর্ণ ব্যবসায়িক বিষয়ে ভোটের আয়োজন করা হলে এখানে অংশ নিতে পারবেন।",
                                actionButtonText = if (isAdmin) "নতুন ভোট প্রস্তাব তৈরি করুন" else null,
                                onActionClick = { showCreatePollDialog = true }
                            )
                        }
                    } else {
                        items(votingPolls) { poll ->
                            VotingPollCard(
                                poll = poll,
                                currentUserId = currentUser?.uid ?: "",
                                isAdmin = isAdmin,
                                onVote = { optionId ->
                                    viewModel.castVote(poll.id, optionId) { res ->
                                        if (res.isSuccess) {
                                            Toast.makeText(context, "আপনার মূল্যবান ভোট সফলভাবে গৃহীত হয়েছে!", Toast.LENGTH_SHORT).show()
                                        } else {
                                            Toast.makeText(context, "ভোট গ্রহণ ব্যর্থ: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                onClosePoll = {
                                    viewModel.closePollManually(poll.id) { res ->
                                        if (res.isSuccess) {
                                            Toast.makeText(context, "ভোটগ্রহণ সমাপ্ত করা হয়েছে", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }

        if (showAddNoticeDialog) {
            AddNoticeDialog(
                authorName = currentUser?.name ?: "অ্যাডমিন",
                onDismiss = { showAddNoticeDialog = false },
                onAdd = { newNotice ->
                    viewModel.addNotice(newNotice) { res ->
                        if (res.isSuccess) {
                            showAddNoticeDialog = false
                            Toast.makeText(context, "নোটিশ সফলভাবে প্রকাশিত হয়েছে", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }

        if (showCreatePollDialog) {
            CreateVotingPollDialog(
                onDismiss = { showCreatePollDialog = false },
                onCreate = { newPoll ->
                    viewModel.createVotingPoll(newPoll) { res ->
                        if (res.isSuccess) {
                            showCreatePollDialog = false
                            Toast.makeText(context, "ভোট সফলভাবে চালু করা হয়েছে", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun NoticeCard(notice: NoticeItem) {
    EmbossedCard(modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusBadge(status = notice.type)
                    if (notice.priority == "জরুরি") {
                        StatusBadge(status = "জরুরি")
                    }
                }

                Text(
                    text = notice.date,
                    fontSize = 12.sp,
                    color = TextMuted
                )
            }

            Text(
                text = notice.title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Text(
                text = notice.content,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                lineHeight = 22.sp
            )

            if (!notice.eventDate.isNullOrBlank()) {
                Surface(
                    color = IslamicGoldContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Event,
                            contentDescription = null,
                            tint = IslamicGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "অনুষ্ঠানের সময়/তারিখ: ${notice.eventDate}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = IslamicGreenDark
                        )
                    }
                }
            }

            Divider(color = BorderSubtle, thickness = 0.6.dp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "বিজ্ঞপ্তি প্রদানকারী: ${notice.authorName.ifBlank { "ফাউন্ডেশন কর্তৃপক্ষ" }}",
                    fontSize = 11.sp,
                    color = TextMuted
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddNoticeDialog(
    authorName: String,
    onDismiss: () -> Unit,
    onAdd: (NoticeItem) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("নোটিশ") }
    var priority by remember { mutableStateOf("সাধারণ") }
    var eventDate by remember { mutableStateOf("") }
    val currentDate = remember {
        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন নোটিশ / ঘোষণা প্রকাশ", fontWeight = FontWeight.Bold, color = IslamicGreenDark) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("শিরোনাম (Title)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("ক্যাটাগরি নির্বাচন করুন:", fontSize = 12.sp, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("নোটিশ", "ঘোষণা", "মিটিং", "ইভেন্ট").forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = { type = t },
                            label = { Text(t, fontSize = 11.sp) }
                        )
                    }
                }

                Text("অগ্রাধিকার:", fontSize = 12.sp, color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("সাধারণ", "জরুরি").forEach { p ->
                        FilterChip(
                            selected = priority == p,
                            onClick = { priority = p },
                            label = { Text(p, fontSize = 11.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("নোটিশের মূল বক্তব্য") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 6
                )

                OutlinedTextField(
                    value = eventDate,
                    onValueChange = { eventDate = it },
                    label = { Text("অনুষ্ঠানের তারিখ / সময় (প্রযোজ্য ক্ষেত্রে)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onAdd(
                            NoticeItem(
                                title = title.trim(),
                                content = content.trim(),
                                type = type,
                                priority = priority,
                                date = currentDate,
                                eventDate = eventDate.trim(),
                                authorName = authorName
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("প্রকাশ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
