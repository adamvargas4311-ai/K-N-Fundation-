package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CapitalContribution
import com.example.model.FinancialOverview
import com.example.model.PaymentSettings
import com.example.model.UserProfile
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MemberDepositDialog(
    paymentSettings: PaymentSettings,
    currentUser: UserProfile?,
    onDismiss: () -> Unit,
    onSubmit: (CapitalContribution) -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = remember { context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager }

    var selectedGateway by remember { mutableStateOf("বিকাশ (bKash)") }
    var amount by remember { mutableStateOf("1000") }
    var senderNumber by remember { mutableStateOf(currentUser?.phone ?: "") }
    var transactionId by remember { mutableStateOf("") }
    var monthYear by remember {
        mutableStateOf(SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date()))
    }
    var note by remember { mutableStateOf("") }

    val activeNumber = when (selectedGateway) {
        "বিকাশ (bKash)" -> paymentSettings.bkashNumber
        "নগদ (Nagad)" -> paymentSettings.nagadNumber.ifBlank { "অ্যাডমিন কর্তৃক নম্বর শীঘ্রই যুক্ত করা হবে" }
        "রকেট (Rocket)" -> paymentSettings.rocketNumber.ifBlank { "অ্যাডমিন কর্তৃক নম্বর শীঘ্রই যুক্ত করা হবে" }
        else -> paymentSettings.bkashNumber
    }

    val instructionText = when (selectedGateway) {
        "বিকাশ (bKash)" -> paymentSettings.bkashInstruction
        "নগদ (Nagad)" -> paymentSettings.nagadInstruction
        "রকেট (Rocket)" -> paymentSettings.rocketInstruction
        else -> ""
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "মূলধন জমা প্রদান (ডিপোজিট)",
                fontWeight = FontWeight.Bold,
                color = IslamicGreenDark
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "পেমেন্ট মেথড নির্বাচন করুন:",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )

                // Gateway Selector Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedGateway == "বিকাশ (bKash)",
                        onClick = { selectedGateway = "বিকাশ (bKash)" },
                        label = { Text("বিকাশ", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFE2136E),
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = selectedGateway == "নগদ (Nagad)",
                        onClick = { selectedGateway = "নগদ (Nagad)" },
                        label = { Text("নগদ", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFFF7941D),
                            selectedLabelColor = Color.White
                        )
                    )
                    FilterChip(
                        selected = selectedGateway == "রকেট (Rocket)",
                        onClick = { selectedGateway = "রকেট (Rocket)" },
                        label = { Text("রকেট", fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF8C3494),
                            selectedLabelColor = Color.White
                        )
                    )
                }

                // Official Foundation Payment Number Display Box
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF3F8F4),
                    border = androidx.compose.foundation.BorderStroke(1.dp, IslamicGreenLight.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "ফাউন্ডেশনের অফিসিয়াল $selectedGateway নম্বর:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = IslamicGreenDark
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = activeNumber,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            if (activeNumber.contains("01")) {
                                IconButton(
                                    onClick = {
                                        val clip = ClipData.newPlainText("Payment Number", activeNumber)
                                        clipboardManager.setPrimaryClip(clip)
                                        Toast.makeText(context, "$selectedGateway নম্বর কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "কপি করুন",
                                        tint = IslamicGreenDark,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }
                        if (instructionText.isNotBlank()) {
                            Text(
                                text = instructionText,
                                fontSize = 11.sp,
                                color = TextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                Divider(color = BorderSubtle)

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("জমাকৃত টাকার পরিমাণ (৳) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = monthYear,
                    onValueChange = { monthYear = it },
                    label = { Text("সংশ্লিষ্ট মাস ও বছর *") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = senderNumber,
                    onValueChange = { senderNumber = it },
                    label = { Text("আপনার প্রেরক মোবাইল নম্বর *") },
                    placeholder = { Text("যে নম্বর থেকে টাকা পাঠিয়েছেন") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = transactionId,
                    onValueChange = { transactionId = it },
                    label = { Text("ট্রানজেকশন আইডি (TrxID) *") },
                    placeholder = { Text("যেমন: BK92837492") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("অতিরিক্ত মন্তব্য / নোট (ঐচ্ছিক)") },
                    modifier = Modifier.fillMaxWidth()
                )

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFFFF8E1),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "পেমেন্ট সাবমিট করার পর অ্যাডমিন যাচাই করে আপনার মূলধন অ্যাকাউন্টে অনুমোদন করবেন।",
                        fontSize = 11.sp,
                        color = Color(0xFF8D6E63),
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull() ?: 0.0
                    if (amt <= 0 || transactionId.isBlank() || senderNumber.isBlank()) return@Button
                    val entry = CapitalContribution(
                        memberId = currentUser?.uid ?: "",
                        memberName = currentUser?.name ?: "সদস্য",
                        memberPhone = currentUser?.phone ?: senderNumber,
                        expectedAmount = amt,
                        paidAmount = amt,
                        dueAmount = 0.0,
                        monthYear = monthYear.trim(),
                        paymentDate = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()),
                        paymentMethod = selectedGateway,
                        transactionId = transactionId.trim(),
                        senderNumber = senderNumber.trim(),
                        transactionNote = note.trim(),
                        status = "প্রক্রিয়াধীন"
                    )
                    onSubmit(entry)
                },
                enabled = amount.isNotBlank() && transactionId.isNotBlank() && senderNumber.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("জমা সাবমিট করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
fun AdminPaymentSettingsDialog(
    currentSettings: PaymentSettings,
    onDismiss: () -> Unit,
    onSave: (PaymentSettings) -> Unit
) {
    var bkashNum by remember { mutableStateOf(currentSettings.bkashNumber) }
    var isBkashActive by remember { mutableStateOf(currentSettings.isBkashActive) }
    var bkashInstruction by remember { mutableStateOf(currentSettings.bkashInstruction) }

    var nagadNum by remember { mutableStateOf(currentSettings.nagadNumber) }
    var isNagadActive by remember { mutableStateOf(currentSettings.isNagadActive) }
    var nagadInstruction by remember { mutableStateOf(currentSettings.nagadInstruction) }

    var rocketNum by remember { mutableStateOf(currentSettings.rocketNumber) }
    var isRocketActive by remember { mutableStateOf(currentSettings.isRocketActive) }
    var rocketInstruction by remember { mutableStateOf(currentSettings.rocketInstruction) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "পেমেন্ট গেটওয়ে সেটিংস (অ্যাডমিন কনফিগ)",
                fontWeight = FontWeight.Bold,
                color = IslamicGreenDark
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "শুধুমাত্র অ্যাডমিন এই পেমেন্ট নম্বর পরিবর্তন করতে পারবেন। সাধারণ সদস্যরা এই নম্বরসমূহ ব্যবহার করে মূলধন পাঠাবেন।",
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                // bKash Section
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFDF0F5),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2136E).copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("বিকাশ (bKash) সেটিংস", fontWeight = FontWeight.Bold, color = Color(0xFFE2136E))
                            Switch(
                                checked = isBkashActive,
                                onCheckedChange = { isBkashActive = it }
                            )
                        }
                        OutlinedTextField(
                            value = bkashNum,
                            onValueChange = { bkashNum = it },
                            label = { Text("বিকাশ নম্বর (ডিফল্ট: 01950-515296)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = bkashInstruction,
                            onValueChange = { bkashInstruction = it },
                            label = { Text("পেমেন্ট নির্দেশনা") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Nagad Section
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFFFF8F0),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF7941D).copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("নগদ (Nagad) সেটিংস", fontWeight = FontWeight.Bold, color = Color(0xFFF7941D))
                            Switch(
                                checked = isNagadActive,
                                onCheckedChange = { isNagadActive = it }
                            )
                        }
                        OutlinedTextField(
                            value = nagadNum,
                            onValueChange = { nagadNum = it },
                            label = { Text("নগদ নম্বর (নম্বর যোগ করুন)") },
                            placeholder = { Text("01XXXXXXXXX") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = nagadInstruction,
                            onValueChange = { nagadInstruction = it },
                            label = { Text("পেমেন্ট নির্দেশনা") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Rocket Section
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF9F0FA),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF8C3494).copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("রকেট (Rocket) সেটিংস", fontWeight = FontWeight.Bold, color = Color(0xFF8C3494))
                            Switch(
                                checked = isRocketActive,
                                onCheckedChange = { isRocketActive = it }
                            )
                        }
                        OutlinedTextField(
                            value = rocketNum,
                            onValueChange = { rocketNum = it },
                            label = { Text("রকেট নম্বর (নম্বর যোগ করুন)") },
                            placeholder = { Text("01XXXXXXXXX-X") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = rocketInstruction,
                            onValueChange = { rocketInstruction = it },
                            label = { Text("পেমেন্ট নির্দেশনা") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = currentSettings.copy(
                        bkashNumber = bkashNum.trim(),
                        isBkashActive = isBkashActive,
                        bkashInstruction = bkashInstruction.trim(),

                        nagadNumber = nagadNum.trim(),
                        isNagadActive = isNagadActive,
                        nagadInstruction = nagadInstruction.trim(),

                        rocketNumber = rocketNum.trim(),
                        isRocketActive = isRocketActive,
                        rocketInstruction = rocketInstruction.trim()
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("সেটিংস সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}

@Composable
fun AdminEditFinancialDialog(
    overview: FinancialOverview,
    onDismiss: () -> Unit,
    onSave: (FinancialOverview) -> Unit
) {
    var monthlyCapital by remember { mutableStateOf(overview.monthlyCapitalCollection.toInt().toString()) }
    var monthlyExpenses by remember { mutableStateOf(overview.monthlyExpenses.toInt().toString()) }
    var monthlyProfit by remember { mutableStateOf(overview.currentMonthProfit.toInt().toString()) }
    var totalCapital by remember { mutableStateOf(overview.totalCapitalCollected.toInt().toString()) }
    var currentBalance by remember { mutableStateOf(overview.currentBalance.toInt().toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "আর্থিক সারাংশ ও মুনাফা সম্পাদন",
                fontWeight = FontWeight.Bold,
                color = IslamicGreenDark
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "চলতি মাসের আর্থিক কার্যক্রম ও মুনাফার হিসাব অ্যাডমিন কর্তৃক হালনাগাদ ও প্রকাশ করুন:",
                    fontSize = 12.sp,
                    color = TextSecondary
                )

                OutlinedTextField(
                    value = monthlyCapital,
                    onValueChange = { monthlyCapital = it },
                    label = { Text("১. চলতি মাসের মোট মূলধন সংগ্রহ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = monthlyExpenses,
                    onValueChange = { monthlyExpenses = it },
                    label = { Text("২. চলতি মাসের মোট ব্যয় (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = monthlyProfit,
                    onValueChange = { monthlyProfit = it },
                    label = { Text("৩. চলতি মাসের মোট মুনাফা (৳) *") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Divider(color = BorderSubtle)

                OutlinedTextField(
                    value = totalCapital,
                    onValueChange = { totalCapital = it },
                    label = { Text("সর্বমোট মূলধন সংগ্রহ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = currentBalance,
                    onValueChange = { currentBalance = it },
                    label = { Text("বর্তমান তহবিল ব্যালেন্স (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val updated = overview.copy(
                        monthlyCapitalCollection = monthlyCapital.toDoubleOrNull() ?: overview.monthlyCapitalCollection,
                        monthlyExpenses = monthlyExpenses.toDoubleOrNull() ?: overview.monthlyExpenses,
                        currentMonthProfit = monthlyProfit.toDoubleOrNull() ?: overview.currentMonthProfit,
                        totalCapitalCollected = totalCapital.toDoubleOrNull() ?: overview.totalCapitalCollected,
                        currentBalance = currentBalance.toDoubleOrNull() ?: overview.currentBalance
                    )
                    onSave(updated)
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("প্রকাশ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
