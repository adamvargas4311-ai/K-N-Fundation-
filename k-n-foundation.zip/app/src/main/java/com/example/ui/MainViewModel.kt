package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.FirebaseRepository
import com.example.model.*
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository = FirebaseRepository()

    val authFirebaseUser: StateFlow<FirebaseUser?> = repository.observeAuthState()
        .stateIn(viewModelScope, SharingStarted.Eagerly, repository.currentAuthUser)

    private val _currentUserProfile = MutableStateFlow<UserProfile?>(null)
    val currentUserProfile: StateFlow<UserProfile?> = _currentUserProfile.asStateFlow()

    val allCapitalContributions: StateFlow<List<CapitalContribution>> =
        repository.observeAllCapitalContributions()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val projects: StateFlow<List<BusinessProject>> =
        repository.observeProjects()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val expenses: StateFlow<List<OrganizationExpense>> =
        repository.observeExpenses()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val profitDistributions: StateFlow<List<ProfitDistribution>> =
        repository.observeProfitDistributions()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val notices: StateFlow<List<NoticeItem>> =
        repository.observeNotices()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val members: StateFlow<List<UserProfile>> =
        repository.observeMembers()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val paymentSettings: StateFlow<PaymentSettings> =
        repository.observePaymentSettings()
            .stateIn(viewModelScope, SharingStarted.Lazily, PaymentSettings())

    val votingPolls: StateFlow<List<VotingPoll>> =
        repository.observeVotingPolls()
            .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val manualFinancialSettings: StateFlow<FinancialOverview?> =
        repository.observeFinancialOverviewSettings()
            .stateIn(viewModelScope, SharingStarted.Lazily, null)

    private val _userNotifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val userNotifications: StateFlow<List<AppNotification>> = _userNotifications.asStateFlow()

    private val _conversations = MutableStateFlow<List<ConversationItem>>(emptyList())
    val conversations: StateFlow<List<ConversationItem>> = _conversations.asStateFlow()

    init {
        // Observe current user profile whenever auth state changes
        viewModelScope.launch {
            authFirebaseUser.collect { user ->
                if (user != null) {
                    repository.observeUserProfile(user.uid).collect { profile ->
                        _currentUserProfile.value = profile
                    }
                } else {
                    _currentUserProfile.value = null
                }
            }
        }

        // Observe notifications for current user
        viewModelScope.launch {
            authFirebaseUser.collect { user ->
                if (user != null) {
                    repository.observeNotifications(user.uid).collect { notifs ->
                        _userNotifications.value = notifs
                    }
                } else {
                    _userNotifications.value = emptyList()
                }
            }
        }

        // Observe conversations for current user
        viewModelScope.launch {
            authFirebaseUser.collect { user ->
                if (user != null) {
                    repository.observeConversations(user.uid).collect { convs ->
                        _conversations.value = convs
                    }
                } else {
                    _conversations.value = emptyList()
                }
            }
        }
    }

    // Filtered member's own capital contributions
    val myCapitalContributions: StateFlow<List<CapitalContribution>> = combine(
        authFirebaseUser,
        allCapitalContributions
    ) { user, list ->
        if (user == null) emptyList() else list.filter { it.memberId == user.uid }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Pending member deposit contributions awaiting Admin approval
    val pendingDeposits: StateFlow<List<CapitalContribution>> = allCapitalContributions.map { list ->
        list.filter { it.status == "প্রক্রিয়াধীন" }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    // Filtered member's received profit distributions
    val myReceivedProfits: StateFlow<List<ProfitDistribution>> = combine(
        authFirebaseUser,
        profitDistributions
    ) { user, list ->
        if (user == null) emptyList() else list.filter { it.memberShares.containsKey(user.uid) }
    }.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    private val transactionsBundle = combine(
        allCapitalContributions,
        expenses,
        profitDistributions
    ) { contributions, expList, distributions ->
        Triple(contributions, expList, distributions)
    }

    // Financial overview calculations
    val financialOverview: StateFlow<FinancialOverview> = combine(
        transactionsBundle,
        projects,
        members,
        manualFinancialSettings
    ) { (contributions, expList, distributions), projectList, memberList, manualSettings ->
        val approvedContributions = contributions.filter { it.status == "অনুমোদিত" }
        val totalCapital = approvedContributions.sumOf { it.paidAmount }
        val totalExpenses = expList.sumOf { it.amount }
        val totalProfitDist = distributions.sumOf { it.totalProfitAmount }
        val calculatedBalance = totalCapital - totalExpenses - totalProfitDist

        val currentMonthPrefix = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(java.util.Date())
        val calculatedMonthlyCapital = approvedContributions.filter { it.monthYear.contains(currentMonthPrefix) || isSameMonth(it.paymentDate) }
            .sumOf { it.paidAmount }
        val calculatedMonthlyExp = expList.filter { isSameMonth(it.date) }.sumOf { it.amount }

        // Current Month Profit: either from manual setting or current month's profit distributions
        val calculatedMonthlyProfit = if (manualSettings != null && manualSettings.currentMonthProfit > 0) {
            manualSettings.currentMonthProfit
        } else {
            distributions.filter { isSameMonth(it.distributionDate) }.sumOf { it.totalProfitAmount }
        }

        FinancialOverview(
            totalCapitalCollected = if (manualSettings != null && manualSettings.totalCapitalCollected > 0) manualSettings.totalCapitalCollected else totalCapital,
            extraFunds = manualSettings?.extraFunds ?: 0.0,
            totalExpenses = if (manualSettings != null && manualSettings.totalExpenses > 0) manualSettings.totalExpenses else totalExpenses,
            currentBalance = if (manualSettings != null && manualSettings.currentBalance > 0) manualSettings.currentBalance else calculatedBalance,
            monthlyCapitalCollection = if (manualSettings != null && manualSettings.monthlyCapitalCollection > 0) manualSettings.monthlyCapitalCollection else calculatedMonthlyCapital,
            monthlyExpenses = if (manualSettings != null && manualSettings.monthlyExpenses > 0) manualSettings.monthlyExpenses else calculatedMonthlyExp,
            currentMonthProfit = calculatedMonthlyProfit,
            totalProfitDistributed = totalProfitDist,
            totalMembers = memberList.size,
            activeMembers = memberList.count { it.status == "active" },
            ongoingProjectsCount = projectList.count { it.status == "চলমান" },
            completedProjectsCount = projectList.count { it.status == "সম্পন্ন" },
            lastUpdatedBy = manualSettings?.lastUpdatedBy ?: "",
            lastUpdatedAt = manualSettings?.lastUpdatedAt ?: 0L
        )
    }.stateIn(viewModelScope, SharingStarted.Lazily, FinancialOverview())

    val unreadNotificationsCount: StateFlow<Int> = userNotifications.map { list ->
        list.count { !it.isRead }
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0)

    // Auth actions
    fun signIn(email: String, pass: String, onResult: (Result<FirebaseUser>) -> Unit) {
        viewModelScope.launch {
            val res = repository.signIn(email, pass)
            onResult(res)
        }
    }

    fun signInWithGoogle(idToken: String, onResult: (Result<FirebaseUser>) -> Unit) {
        viewModelScope.launch {
            val res = repository.signInWithGoogleCredential(idToken)
            onResult(res)
        }
    }

    fun signUp(name: String, email: String, pass: String, phone: String, photoUrl: String, onResult: (Result<FirebaseUser>) -> Unit) {
        viewModelScope.launch {
            val res = repository.signUp(name, email, pass, phone, photoUrl)
            onResult(res)
        }
    }

    fun signOut() {
        repository.signOut()
    }

    // Capital
    fun addCapitalContribution(item: CapitalContribution, onResult: (Result<String>) -> Unit) {
        viewModelScope.launch {
            val res = repository.addCapitalContribution(item)
            onResult(res)
        }
    }

    // Projects
    fun addProject(project: BusinessProject, onResult: (Result<String>) -> Unit) {
        viewModelScope.launch {
            val res = repository.addProject(project)
            onResult(res)
        }
    }

    fun updateProject(project: BusinessProject, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val res = repository.updateProject(project)
            onResult(res)
        }
    }

    // Expenses
    fun addExpense(expense: OrganizationExpense, onResult: (Result<String>) -> Unit) {
        viewModelScope.launch {
            val res = repository.addExpense(expense)
            onResult(res)
        }
    }

    // Profit distribution
    fun addProfitDistribution(dist: ProfitDistribution, onResult: (Result<String>) -> Unit) {
        viewModelScope.launch {
            val res = repository.addProfitDistribution(dist)
            onResult(res)
        }
    }

    // Notices
    fun addNotice(notice: NoticeItem, onResult: (Result<String>) -> Unit) {
        viewModelScope.launch {
            val res = repository.addNotice(notice)
            onResult(res)
        }
    }

    // Members management
    fun updateMemberRoleAndPermissions(
        targetUid: String,
        newRole: String,
        newPermissions: List<String>,
        onResult: (Result<Unit>) -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.updateMemberRoleAndPermissions(targetUid, newRole, newPermissions)
            onResult(res)
        }
    }

    fun updateMemberStatus(targetUid: String, newStatus: String, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val res = repository.updateMemberStatus(targetUid, newStatus)
            onResult(res)
        }
    }

    fun updateUserProfile(profile: UserProfile, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val res = repository.updateUserProfile(profile)
            onResult(res)
        }
    }

    // Notifications
    fun markNotificationAsRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    // Messaging
    fun observeMessages(conversationId: String): Flow<List<ChatMessage>> {
        return repository.observeMessages(conversationId)
    }

    fun sendMessage(
        conversationId: String,
        receiverId: String,
        receiverName: String,
        text: String,
        imageUrl: String = "",
        onResult: (Result<Unit>) -> Unit = {}
    ) {
        val user = currentUserProfile.value ?: return
        viewModelScope.launch {
            val res = repository.sendMessage(
                conversationId = conversationId,
                senderId = user.uid,
                senderName = user.name.ifBlank { "সদস্য" },
                receiverId = receiverId,
                receiverName = receiverName,
                text = text,
                imageUrl = imageUrl
            )
            onResult(res)
        }
    }

    fun markMessagesAsSeen(conversationId: String) {
        val user = currentUserProfile.value ?: return
        viewModelScope.launch {
            repository.markMessagesAsSeen(conversationId, user.uid)
        }
    }

    // Payment Settings (Admin Only)
    fun updatePaymentSettings(settings: PaymentSettings, onResult: (Result<Unit>) -> Unit) {
        val admin = currentUserProfile.value
        val adminName = admin?.name ?: "অ্যাডমিন"
        viewModelScope.launch {
            val res = repository.updatePaymentSettings(settings, adminName)
            onResult(res)
        }
    }

    // Member Deposit Submission (Pending Admin Approval)
    fun submitMemberDeposit(item: CapitalContribution, onResult: (Result<String>) -> Unit) {
        viewModelScope.launch {
            val res = repository.submitMemberDeposit(item)
            onResult(res)
        }
    }

    // Deposit Approval by Admin
    fun approveCapitalContribution(id: String, memberId: String, amount: Double, onResult: (Result<Unit>) -> Unit) {
        val admin = currentUserProfile.value
        val adminName = admin?.name ?: "অ্যাডমিন"
        viewModelScope.launch {
            val res = repository.approveCapitalContribution(id, memberId, amount, adminName)
            onResult(res)
        }
    }

    fun rejectCapitalContribution(id: String, memberId: String, reason: String, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val res = repository.rejectCapitalContribution(id, memberId, reason)
            onResult(res)
        }
    }

    fun approveDeposit(deposit: CapitalContribution, onResult: (Result<Unit>) -> Unit) {
        approveCapitalContribution(deposit.id, deposit.memberId, deposit.paidAmount, onResult)
    }

    fun rejectDeposit(deposit: CapitalContribution, reason: String = "বাতিল করা হয়েছে", onResult: (Result<Unit>) -> Unit) {
        rejectCapitalContribution(deposit.id, deposit.memberId, reason, onResult)
    }

    // Advanced Voting & Decision-Making System
    fun createVotingPoll(poll: VotingPoll, onResult: (Result<String>) -> Unit) {
        val author = currentUserProfile.value
        val finalPoll = poll.copy(
            authorId = author?.uid ?: "",
            authorName = author?.name ?: "অ্যাডমিন"
        )
        viewModelScope.launch {
            val res = repository.createVotingPoll(finalPoll)
            onResult(res)
        }
    }

    fun castVote(pollId: String, optionId: String, onResult: (Result<Unit>) -> Unit) {
        val user = currentUserProfile.value
        if (user == null) {
            onResult(Result.failure(Exception("অনুগ্রহ করে লগইন করুন")))
            return
        }
        viewModelScope.launch {
            val res = repository.castVote(
                pollId = pollId,
                memberUid = user.uid,
                memberName = user.name.ifBlank { "সদস্য" },
                optionId = optionId
            )
            onResult(res)
        }
    }

    fun closeVotingPoll(pollId: String, onResult: (Result<Unit>) -> Unit) {
        viewModelScope.launch {
            val res = repository.closeVotingPoll(pollId)
            onResult(res)
        }
    }

    fun closePollManually(pollId: String, onResult: (Result<Unit>) -> Unit) {
        closeVotingPoll(pollId, onResult)
    }

    // Financial Overview Manual Publish / Edit by Admin
    fun updateFinancialOverview(overview: FinancialOverview, onResult: (Result<Unit>) -> Unit) {
        val admin = currentUserProfile.value
        val adminName = admin?.name ?: "অ্যাডমিন"
        viewModelScope.launch {
            val res = repository.updateFinancialOverviewManual(overview, adminName)
            onResult(res)
        }
    }

    private fun isSameMonth(dateStr: String): Boolean {
        if (dateStr.isBlank()) return false
        val currentMonthYear = java.text.SimpleDateFormat("yyyy-MM", java.util.Locale.getDefault()).format(java.util.Date())
        return dateStr.contains(currentMonthYear)
    }
}
