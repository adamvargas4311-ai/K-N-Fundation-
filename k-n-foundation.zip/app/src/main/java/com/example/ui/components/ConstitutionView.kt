package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.model.ConstitutionClause
import com.example.model.FoundationConstitutionData
import com.example.ui.theme.*

@Composable
fun ConstitutionView(
    modifier: Modifier = Modifier,
    listState: LazyListState = rememberLazyListState(),
    onLogoClick: () -> Unit = {}
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("সব ধারা") }
    var expandedClauseIds by remember {
        mutableStateOf(FoundationConstitutionData.clauses.map { it.id }.toSet())
    }

    val categories = remember {
        listOf("সব ধারা", "মূলনীতি ও উদ্দেশ্য", "মূলধন ও সঞ্চয়", "লাভ ও ব্যাংকিং", "কমিটি ও প্রশাসন", "সদস্যপদ", "হিসাব ও শৃঙ্খলা")
    }

    val filteredClauses = remember(searchQuery, selectedCategory) {
        FoundationConstitutionData.clauses.filter { clause ->
            val matchesCategory = selectedCategory == "সব ধারা" || clause.category == selectedCategory
            val matchesSearch = searchQuery.isBlank() ||
                    clause.title.contains(searchQuery, ignoreCase = true) ||
                    clause.numberBengali.contains(searchQuery) ||
                    clause.points.any { it.contains(searchQuery, ignoreCase = true) }
            matchesCategory && matchesSearch
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Islamic Official Document Banner
        item {
            EmbossedCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = Color.White
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    // Top Sacred Calligraphy Box
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = IslamicGoldContainer.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, IslamicGold.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 14.dp)
                        ) {
                            Text(
                                text = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = IslamicGreenDark,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "বিসমিল্লাহির রাহমানির রাহিম",
                                fontSize = 12.sp,
                                color = TextSecondary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Center Logo with Ornate Rings
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(80.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(IslamicGoldContainer, Color.White)
                                )
                            )
                            .clickable(onClick = onLogoClick)
                    ) {
                        Surface(
                            shape = CircleShape,
                            border = BorderStroke(2.5.dp, IslamicGold),
                            shadowElevation = 6.dp,
                            modifier = Modifier.size(76.dp)
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.org_logo),
                                contentDescription = "খতমে নবুয়াত ফাউন্ডেশন লোগো",
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = FoundationConstitutionData.ORGANIZATION_NAME,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = IslamicGreenDark,
                        textAlign = TextAlign.Center
                    )

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = IslamicGreenContainer,
                        modifier = Modifier.padding(top = 4.dp)
                    ) {
                        Text(
                            text = FoundationConstitutionData.DOCUMENT_TITLE,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = IslamicGreenDark,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "“${FoundationConstitutionData.PROPHET_BELIEF_STATEMENT}”",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold,
                        color = IslamicGold,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "— ${FoundationConstitutionData.MOTTO} —",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    HorizontalDivider(color = BorderSubtle, thickness = 0.8.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Action buttons row: Share full text & Toggle expand
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = {
                                val fullText = FoundationConstitutionData.getFullText()
                                val sendIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, fullText)
                                    type = "text/plain"
                                }
                                val shareIntent = Intent.createChooser(sendIntent, "গঠনতন্ত্র ও নীতিমালা শেয়ার করুন")
                                context.startActivity(shareIntent)
                            },
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, IslamicGreen),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = IslamicGreen),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("সম্পূর্ণ শেয়ার করুন", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }

                        TextButton(
                            onClick = {
                                expandedClauseIds = if (expandedClauseIds.size == FoundationConstitutionData.clauses.size) {
                                    emptySet()
                                } else {
                                    FoundationConstitutionData.clauses.map { it.id }.toSet()
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (expandedClauseIds.isEmpty()) Icons.Default.UnfoldMore else Icons.Default.UnfoldLess,
                                contentDescription = null,
                                tint = IslamicGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (expandedClauseIds.isEmpty()) "সব খুলুন" else "সব গুটিয়ে নিন",
                                fontSize = 12.sp,
                                color = IslamicGold,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ধারা বা বিষয় খুঁজুন (যেমন: মূলধন, সঞ্চয়, কিস্তি, লভ্যাংশ...)") },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = IslamicGreen)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = IslamicGreen,
                    unfocusedBorderColor = BorderSubtle,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                )
            )
        }

        // Category Filter Chips (Horizontal scrollable)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { category ->
                    val isSelected = selectedCategory == category
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = category },
                        label = {
                            Text(
                                text = category,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = IslamicGreen,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White,
                            labelColor = TextPrimary
                        ),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) IslamicGreen else BorderSubtle
                        ),
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            }
        }

        // Search count indicator if filtered
        if (searchQuery.isNotBlank() || selectedCategory != "সব ধারা") {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "মোট ফলাফল: ${filteredClauses.size}টি ধারা",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary
                    )
                    TextButton(onClick = {
                        searchQuery = ""
                        selectedCategory = "সব ধারা"
                    }) {
                        Text("ফিল্টার রিসেট", fontSize = 12.sp, color = IslamicGreen)
                    }
                }
            }
        }

        // Empty state if no search matches
        if (filteredClauses.isEmpty()) {
            item {
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    EmptyStateView(
                        icon = Icons.Outlined.SearchOff,
                        title = "কোনো ধারা পাওয়া যায়নি",
                        subtitle = "\"$searchQuery\" সম্পর্কিত কোনো ধারা নেই। অন্য শব্দ দিয়ে খুঁজে দেখুন।"
                    )
                }
            }
        } else {
            // All filtered clauses
            items(filteredClauses, key = { it.id }) { clause ->
                val isExpanded = expandedClauseIds.contains(clause.id)
                ConstitutionClauseCard(
                    clause = clause,
                    isExpanded = isExpanded,
                    onToggleExpand = {
                        expandedClauseIds = if (isExpanded) {
                            expandedClauseIds - clause.id
                        } else {
                            expandedClauseIds + clause.id
                        }
                    },
                    onCopyClause = {
                        val text = "【ধারা ${clause.numberBengali}: ${clause.title}】\n" +
                                clause.points.mapIndexed { idx, pt -> "(${idx + 1}) $pt" }.joinToString("\n") +
                                "\n— খতমে নবুয়াত ফাউন্ডেশন গঠনতন্ত্র"
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Constitution Clause ${clause.numberBengali}", text)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "ধারা ${clause.numberBengali} ক্লিপবোর্ডে কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                    },
                    onShareClause = {
                        val text = "【ধারা ${clause.numberBengali}: ${clause.title}】\n" +
                                clause.points.mapIndexed { idx, pt -> "(${idx + 1}) $pt" }.joinToString("\n") +
                                "\n— খতমে নবুয়াত ফাউন্ডেশন গঠনতন্ত্র"
                        val sendIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, text)
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "ধারা ${clause.numberBengali} শেয়ার করুন"))
                    }
                )
            }
        }

        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = IslamicGreenContainer.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "সার্বজনীন অঙ্গীকার",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = IslamicGreenDark
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "খতমে নবুয়াত ফাউন্ডেশনের প্রতিটি সদস্য এই গঠনতন্ত্র ও পরিচালনা নীতিমালা আন্তরিকভাবে মানতে অঙ্গীকারবদ্ধ। আল্লাহ তাআলা আমাদের সকলের হালাল প্রচেষ্টায় বরকত দান করুন।",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun ConstitutionClauseCard(
    clause: ConstitutionClause,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onCopyClause: () -> Unit,
    onShareClause: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .shadow(2.dp, RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(1.dp, if (isExpanded) IslamicGreen.copy(alpha = 0.35f) else BorderSubtle)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header: Number Badge, Title, Category and Expand Icon
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(onClick = onToggleExpand),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    // Number Badge
                    Surface(
                        shape = CircleShape,
                        color = IslamicGreen,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = clause.numberBengali,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 14.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = clause.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = TextPrimary
                        )
                        Text(
                            text = clause.category,
                            fontSize = 11.sp,
                            color = IslamicGold,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                IconButton(
                    onClick = onToggleExpand,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = if (isExpanded) "Collapse" else "Expand",
                        tint = IslamicGreenDark
                    )
                }
            }

            AnimatedVisibility(
                visible = isExpanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(10.dp))

                    // List of points
                    clause.points.forEachIndexed { index, point ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = IslamicGreenContainer,
                                modifier = Modifier
                                    .padding(top = 3.dp)
                                    .size(20.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "${index + 1}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IslamicGreenDark
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Text(
                                text = point,
                                fontSize = 13.sp,
                                color = TextPrimary,
                                lineHeight = 19.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = BorderSubtle.copy(alpha = 0.5f), thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(4.dp))

                    // Mini action bar for this clause
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(
                            onClick = onCopyClause,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp), tint = TextSecondary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("কপি", fontSize = 11.sp, color = TextSecondary)
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        TextButton(
                            onClick = onShareClause,
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp), tint = IslamicGreen)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("শেয়ার", fontSize = 11.sp, color = IslamicGreen, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FullscreenLogoDialog(
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = Color.White,
            shadowElevation = 10.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "প্রতিষ্ঠানের আনুষ্ঠানিক প্রতীক",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        color = IslamicGreenDark
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Official Logo Large Display
                Surface(
                    shape = CircleShape,
                    border = BorderStroke(4.dp, IslamicGold),
                    shadowElevation = 8.dp,
                    modifier = Modifier.size(220.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.org_logo),
                        contentDescription = "খতমে নবুয়াত ফাউন্ডেশন লোগো",
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "খতমে নবুয়াত ফাউন্ডেশন",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = IslamicGreenDark,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "K N Foundation",
                    style = MaterialTheme.typography.titleSmall,
                    color = IslamicGold,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "“সর্বশেষ নবী মুহাম্মদ ﷺ উনার পরে আর কোন নবী আসবে না”",
                    style = MaterialTheme.typography.bodySmall,
                    color = IslamicGoldDark,
                    textAlign = TextAlign.Center,
                    fontWeight = FontWeight.Medium
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ঠিক আছে", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
