package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.BusinessProject
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectsScreen(
    viewModel: MainViewModel
) {
    val projects by viewModel.projects.collectAsState()
    val currentUser by viewModel.currentUserProfile.collectAsState()

    var selectedFilter by remember { mutableStateOf("সকল") } // সকল, চলমান, সম্পন্ন
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedProjectForDetails by remember { mutableStateOf<BusinessProject?>(null) }

    val currencyFormatter = remember { NumberFormat.getNumberInstance(Locale.US) }
    val isAdmin = currentUser?.isAdmin() == true

    val filteredProjects = when (selectedFilter) {
        "চলমান" -> projects.filter { it.status == "চলমান" }
        "সম্পন্ন" -> projects.filter { it.status == "সম্পন্ন" }
        else -> projects
    }

    Scaffold(
        floatingActionButton = {
            if (isAdmin) {
                FloatingActionButton(
                    onClick = { showAddDialog = true },
                    containerColor = IslamicGreen,
                    contentColor = Color.White,
                    modifier = Modifier.testTag("add_project_fab")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "নতুন প্রকল্প")
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Filter Chips Row
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                shadowElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("সকল", "চলমান", "সম্পন্ন").forEach { filter ->
                        FilterChip(
                            selected = selectedFilter == filter,
                            onClick = { selectedFilter = filter },
                            label = { Text(filter) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = IslamicGreen,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (filteredProjects.isEmpty()) {
                    item {
                        EmptyStateView(
                            icon = Icons.Outlined.BusinessCenter,
                            title = "কোনো ব্যবসায়িক প্রকল্প নেই",
                            subtitle = "ফাউন্ডেশনের শরীয়াহসম্মত ব্যবসায়িক প্রকল্পসমূহ এখানে প্রকাশিত হবে।",
                            actionButtonText = if (isAdmin) "নতুন প্রকল্প যোগ করুন" else null,
                            onActionClick = { showAddDialog = true }
                        )
                    }
                } else {
                    items(filteredProjects) { project ->
                        ProjectCard(
                            project = project,
                            currencyFormatter = currencyFormatter,
                            onClick = { selectedProjectForDetails = project }
                        )
                    }
                }
            }
        }

        if (showAddDialog) {
            AddProjectDialog(
                onDismiss = { showAddDialog = false },
                onAdd = { newProject ->
                    viewModel.addProject(newProject) { res ->
                        if (res.isSuccess) {
                            showAddDialog = false
                        }
                    }
                }
            )
        }

        if (selectedProjectForDetails != null) {
            ProjectDetailDialog(
                project = selectedProjectForDetails!!,
                currencyFormatter = currencyFormatter,
                isAdmin = isAdmin,
                onDismiss = { selectedProjectForDetails = null },
                onUpdateStatus = { updatedProject ->
                    viewModel.updateProject(updatedProject) { res ->
                        if (res.isSuccess) {
                            selectedProjectForDetails = null
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun ProjectCard(
    project: BusinessProject,
    currencyFormatter: NumberFormat,
    onClick: () -> Unit
) {
    EmbossedCard(
        modifier = Modifier.fillMaxWidth(),
        onClick = onClick
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // Project Image Banner (if available)
            if (project.imageUrl.isNotBlank()) {
                AsyncImage(
                    model = project.imageUrl,
                    contentDescription = project.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(10.dp)),
                    contentScale = ContentScale.Crop
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = project.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${project.category} • ${project.location}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
                StatusBadge(status = project.status)
            }

            Text(
                text = project.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                maxLines = 2
            )

            Divider(color = BorderSubtle, thickness = 0.6.dp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "মোট বিনিয়োগ", fontSize = 11.sp, color = TextMuted)
                    Text(
                        text = "৳ ${currencyFormatter.format(project.totalInvestment.toInt())}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = IslamicGreenDark
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "প্রত্যাশিত লাভ", fontSize = 11.sp, color = TextMuted)
                    Text(
                        text = "৳ ${currencyFormatter.format(project.expectedProfit.toInt())}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = IslamicGold
                    )
                }
            }
        }
    }
}

@Composable
fun ProjectDetailDialog(
    project: BusinessProject,
    currencyFormatter: NumberFormat,
    isAdmin: Boolean,
    onDismiss: () -> Unit,
    onUpdateStatus: (BusinessProject) -> Unit
) {
    var editStatus by remember { mutableStateOf(project.status) }
    var editActualProfit by remember { mutableStateOf(project.actualProfitLoss.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(text = project.title, fontWeight = FontWeight.Bold, color = IslamicGreenDark)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (project.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = project.imageUrl,
                        contentDescription = null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .clip(RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                }

                Text(text = "বিবরণ:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(text = project.description, fontSize = 13.sp, color = TextSecondary)

                Divider(color = BorderSubtle)

                SummaryRow("ক্যাটাগরি", project.category, TextPrimary)
                SummaryRow("শুরুর তারিখ", project.startDate, TextPrimary)
                SummaryRow("স্থান", project.location, TextPrimary)
                SummaryRow("মোট বিনিয়োগ", "৳ ${currencyFormatter.format(project.totalInvestment.toInt())}", IslamicGreen)
                SummaryRow("প্রত্যাশিত লাভ", "৳ ${currencyFormatter.format(project.expectedProfit.toInt())}", IslamicGold)
                SummaryRow("প্রকৃত লাভ/ক্ষতি", "৳ ${currencyFormatter.format(project.actualProfitLoss.toInt())}", if (project.actualProfitLoss >= 0) IslamicGreen else ErrorRed)
                SummaryRow("বর্তমান অবস্থা", project.status, IslamicGreenDark)

                if (isAdmin) {
                    Divider(color = BorderSubtle)
                    Text(text = "অ্যাডমিন আপডেট:", fontWeight = FontWeight.Bold, color = IslamicGreenDark)

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("চলমান", "সম্পন্ন", "বাতিল").forEach { st ->
                            FilterChip(
                                selected = editStatus == st,
                                onClick = { editStatus = st },
                                label = { Text(st, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = editActualProfit,
                        onValueChange = { editActualProfit = it },
                        label = { Text("প্রকৃত লাভ / ক্ষতি (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            if (isAdmin) {
                Button(
                    onClick = {
                        val profitVal = editActualProfit.toDoubleOrNull() ?: project.actualProfitLoss
                        onUpdateStatus(
                            project.copy(status = editStatus, actualProfitLoss = profitVal)
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
                ) {
                    Text("আপডেট করুন")
                }
            } else {
                TextButton(onClick = onDismiss) { Text("ঠিক আছে") }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বন্ধ করুন") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProjectDialog(
    onDismiss: () -> Unit,
    onAdd: (BusinessProject) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("ট্রেডিং ও ব্যবসা") }
    var imageUrl by remember { mutableStateOf("") }
    var startDate by remember {
        mutableStateOf(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
    }
    var location by remember { mutableStateOf("ঢাকা, বাংলাদেশ") }
    var totalInvestment by remember { mutableStateOf("") }
    var expectedProfit by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("চলমান") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন ব্যবসায়িক প্রকল্প তৈরি", fontWeight = FontWeight.Bold, color = IslamicGreenDark) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("প্রকল্পের নাম (Title)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("প্রকল্পের বিবরণ (Description)") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("ক্যাটাগরি (ট্রেডিং, উৎপাদন, সেবা, ইত্যাদি)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                ImagePickerAndUploader(
                    currentImageUrl = imageUrl,
                    onImageUrlSelected = { imageUrl = it },
                    label = "প্রকল্পের ছবি (Project Image)"
                )

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("স্থান / এলাকা") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = totalInvestment,
                    onValueChange = { totalInvestment = it },
                    label = { Text("মোট বিনিয়োগ পরিমাণ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = expectedProfit,
                    onValueChange = { expectedProfit = it },
                    label = { Text("প্রত্যাশিত মোট লাভ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = startDate,
                    onValueChange = { startDate = it },
                    label = { Text("শুরুর তারিখ (দিন/মাস/বছর)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val inv = totalInvestment.toDoubleOrNull() ?: 0.0
                    val expProf = expectedProfit.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank() && inv > 0) {
                        onAdd(
                            BusinessProject(
                                title = title.trim(),
                                description = description.trim(),
                                category = category.trim(),
                                imageUrl = imageUrl.trim(),
                                startDate = startDate.trim(),
                                location = location.trim(),
                                totalInvestment = inv,
                                expectedProfit = expProf,
                                actualProfitLoss = 0.0,
                                status = status
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("তৈরি করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
