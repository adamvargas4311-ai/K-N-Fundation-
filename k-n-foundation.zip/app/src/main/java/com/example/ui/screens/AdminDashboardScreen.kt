package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.*
import com.example.ui.MainViewModel
import com.example.ui.components.*
import com.example.ui.theme.*
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

import androidx.compose.ui.platform.LocalContext
import android.widget.Toast
import com.example.data.PdfReportGenerator

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: MainViewModel,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val overview by viewModel.financialOverview.collectAsState()
    val currentUser by viewModel.currentUserProfile.collectAsState()
    val members by viewModel.members.collectAsState()
    val projects by viewModel.projects.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val profitDistributions by viewModel.profitDistributions.collectAsState()
    val paymentSettings by viewModel.paymentSettings.collectAsState()
    val pendingDeposits by viewModel.pendingDeposits.collectAsState()
    val votingPolls by viewModel.votingPolls.collectAsState()

    val currencyFormatter = remember { NumberFormat.getNumberInstance(Locale.US) }
    val isSuperAdmin = currentUser?.isSuperAdmin() == true

    var activeAdminTab by remember { mutableIntStateOf(0) }

    // Dialog states
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var showAddProfitDistributionDialog by remember { mutableStateOf(false) }
    var showAddCapitalDialog by remember { mutableStateOf(false) }
    var showAddProjectDialog by remember { mutableStateOf(false) }
    var showAddNoticeDialog by remember { mutableStateOf(false) }
    var showPaymentSettingsDialog by remember { mutableStateOf(false) }
    var showEditFinancialDialog by remember { mutableStateOf(false) }
    var showCreatePollDialog by remember { mutableStateOf(false) }
    var selectedMemberToManage by remember { mutableStateOf<UserProfile?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isSuperAdmin) "সুপার অ্যাডমিন ড্যাশবোর্ড" else "অ্যাডমিন ড্যাশবোর্ড",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = IslamicGreenDark
                        )
                        Text(
                            text = "খতমে নবুয়াত ফাউন্ডেশন প্রশাসন",
                            style = MaterialTheme.typography.labelSmall,
                            color = IslamicGold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "ফিরে যান", tint = IslamicGreenDark)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Admin Section Tabs
            ScrollableTabRow(
                selectedTabIndex = activeAdminTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = IslamicGreen,
                edgePadding = 16.dp
            ) {
                Tab(
                    selected = activeAdminTab == 0,
                    onClick = { activeAdminTab = 0 },
                    text = { Text("ওভারভিউ ও একশন", fontWeight = if (activeAdminTab == 0) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = activeAdminTab == 1,
                    onClick = { activeAdminTab = 1 },
                    text = { Text("সদস্য ব্যবস্থাপনা (${members.size})", fontWeight = if (activeAdminTab == 1) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = activeAdminTab == 2,
                    onClick = { activeAdminTab = 2 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("জমা অনুমোদন", fontWeight = if (activeAdminTab == 2) FontWeight.Bold else FontWeight.Normal)
                            if (pendingDeposits.isNotEmpty()) {
                                Surface(shape = CircleShape, color = ErrorRed) {
                                    Text(
                                        text = "${pendingDeposits.size}",
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                )
                Tab(
                    selected = activeAdminTab == 3,
                    onClick = { activeAdminTab = 3 },
                    text = { Text("পেমেন্ট গেটওয়ে", fontWeight = if (activeAdminTab == 3) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = activeAdminTab == 4,
                    onClick = { activeAdminTab = 4 },
                    text = { Text("ভোট ও সিদ্ধান্ত", fontWeight = if (activeAdminTab == 4) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = activeAdminTab == 5,
                    onClick = { activeAdminTab = 5 },
                    text = { Text("খরচ ব্যবস্থাপনা", fontWeight = if (activeAdminTab == 5) FontWeight.Bold else FontWeight.Normal) }
                )
                Tab(
                    selected = activeAdminTab == 6,
                    onClick = { activeAdminTab = 6 },
                    text = { Text("মুনাফা বণ্টন", fontWeight = if (activeAdminTab == 6) FontWeight.Bold else FontWeight.Normal) }
                )
            }

            when (activeAdminTab) {
                0 -> {
                    // OVERVIEW & QUICK ACTIONS
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // All 10 Metrics as required
                        item {
                            Text(
                                text = "ফাউন্ডেশনের রিয়েল-টাইম হিসাব",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    MetricCard(
                                        title = "বর্তমান তহবিল ব্যালেন্স",
                                        value = "৳ ${currencyFormatter.format(overview.currentBalance.toInt())}",
                                        color = IslamicGreenDark,
                                        modifier = Modifier.weight(1f)
                                    )
                                    MetricCard(
                                        title = "মোট সংগৃহীত মূলধন",
                                        value = "৳ ${currencyFormatter.format(overview.totalCapitalCollected.toInt())}",
                                        color = IslamicGreen,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    MetricCard(
                                        title = "চলতি মাসের মূলধন",
                                        value = "৳ ${currencyFormatter.format(overview.monthlyCapitalCollection.toInt())}",
                                        color = IslamicGreenLight,
                                        modifier = Modifier.weight(1f)
                                    )
                                    MetricCard(
                                        title = "মোট প্রতিষ্ঠানের ব্যয়",
                                        value = "৳ ${currencyFormatter.format(overview.totalExpenses.toInt())}",
                                        color = ErrorRed,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    MetricCard(
                                        title = "চলতি মাসের ব্যয়",
                                        value = "৳ ${currencyFormatter.format(overview.monthlyExpenses.toInt())}",
                                        color = ErrorRed,
                                        modifier = Modifier.weight(1f)
                                    )
                                    MetricCard(
                                        title = "চলতি মাসের মোট মুনাফা",
                                        value = "৳ ${currencyFormatter.format(overview.currentMonthProfit.toInt())}",
                                        color = IslamicGold,
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    MetricCard(
                                        title = "মোট সদস্য / সক্রিয়",
                                        value = "${overview.totalMembers} / ${overview.activeMembers}",
                                        color = TextPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    MetricCard(
                                        title = "চলমান / সম্পন্ন প্রকল্প",
                                        value = "${overview.ongoingProjectsCount} / ${overview.completedProjectsCount}",
                                        color = IslamicGreen,
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }

                        // Quick Actions Grid
                        item {
                            Text(
                                text = "প্রশাসনিক দ্রুত কার্যক্রম (Quick Actions)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }

                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ActionTile(
                                        icon = Icons.Default.Payments,
                                        title = "পেমেন্ট গেটওয়ে সেটিংস",
                                        subtitle = "বিকাশ/নগদ/রকেট নম্বর",
                                        onClick = { showPaymentSettingsDialog = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    ActionTile(
                                        icon = Icons.Default.FactCheck,
                                        title = "জমা অনুমোদন (${pendingDeposits.size})",
                                        subtitle = "সদস্যদের জমা লেজার",
                                        onClick = { activeAdminTab = 2 },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ActionTile(
                                        icon = Icons.Default.EditCalendar,
                                        title = "মাসিক হিসাব ও মুনাফা",
                                        subtitle = "মুনাফা ও আয়-ব্যয় সম্পাদন",
                                        onClick = { showEditFinancialDialog = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    ActionTile(
                                        icon = Icons.Default.PictureAsPdf,
                                        title = "মাসিক রিপোর্ট (PDF)",
                                        subtitle = "পিডিএফ ডাউনলোড ও শেয়ার",
                                        onClick = {
                                            PdfReportGenerator.generateAndShareMonthlyReport(
                                                context = context,
                                                overview = overview,
                                                members = members,
                                                projects = projects
                                            )
                                        },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ActionTile(
                                        icon = Icons.Default.HowToVote,
                                        title = "ভোট ও সিদ্ধান্ত প্রস্তাব",
                                        subtitle = "নতুন পোল তৈরি ও রেজাল্ট",
                                        onClick = { showCreatePollDialog = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    ActionTile(
                                        icon = Icons.Default.Savings,
                                        title = "মূলধন জমা এন্ট্রি",
                                        subtitle = "ম্যানুয়াল ক্যাশ গ্রহণ",
                                        onClick = { showAddCapitalDialog = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ActionTile(
                                        icon = Icons.Default.AddBusiness,
                                        title = "নতুন ব্যবসা প্রকল্প",
                                        subtitle = "বিনিয়োগ venture শুরু",
                                        onClick = { showAddProjectDialog = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    ActionTile(
                                        icon = Icons.Default.ReceiptLong,
                                        title = "প্রতিষ্ঠান খরচ যোগ",
                                        subtitle = "ব্যয় ও রশিদ এন্ট্রি",
                                        onClick = { showAddExpenseDialog = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    ActionTile(
                                        icon = Icons.Default.MonetizationOn,
                                        title = "মুনাফা বণ্টন তৈরি",
                                        subtitle = "প্রকল্পের লাভ বিতরণ",
                                        onClick = { showAddProfitDistributionDialog = true },
                                        modifier = Modifier.weight(1f)
                                    )
                                    ActionTile(
                                        icon = Icons.Default.ManageAccounts,
                                        title = "সদস্য পরিচালনা",
                                        subtitle = "অ্যাক্টিভেশন ও রোল",
                                        onClick = { activeAdminTab = 1 },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                1 -> {
                    // MEMBERS MANAGEMENT (Search, filter, status, role)
                    var searchQuery by remember { mutableStateOf("") }
                    val filteredMembers = members.filter {
                        it.name.contains(searchQuery, ignoreCase = true) ||
                                it.phone.contains(searchQuery) ||
                                it.email.contains(searchQuery, ignoreCase = true)
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("নাম, ফোন বা ইমেইল দিয়ে খুঁজুন...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = IslamicGreen) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )

                        if (filteredMembers.isEmpty()) {
                            EmptyStateView(
                                icon = Icons.Outlined.PersonSearch,
                                title = "কোনো সদস্য পাওয়া যায়নি",
                                subtitle = "অন্য কোনো শব্দ দিয়ে অনুসন্ধান করুন।"
                            )
                        } else {
                            LazyColumn(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filteredMembers) { member ->
                                    EmbossedCard(
                                        modifier = Modifier.fillMaxWidth(),
                                        onClick = { selectedMemberToManage = member }
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(44.dp)
                                                        .clip(CircleShape)
                                                        .background(IslamicGreenContainer),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    if (member.photoURL.isNotBlank()) {
                                                        AsyncImage(
                                                            model = member.photoURL,
                                                            contentDescription = member.name,
                                                            modifier = Modifier.fillMaxSize(),
                                                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                                        )
                                                    } else {
                                                        Icon(Icons.Default.Person, contentDescription = null, tint = IslamicGreen)
                                                    }
                                                }
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Column {
                                                    Text(member.name.ifBlank { "সদস্য" }, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                                    Text(member.phone, fontSize = 12.sp, color = TextMuted)
                                                    Text(
                                                        "মূলধন: ৳ ${currencyFormatter.format(member.totalCapitalContributed.toInt())}",
                                                        fontSize = 12.sp,
                                                        color = IslamicGreen,
                                                        fontWeight = FontWeight.Medium
                                                    )
                                                }
                                            }

                                            Column(horizontalAlignment = Alignment.End) {
                                                StatusBadge(
                                                    status = when (member.role) {
                                                        "super_admin" -> "সুপার অ্যাডমিন"
                                                        "admin" -> "অ্যাডমিন"
                                                        else -> "সদস্য"
                                                    }
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                StatusBadge(status = member.status)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // DEPOSIT APPROVALS LEDGER
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = IslamicGreenContainer.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        text = "সদস্যদের মূলধন জমাদান অনুমোদন লেজার",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = IslamicGreenDark
                                    )
                                    Text(
                                        text = "সদস্যরা বিকাশ, নগদ বা রকেটের মাধ্যমে টাকা পাঠিয়ে যে TrxID সাবমিট করেছেন তা যাচাই করে অনুমোদন বা বাতিল করুন।",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }

                        if (pendingDeposits.isEmpty()) {
                            item {
                                EmptyStateView(
                                    icon = Icons.Outlined.CheckCircle,
                                    title = "কোনো মুলতবি জমা নেই",
                                    subtitle = "সকল জমাদান অনুমোদিত হয়েছে। নতুন কোনো সদস্য মূলধন পাঠালে তা এখানে প্রদর্শিত হবে।"
                                )
                            }
                        } else {
                            items(pendingDeposits) { deposit ->
                                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = deposit.memberName.ifBlank { "সদস্য" },
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 16.sp,
                                                    color = TextPrimary
                                                )
                                                Text(
                                                    text = deposit.memberPhone,
                                                    fontSize = 12.sp,
                                                    color = TextSecondary
                                                )
                                            }
                                            StatusBadge(status = deposit.status)
                                        }

                                        Divider(color = BorderSubtle, thickness = 0.5.dp)

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = "জমার পরিমাণ:", fontSize = 13.sp, color = TextSecondary)
                                            Text(
                                                text = "৳ ${currencyFormatter.format(deposit.paidAmount.toInt())}",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = IslamicGreenDark
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = "পেমেন্ট মাধ্যম:", fontSize = 13.sp, color = TextSecondary)
                                            Text(
                                                text = deposit.paymentMethod,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TextPrimary
                                            )
                                        }

                                        if (deposit.senderNumber.isNotBlank()) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(text = "প্রেরক মোবাইল:", fontSize = 13.sp, color = TextSecondary)
                                                Text(
                                                    text = deposit.senderNumber,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    color = TextPrimary
                                                )
                                            }
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = "ট্রানজেকশন আইডি (TrxID):", fontSize = 13.sp, color = TextSecondary)
                                            Text(
                                                text = deposit.transactionId.ifBlank { "প্রযোজ্য নয়" },
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF1976D2)
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = "মাস ও তারিখ:", fontSize = 13.sp, color = TextSecondary)
                                            Text(
                                                text = "${deposit.monthYear} (${deposit.paymentDate})",
                                                fontSize = 12.sp,
                                                color = TextMuted
                                            )
                                        }

                                        if (deposit.transactionNote.isNotBlank()) {
                                            Text(
                                                text = "নোট: ${deposit.transactionNote}",
                                                fontSize = 12.sp,
                                                color = TextSecondary
                                            )
                                        }

                                        Divider(color = BorderSubtle, thickness = 0.5.dp)

                                        // Action buttons: Approve / Reject
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = {
                                                    viewModel.rejectDeposit(deposit) { res ->
                                                        if (res.isSuccess) {
                                                            Toast.makeText(context, "আবেদন বাতিল করা হয়েছে", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                },
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("বাতিল করুন", fontSize = 13.sp)
                                            }

                                            Button(
                                                onClick = {
                                                    viewModel.approveDeposit(deposit) { res ->
                                                        if (res.isSuccess) {
                                                            Toast.makeText(context, "মূলধন জমা সফলভাবে অনুমোদিত হয়েছে!", Toast.LENGTH_SHORT).show()
                                                        } else {
                                                            Toast.makeText(context, "ত্রুটি: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                                        }
                                                    }
                                                },
                                                shape = RoundedCornerShape(8.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("অনুমোদন করুন", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                3 -> {
                    // PAYMENT GATEWAY SETTINGS (Only Admin)
                    var bkashNumber by remember(paymentSettings) { mutableStateOf(paymentSettings.bkashNumber) }
                    var bkashActive by remember(paymentSettings) { mutableStateOf(paymentSettings.bkashActive) }
                    var bkashNote by remember(paymentSettings) { mutableStateOf(paymentSettings.bkashNote) }

                    var nagadNumber by remember(paymentSettings) { mutableStateOf(paymentSettings.nagadNumber) }
                    var nagadActive by remember(paymentSettings) { mutableStateOf(paymentSettings.nagadActive) }
                    var nagadNote by remember(paymentSettings) { mutableStateOf(paymentSettings.nagadNote) }

                    var rocketNumber by remember(paymentSettings) { mutableStateOf(paymentSettings.rocketNumber) }
                    var rocketActive by remember(paymentSettings) { mutableStateOf(paymentSettings.rocketActive) }
                    var rocketNote by remember(paymentSettings) { mutableStateOf(paymentSettings.rocketNote) }

                    var generalInstruction by remember(paymentSettings) { mutableStateOf(paymentSettings.generalInstruction) }

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = IslamicGreenContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "পেমেন্ট গেটওয়ে সেটিংস (অ্যাডমিন প্রিভিলেজ)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = IslamicGreenDark
                                )
                                Text(
                                    text = "শুধুমাত্র অ্যাডমিন এই নম্বর ও স্ট্যাটাস পরিবর্তন করতে পারবেন। সাধারণ সদস্যরা এই নম্বরে টাকা পাঠিয়ে ডিপোজিট সাবমিট করবেন।",
                                    fontSize = 12.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        // BKASH CONFIGURATION
                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("বিকাশ (bKash)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFE2136E))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (bkashActive) "সক্রিয়" else "নিষ্ক্রিয়", fontSize = 12.sp, color = if (bkashActive) IslamicGreen else TextMuted)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Switch(checked = bkashActive, onCheckedChange = { bkashActive = it })
                                    }
                                }
                                OutlinedTextField(
                                    value = bkashNumber,
                                    onValueChange = { bkashNumber = it },
                                    label = { Text("বিকাশ নম্বর") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = bkashNote,
                                    onValueChange = { bkashNote = it },
                                    label = { Text("বিকাশ নির্দেশিকা") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                            }
                        }

                        // NAGAD CONFIGURATION
                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("নগদ (Nagad)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFFF7941D))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (nagadActive) "সক্রিয়" else "নিষ্ক্রিয়", fontSize = 12.sp, color = if (nagadActive) IslamicGreen else TextMuted)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Switch(checked = nagadActive, onCheckedChange = { nagadActive = it })
                                    }
                                }
                                OutlinedTextField(
                                    value = nagadNumber,
                                    onValueChange = { nagadNumber = it },
                                    label = { Text("নগদ নম্বর (প্রযোজ্য হলে)") },
                                    placeholder = { Text("যেমন: 017XXXXXXXX") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = nagadNote,
                                    onValueChange = { nagadNote = it },
                                    label = { Text("নগদ নির্দেশিকা") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                            }
                        }

                        // ROCKET CONFIGURATION
                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("রকেট (Rocket)", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF8C3494))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (rocketActive) "সক্রিয়" else "নিষ্ক্রিয়", fontSize = 12.sp, color = if (rocketActive) IslamicGreen else TextMuted)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Switch(checked = rocketActive, onCheckedChange = { rocketActive = it })
                                    }
                                }
                                OutlinedTextField(
                                    value = rocketNumber,
                                    onValueChange = { rocketNumber = it },
                                    label = { Text("রকেট নম্বর (প্রযোজ্য হলে)") },
                                    placeholder = { Text("যেমন: 018XXXXXXXXX") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                                OutlinedTextField(
                                    value = rocketNote,
                                    onValueChange = { rocketNote = it },
                                    label = { Text("রকেট নির্দেশিকা") },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true
                                )
                            }
                        }

                        // GENERAL INSTRUCTION
                        EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("সাধারণ জমাদান নির্দেশিকা", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                OutlinedTextField(
                                    value = generalInstruction,
                                    onValueChange = { generalInstruction = it },
                                    label = { Text("নির্দেশনা বার্তা") },
                                    modifier = Modifier.fillMaxWidth(),
                                    minLines = 2
                                )
                            }
                        }

                        Button(
                            onClick = {
                                val updated = paymentSettings.copy(
                                    bkashNumber = bkashNumber.trim(),
                                    bkashActive = bkashActive,
                                    bkashNote = bkashNote.trim(),
                                    nagadNumber = nagadNumber.trim(),
                                    nagadActive = nagadActive,
                                    nagadNote = nagadNote.trim(),
                                    rocketNumber = rocketNumber.trim(),
                                    rocketActive = rocketActive,
                                    rocketNote = rocketNote.trim(),
                                    generalInstruction = generalInstruction.trim(),
                                    lastUpdated = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
                                )
                                viewModel.updatePaymentSettings(updated) { res ->
                                    if (res.isSuccess) {
                                        Toast.makeText(context, "পেমেন্ট সেটিংস সফলভাবে সংরক্ষিত হয়েছে!", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "ব্যর্থ: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("পেমেন্ট গেটওয়ে সেটিংস সংরক্ষণ করুন", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                4 -> {
                    // VOTING & DECISION MAKING MANAGEMENT
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "ভোট ও সিদ্ধান্ত গ্রহণ প্রশাসন",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = "সকল পোল ব্যবস্থাপনা ও ফলাফল পর্যবেক্ষণ",
                                        fontSize = 12.sp,
                                        color = TextSecondary
                                    )
                                }
                                Button(
                                    onClick = { showCreatePollDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("নতুন ভোট", fontSize = 12.sp)
                                }
                            }
                        }

                        if (votingPolls.isEmpty()) {
                            item {
                                EmptyStateView(
                                    icon = Icons.Outlined.HowToVote,
                                    title = "কোনো ভোট প্রস্তাব তৈরি করা হয়নি",
                                    subtitle = "গুরুত্বপূর্ণ সিদ্ধান্ত গ্রহণের জন্য নতুন পোল তৈরি করতে ওপরের বাটনে চাপুন।"
                                )
                            }
                        } else {
                            items(votingPolls) { poll ->
                                VotingPollCard(
                                    poll = poll,
                                    currentUserId = currentUser?.uid ?: "",
                                    isAdmin = true,
                                    onVote = { optionId ->
                                        viewModel.castVote(poll.id, optionId) { res ->
                                            if (res.isSuccess) {
                                                Toast.makeText(context, "ভোট গৃহীত হয়েছে!", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    },
                                    onClosePoll = {
                                        viewModel.closePollManually(poll.id) { res ->
                                            if (res.isSuccess) {
                                                Toast.makeText(context, "ভোটগ্রহণ সমাপ্ত করা হয়েছে", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                )
                            }
                        }
                    }
                }

                5 -> {
                    // EXPENSES MANAGEMENT
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "প্রতিষ্ঠানের যাবতীয় ব্যয় তালিকা",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Button(
                                    onClick = { showAddExpenseDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("খরচ যোগ করুন", fontSize = 12.sp)
                                }
                            }
                        }

                        if (expenses.isEmpty()) {
                            item {
                                EmptyStateView(
                                    icon = Icons.Outlined.ReceiptLong,
                                    title = "কোনো ব্যয়ের রেকর্ড নেই",
                                    subtitle = "ফাউন্ডেশনের খরচের এন্ট্রি এখানে যুক্ত করতে পারেন।"
                                )
                            }
                        } else {
                            items(expenses) { exp ->
                                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(exp.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                            Text("খাত: ${exp.category} | তারিখ: ${exp.date}", fontSize = 11.sp, color = TextMuted)
                                            if (exp.spentBy.isNotBlank()) {
                                                Text("ব্যয়কারী: ${exp.spentBy}", fontSize = 11.sp, color = TextSecondary)
                                            }
                                        }
                                        Text(
                                            text = "- ৳ ${currencyFormatter.format(exp.amount.toInt())}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = ErrorRed
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                6 -> {
                    // PROFIT DISTRIBUTION MANAGEMENT
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "মুনাফা বণ্টন বিবরণী",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Button(
                                    onClick = { showAddProfitDistributionDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("বণ্টন ঘোষণা", fontSize = 12.sp)
                                }
                            }
                        }

                        if (profitDistributions.isEmpty()) {
                            item {
                                EmptyStateView(
                                    icon = Icons.Outlined.Paid,
                                    title = "কোনো মুনাফা বণ্টন করা হয়নি",
                                    subtitle = "প্রকল্পের লাভ বণ্টন সম্পন্ন হলে তা এখানে তালিকাভুক্ত হবে।"
                                )
                            }
                        } else {
                            items(profitDistributions) { dist ->
                                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(dist.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            StatusBadge(status = dist.status)
                                        }
                                        Text(
                                            text = "সম্পর্কিত প্রকল্প: ${dist.projectName.ifBlank { "সাধারণ যৌথ ব্যবসা" }}",
                                            fontSize = 12.sp,
                                            color = TextSecondary
                                        )
                                        Divider(color = BorderSubtle, thickness = 0.5.dp)
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text("মোট বণ্টিত লাভ: ৳ ${currencyFormatter.format(dist.totalProfitAmount.toInt())}", fontWeight = FontWeight.Bold, color = IslamicGreenDark, fontSize = 13.sp)
                                            Text("তারিখ: ${dist.distributionDate}", fontSize = 11.sp, color = TextMuted)
                                        }
                                        Text("অংশগ্রহণকারী সদস্য সংখ্যা: ${dist.memberShares.size} জন", fontSize = 11.sp, color = TextMuted)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Add Expense Dialog
        if (showAddExpenseDialog) {
            AddExpenseDialog(
                projects = projects,
                onDismiss = { showAddExpenseDialog = false },
                onAdd = { newExp ->
                    viewModel.addExpense(newExp) { res ->
                        if (res.isSuccess) showAddExpenseDialog = false
                    }
                }
            )
        }

        // Add Profit Distribution Dialog
        if (showAddProfitDistributionDialog) {
            AddProfitDistributionDialog(
                projects = projects,
                members = members,
                onDismiss = { showAddProfitDistributionDialog = false },
                onAdd = { newDist ->
                    viewModel.addProfitDistribution(newDist) { res ->
                        if (res.isSuccess) showAddProfitDistributionDialog = false
                    }
                }
            )
        }

        // Add Capital Dialog
        if (showAddCapitalDialog) {
            AddCapitalContributionDialog(
                members = members,
                onDismiss = { showAddCapitalDialog = false },
                onAdd = { newContribution ->
                    viewModel.addCapitalContribution(newContribution) { res ->
                        if (res.isSuccess) showAddCapitalDialog = false
                    }
                }
            )
        }

        // Add Project Dialog
        if (showAddProjectDialog) {
            AddProjectDialog(
                onDismiss = { showAddProjectDialog = false },
                onAdd = { newProject ->
                    viewModel.addProject(newProject) { res ->
                        if (res.isSuccess) showAddProjectDialog = false
                    }
                }
            )
        }

        // Add Notice Dialog
        if (showAddNoticeDialog) {
            AddNoticeDialog(
                authorName = currentUser?.name ?: "অ্যাডমিন",
                onDismiss = { showAddNoticeDialog = false },
                onAdd = { newNotice ->
                    viewModel.addNotice(newNotice) { res ->
                        if (res.isSuccess) showAddNoticeDialog = false
                    }
                }
            )
        }

        // Member Management Dialog (Status, Role, Permissions)
        if (selectedMemberToManage != null) {
            ManageMemberDetailsDialog(
                member = selectedMemberToManage!!,
                isSuperAdmin = isSuperAdmin,
                onDismiss = { selectedMemberToManage = null },
                onUpdateStatus = { newStatus ->
                    viewModel.updateMemberStatus(selectedMemberToManage!!.uid, newStatus) { res ->
                        if (res.isSuccess) selectedMemberToManage = null
                    }
                },
                onUpdateRoleAndPermissions = { newRole, perms ->
                    viewModel.updateMemberRoleAndPermissions(selectedMemberToManage!!.uid, newRole, perms) { res ->
                        if (res.isSuccess) selectedMemberToManage = null
                    }
                }
            )
        }

        // Admin Payment Settings Dialog (Bkash, Nagad, Rocket)
        if (showPaymentSettingsDialog) {
            AdminPaymentSettingsDialog(
                currentSettings = paymentSettings,
                onDismiss = { showPaymentSettingsDialog = false },
                onSave = { updatedSettings ->
                    viewModel.updatePaymentSettings(updatedSettings) { res ->
                        if (res.isSuccess) {
                            showPaymentSettingsDialog = false
                            Toast.makeText(context, "পেমেন্ট সেটিংস সফলভাবে হালনাগাদ করা হয়েছে", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "ত্রুটি: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }

        // Admin Edit Financial Overview & Monthly Profit Dialog
        if (showEditFinancialDialog) {
            AdminEditFinancialDialog(
                overview = overview,
                onDismiss = { showEditFinancialDialog = false },
                onSave = { updatedOverview ->
                    viewModel.updateFinancialOverview(updatedOverview) { res ->
                        if (res.isSuccess) {
                            showEditFinancialDialog = false
                            Toast.makeText(context, "আর্থিক সারাংশ ও মুনাফা সফলভাবে সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "ত্রুটি: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }

        // Create Voting Poll Dialog
        if (showCreatePollDialog) {
            CreateVotingPollDialog(
                onDismiss = { showCreatePollDialog = false },
                onCreate = { newPoll ->
                    viewModel.createVotingPoll(newPoll) { res ->
                        if (res.isSuccess) {
                            showCreatePollDialog = false
                            Toast.makeText(context, "ভোট সফলভাবে তৈরি ও সক্রিয় করা হয়েছে", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "ত্রুটি: ${res.exceptionOrNull()?.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun MetricCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    EmbossedCard(modifier = modifier) {
        Column {
            Text(text = title, fontSize = 11.sp, color = TextSecondary, maxLines = 1)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun ActionTile(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    EmbossedCard(
        modifier = modifier,
        onClick = onClick
    ) {
        Column {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = IslamicGreenContainer,
                modifier = Modifier.size(36.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = IslamicGreen, modifier = Modifier.size(20.dp))
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = TextPrimary)
            Text(text = subtitle, fontSize = 11.sp, color = TextMuted)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddExpenseDialog(
    projects: List<BusinessProject>,
    onDismiss: () -> Unit,
    onAdd: (OrganizationExpense) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("সাধারণ প্রশাসনিক খরচ") }
    var amount by remember { mutableStateOf("") }
    var spentBy by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var date by remember {
        mutableStateOf(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
    }
    var selectedProject by remember { mutableStateOf<BusinessProject?>(null) }
    var expandedProjectDropdown by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন খরচ এন্ট্রি", fontWeight = FontWeight.Bold, color = IslamicGreenDark) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("খরচের শিরোনাম (Title)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("খরচের পরিমাণ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("ক্যাটাগরি (অফিস খরচ, প্রকল্প খরচ, ইত্যাদি)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = spentBy,
                    onValueChange = { spentBy = it },
                    label = { Text("ব্যয়কারীর নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = date,
                    onValueChange = { date = it },
                    label = { Text("তারিখ (দিন/মাস/বছর)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("নোট বা রসিদ রেফারেন্স") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank() && amt > 0) {
                        onAdd(
                            OrganizationExpense(
                                title = title.trim(),
                                category = category.trim(),
                                amount = amt,
                                date = date.trim(),
                                spentBy = spentBy.trim(),
                                projectId = selectedProject?.id ?: "",
                                note = note.trim()
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddProfitDistributionDialog(
    projects: List<BusinessProject>,
    members: List<UserProfile>,
    onDismiss: () -> Unit,
    onAdd: (ProfitDistribution) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var totalProfitAmount by remember { mutableStateOf("") }
    var distributionDate by remember {
        mutableStateOf(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date()))
    }
    var selectedProject by remember { mutableStateOf<BusinessProject?>(projects.firstOrNull()) }
    var expandedProj by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন মুনাফা বণ্টন তৈরি", fontWeight = FontWeight.Bold, color = IslamicGreenDark) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("বণ্টনের শিরোনাম (যেমন: ৩য় কোয়ার্টার ট্রেডিং মুনাফা)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                // Project Selector
                ExposedDropdownMenuBox(
                    expanded = expandedProj,
                    onExpandedChange = { expandedProj = !expandedProj }
                ) {
                    OutlinedTextField(
                        value = selectedProject?.title ?: "প্রকল্প নির্বাচন করুন",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("সংশ্লিষ্ট প্রকল্প") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedProj) },
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedProj,
                        onDismissRequest = { expandedProj = false }
                    ) {
                        projects.forEach { p ->
                            DropdownMenuItem(
                                text = { Text(p.title) },
                                onClick = {
                                    selectedProject = p
                                    expandedProj = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = totalProfitAmount,
                    onValueChange = { totalProfitAmount = it },
                    label = { Text("মোট বণ্টনযোগ্য মুনাফার পরিমাণ (৳)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = distributionDate,
                    onValueChange = { distributionDate = it },
                    label = { Text("বণ্টনের তারিখ") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "মোট সক্রিয় সদস্য সংখ্যা: ${members.count { it.status == "active" }} জন। মোট মুনাফা সক্রিয় সদস্যদের মূলধনের অনুপাত অনুযায়ী সমবণ্টন করা হবে।",
                    fontSize = 11.sp,
                    color = TextMuted,
                    lineHeight = 16.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val total = totalProfitAmount.toDoubleOrNull() ?: 0.0
                    val activeMembers = members.filter { it.status == "active" }
                    if (title.isNotBlank() && total > 0 && activeMembers.isNotEmpty()) {
                        // Calculate member shares by ratio of their capital or equal share
                        val totalContributed = activeMembers.sumOf { it.totalCapitalContributed }
                        val sharesMap = mutableMapOf<String, Double>()

                        if (totalContributed > 0) {
                            activeMembers.forEach { m ->
                                val shareRatio = m.totalCapitalContributed / totalContributed
                                sharesMap[m.uid] = total * shareRatio
                            }
                        } else {
                            val perMember = total / activeMembers.size
                            activeMembers.forEach { m ->
                                sharesMap[m.uid] = perMember
                            }
                        }

                        onAdd(
                            ProfitDistribution(
                                title = title.trim(),
                                projectId = selectedProject?.id ?: "",
                                projectName = selectedProject?.title ?: "সাধারণ",
                                totalProfitAmount = total,
                                distributionDate = distributionDate.trim(),
                                memberShares = sharesMap,
                                status = "সম্পন্ন"
                            )
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("বণ্টন নিশ্চিত করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}

@Composable
fun ManageMemberDetailsDialog(
    member: UserProfile,
    isSuperAdmin: Boolean,
    onDismiss: () -> Unit,
    onUpdateStatus: (String) -> Unit,
    onUpdateRoleAndPermissions: (String, List<String>) -> Unit
) {
    var selectedRole by remember { mutableStateOf(member.role) }
    var canManageCapital by remember { mutableStateOf(member.permissions.contains("manage_capital")) }
    var canManageProjects by remember { mutableStateOf(member.permissions.contains("manage_projects")) }
    var canManageNotices by remember { mutableStateOf(member.permissions.contains("manage_notices")) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(member.name.ifBlank { "সদস্য বিবরণ" }, fontWeight = FontWeight.Bold, color = IslamicGreenDark) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                InfoRow(Icons.Default.Phone, "ফোন", member.phone)
                InfoRow(Icons.Default.Email, "ইমেইল", member.email)
                InfoRow(Icons.Default.Savings, "মোট মূলধন", "৳ ${member.totalCapitalContributed.toInt()}")
                InfoRow(Icons.Default.Badge, "পদবি", member.role)

                Divider(color = BorderSubtle)

                Text(text = "সদস্য স্ট্যাটাস:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onUpdateStatus("active") },
                        colors = ButtonDefaults.buttonColors(containerColor = if (member.status == "active") IslamicGreen else Color.Gray),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("সক্রিয় করুন", fontSize = 12.sp)
                    }

                    Button(
                        onClick = { onUpdateStatus("inactive") },
                        colors = ButtonDefaults.buttonColors(containerColor = if (member.status == "inactive") ErrorRed else Color.Gray),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("নিষ্ক্রিয় করুন", fontSize = 12.sp)
                    }
                }

                // Super Admin specific role and permissions assignment
                if (isSuperAdmin) {
                    Divider(color = BorderSubtle)
                    Text(
                        text = "সুপার অ্যাডমিন ক্ষমতা (Role & Permissions):",
                        fontWeight = FontWeight.Bold,
                        color = IslamicGreenDark,
                        fontSize = 13.sp
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedRole == "member",
                            onClick = { selectedRole = "member" },
                            label = { Text("সাধারণ সদস্য") }
                        )
                        FilterChip(
                            selected = selectedRole == "admin",
                            onClick = { selectedRole = "admin" },
                            label = { Text("অ্যাডমিন") }
                        )
                    }

                    if (selectedRole == "admin") {
                        Text("অনুমোদিত পারমিশনসমূহ:", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = canManageCapital, onCheckedChange = { canManageCapital = it })
                            Text("মূলধন পরিচালনা (Manage Capital)", fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = canManageProjects, onCheckedChange = { canManageProjects = it })
                            Text("প্রকল্প পরিচালনা (Manage Projects)", fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = canManageNotices, onCheckedChange = { canManageNotices = it })
                            Text("নোটিশ প্রকাশ (Manage Notices)", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                val perms = mutableListOf<String>()
                                if (canManageCapital) perms.add("manage_capital")
                                if (canManageProjects) perms.add("manage_projects")
                                if (canManageNotices) perms.add("manage_notices")
                                onUpdateRoleAndPermissions("admin", perms)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = IslamicGold),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("অ্যাডমিন রোল ও পারমিশন নিশ্চিত করুন")
                        }
                    } else if (member.role == "admin" && selectedRole == "member") {
                        Button(
                            onClick = {
                                onUpdateRoleAndPermissions("member", emptyList())
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("অ্যাডমিন পদবি অপসারণ করুন")
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("বন্ধ করুন") }
        }
    )
}
