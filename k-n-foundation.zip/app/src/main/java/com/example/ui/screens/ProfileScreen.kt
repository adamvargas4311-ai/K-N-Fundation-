package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.ImageUploadService
import com.example.model.UserProfile
import com.example.ui.MainViewModel
import com.example.ui.components.EmbossedButton
import com.example.ui.components.EmbossedCard
import com.example.ui.components.ImagePickerAndUploader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

@Composable
fun ProfileScreen(
    viewModel: MainViewModel,
    onSignOut: () -> Unit,
    onNavigateToAuth: () -> Unit = {}
) {
    val currentUser by viewModel.currentUserProfile.collectAsState()
    val myProfits by viewModel.myReceivedProfits.collectAsState()
    val currencyFormatter = remember { NumberFormat.getNumberInstance(Locale.US) }

    var showEditDialog by remember { mutableStateOf(false) }
    var showImageHostConfigDialog by remember { mutableStateOf(false) }

    val user = currentUser ?: UserProfile()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        if (currentUser == null) {
            // GUEST PROFILE HEADER
            item {
                EmbossedCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = Color.White
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(84.dp)
                                .clip(CircleShape)
                                .background(IslamicGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PersonOutline,
                                contentDescription = null,
                                tint = IslamicGreen,
                                modifier = Modifier.size(44.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "অতিথি ব্যবহারকারী (Guest Visitor)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "আপনি বর্তমানে কোনো অ্যাকাউন্টে প্রবেশ করেননি। যৌথ মূলধনে অংশ নিতে ও সদস্য হিসেবে সকল আর্থিক সুযোগ-সুবিধা পেতে অ্যাকাউন্ট তৈরি করুন অথবা লগইন করুন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        EmbossedButton(
                            text = "লগইন বা অ্যাকাউন্ট তৈরি করুন",
                            onClick = onNavigateToAuth,
                            icon = Icons.Default.Login,
                            modifier = Modifier.fillMaxWidth(),
                            testTag = "guest_login_button"
                        )
                    }
                }
            }
        } else {
            // User Profile Header
            item {
                EmbossedCard(
                    modifier = Modifier.fillMaxWidth(),
                    backgroundColor = Color.White
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .clip(CircleShape)
                                .background(IslamicGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            if (user.photoURL.isNotBlank()) {
                                AsyncImage(
                                    model = user.photoURL,
                                    contentDescription = user.name,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Image(
                                    painter = painterResource(id = R.drawable.org_logo),
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = user.name.ifBlank { "সম্মানিত সদস্য" },
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusBadge(
                                status = when (user.role) {
                                    "super_admin" -> "সুপার অ্যাডমিন"
                                    "admin" -> "অ্যাডমিন"
                                    else -> "সাধারণ সদস্য"
                                }
                            )
                            StatusBadge(status = if (user.status == "active") "সক্রিয় সদস্য" else "নিষ্ক্রিয়")
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedButton(
                            onClick = { showEditDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Outlined.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("প্রোফাইল সম্পাদন", fontSize = 12.sp)
                        }
                    }
                }
            }

        // Capital & Share Overview Card
        item {
            EmbossedCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = IslamicGreenContainer.copy(alpha = 0.5f)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "আমার অংশীদারিত্ব ও মূলধন",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = IslamicGreenDark
                    )
                    Divider(color = BorderSubtle)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("মোট জমাকৃত মূলধন", fontSize = 12.sp, color = TextSecondary)
                            Text(
                                "৳ ${currencyFormatter.format(user.totalCapitalContributed.toInt())}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = IslamicGreenDark
                            )
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("মুনাফা বণ্টনের হার", fontSize = 12.sp, color = TextSecondary)
                            Text(
                                "${user.profitSharePercentage}%",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = IslamicGold
                            )
                        }
                    }
                }
            }
        }

        // Contact & Personal Information Card
        item {
            EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "যোগাযোগ ও বিবরণ",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = TextPrimary
                    )
                    Divider(color = BorderSubtle)

                    InfoRow(Icons.Outlined.Phone, "মোবাইল নম্বর", user.phone.ifBlank { "দেওয়া হয়নি" })
                    InfoRow(Icons.Outlined.Email, "ইমেইল", user.email)
                    InfoRow(Icons.Outlined.Home, "বর্তমান ঠিকানা", user.address.ifBlank { "দেওয়া হয়নি" })
                    InfoRow(Icons.Outlined.CalendarMonth, "যোগদানের তারিখ", user.joiningDate.ifBlank { "২০২৬" })
                    InfoRow(Icons.Outlined.Fingerprint, "সদস্য আইডি (UID)", user.uid.take(12) + "...")
                }
            }
        }

        // Received Profit History Section
        item {
            Text(
                text = "আমার প্রাপ্ত মুনাফা বিতরণ ইতিহাস",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = TextPrimary
            )
        }

        if (myProfits.isEmpty()) {
            item {
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "এখন পর্যন্ত কোনো মুনাফা বণ্টন রেকর্ড পাওয়া যায়নি। ব্যবসা প্রকল্প হতে মুনাফা ঘোষণা হলে এখানে যুক্ত হবে।",
                        fontSize = 13.sp,
                        color = TextMuted
                    )
                }
            }
        } else {
            items(myProfits) { dist ->
                val myShare = dist.memberShares[user.uid] ?: 0.0
                EmbossedCard(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(dist.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text(
                                "তারিখ: ${dist.distributionDate} | প্রকল্প: ${dist.projectName.ifBlank { "সাধারণ" }}",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                        }
                        Text(
                            text = "+ ৳ ${currencyFormatter.format(myShare.toInt())}",
                            color = IslamicGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }
    }

        // Foundation Sharia Principles Information
        item {
            EmbossedCard(
                modifier = Modifier.fillMaxWidth(),
                backgroundColor = MaterialTheme.colorScheme.surface
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = IslamicGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "শরীয়াহসম্মত নীতিমালার অঙ্গীকার",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = IslamicGreenDark
                        )
                    }
                    Text(
                        text = "খতমে নবুয়াত ফাউন্ডেশন সকল প্রকার সুদ, অনিশ্চয়তা (গারার) ও হারাম লেনদেনমুক্ত যৌথ মূলধনের ভিত্তিতে মোদারাবা ও মুশারাকা নীতিমালা মেনে ব্যবসা পরিচালনা করে।",
                        fontSize = 12.sp,
                        color = TextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Image Hosting Setting (for Admins)
        if (user.isAdmin()) {
            item {
                OutlinedButton(
                    onClick = { showImageHostConfigDialog = true },
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.CloudSync, contentDescription = null, tint = IslamicGreen)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("বহিরাগত ইমেজ হোস্টিং সেটিংস (CDN Config)", color = IslamicGreen)
                }
            }
        }

        // Sign Out Button
        if (currentUser != null) {
            item {
                EmbossedButton(
                    text = "অ্যাকাউন্ট হতে লগআউট করুন",
                    onClick = {
                        viewModel.signOut()
                        onSignOut()
                    },
                    icon = Icons.Default.Logout,
                    isPrimary = false,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "logout_button"
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showEditDialog) {
        EditProfileDialog(
            user = user,
            onDismiss = { showEditDialog = false },
            onSave = { updated ->
                viewModel.updateUserProfile(updated) { res ->
                    if (res.isSuccess) {
                        showEditDialog = false
                    }
                }
            }
        )
    }

    if (showImageHostConfigDialog) {
        ImageHostConfigDialog(
            onDismiss = { showImageHostConfigDialog = false }
        )
    }
}

@Composable
fun InfoRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = IslamicGreen, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Text(text = "$label: ", fontSize = 13.sp, color = TextSecondary)
        Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
    }
}

@Composable
fun EditProfileDialog(
    user: UserProfile,
    onDismiss: () -> Unit,
    onSave: (UserProfile) -> Unit
) {
    var name by remember { mutableStateOf(user.name) }
    var phone by remember { mutableStateOf(user.phone) }
    var address by remember { mutableStateOf(user.address) }
    var photoUrl by remember { mutableStateOf(user.photoURL) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("প্রোফাইল সম্পাদন", fontWeight = FontWeight.Bold, color = IslamicGreenDark) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("নাম") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("মোবাইল নম্বর") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("ঠিকানা") },
                    modifier = Modifier.fillMaxWidth()
                )

                ImagePickerAndUploader(
                    currentImageUrl = photoUrl,
                    onImageUrlSelected = { photoUrl = it },
                    label = "প্রোফাইল ছবি পরিবর্তন"
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onSave(
                        user.copy(
                            name = name.trim(),
                            phone = phone.trim(),
                            address = address.trim(),
                            photoURL = photoUrl.trim()
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}

@Composable
fun ImageHostConfigDialog(
    onDismiss: () -> Unit
) {
    var apiKey by remember { mutableStateOf(ImageUploadService.customApiKey) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ইমেজ হোস্টিং এপিআই (ImgBB/CDN)", fontWeight = FontWeight.Bold, color = IslamicGreenDark) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "ফটো আপলোডের জন্য বহিরাগত CDN এপিআই কী কনফিগার করুন (ফায়ারবেস স্টোরেজ ব্যবহৃত হচ্ছে না)।",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    label = { Text("API Key") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    ImageUploadService.customApiKey = apiKey.trim()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(containerColor = IslamicGreen)
            ) {
                Text("সেভ করুন")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
