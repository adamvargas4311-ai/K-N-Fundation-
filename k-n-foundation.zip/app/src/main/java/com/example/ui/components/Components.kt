package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.ImageUploadService
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun EmbossedCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = MaterialTheme.colorScheme.surface,
    borderColor: Color = MaterialTheme.colorScheme.outline,
    cornerRadius: Dp = 16.dp,
    elevation: Dp = 2.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit
) {
    val clickableModifier = if (onClick != null) {
        Modifier.clickable(onClick = onClick)
    } else Modifier

    Surface(
        modifier = modifier
            .shadow(
                elevation = elevation,
                shape = RoundedCornerShape(cornerRadius),
                ambientColor = IslamicGreenDark.copy(alpha = 0.08f),
                spotColor = IslamicGreenDark.copy(alpha = 0.12f)
            )
            .then(clickableModifier),
        shape = RoundedCornerShape(cornerRadius),
        color = backgroundColor,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Box(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun EmbossedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    isPrimary: Boolean = true,
    testTag: String = "embossed_button"
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(if (isPressed) 0.96f else 1f, label = "button_scale")

    val bgBrush = if (isPrimary) {
        Brush.horizontalGradient(
            colors = listOf(IslamicGreen, IslamicGreenLight)
        )
    } else {
        Brush.horizontalGradient(
            colors = listOf(MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.surface)
        )
    }

    val contentColor = if (isPrimary) Color.White else IslamicGreen
    val borderColor = if (isPrimary) IslamicGreenDark else IslamicGreen

    Surface(
        modifier = modifier
            .scale(scale)
            .heightIn(min = 48.dp)
            .shadow(
                elevation = if (isPressed) 1.dp else 3.dp,
                shape = RoundedCornerShape(12.dp),
                ambientColor = IslamicGreen.copy(alpha = 0.2f)
            )
            .testTag(testTag),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.2.dp, borderColor),
        color = Color.Transparent,
        enabled = enabled && !isLoading,
        onClick = onClick,
        interactionSource = interactionSource
    ) {
        Box(
            modifier = Modifier
                .background(bgBrush)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(20.dp),
                    color = contentColor,
                    strokeWidth = 2.dp
                )
            } else {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (icon != null) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = contentColor,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = text,
                        color = contentColor,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
fun StatusBadge(
    status: String,
    modifier: Modifier = Modifier
) {
    val (bg, textColor) = when (status) {
        "চলমান", "active", "অনুমোদিত", "সম্পন্ন" -> Pair(IslamicGreenContainer, IslamicGreen)
        "জরুরি" -> Pair(ErrorRed.copy(alpha = 0.12f), ErrorRed)
        "বাতিল", "inactive" -> Pair(Color(0xFFF3F4F6), Color(0xFF6B7280))
        else -> Pair(IslamicGoldContainer, IslamicGold)
    }

    Surface(
        modifier = modifier,
        color = bg,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(0.8.dp, textColor.copy(alpha = 0.3f))
    ) {
        Text(
            text = status,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun EmptyStateView(
    icon: ImageVector,
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    actionButtonText: String? = null,
    onActionClick: (() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            shape = CircleShape,
            color = IslamicGreenContainer.copy(alpha = 0.7f),
            modifier = Modifier.size(72.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = IslamicGreen,
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = TextMuted,
            textAlign = TextAlign.Center,
            lineHeight = 20.sp
        )

        if (actionButtonText != null && onActionClick != null) {
            Spacer(modifier = Modifier.height(18.dp))
            EmbossedButton(
                text = actionButtonText,
                onClick = onActionClick,
                isPrimary = false
            )
        }
    }
}

@Composable
fun ImagePickerAndUploader(
    currentImageUrl: String,
    onImageUrlSelected: (String) -> Unit,
    modifier: Modifier = Modifier,
    label: String = "ছবি সংযুক্ত করুন"
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var isUploading by remember { mutableStateOf(false) }
    var uploadError by remember { mutableStateOf<String?>(null) }
    var manualUrlInput by remember { mutableStateOf("") }
    var showUrlDialog by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            coroutineScope.launch {
                isUploading = true
                uploadError = null
                val result = ImageUploadService.compressAndUploadImage(context, uri)
                isUploading = false
                if (result.isSuccess) {
                    onImageUrlSelected(result.getOrNull().orEmpty())
                } else {
                    uploadError = result.exceptionOrNull()?.localizedMessage ?: "আপলোড ব্যর্থ হয়েছে"
                }
            }
        }
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary,
            fontWeight = FontWeight.Medium
        )
        Spacer(modifier = Modifier.height(8.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Preview box
            Box(
                modifier = Modifier
                    .size(70.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(IslamicGreenContainer.copy(alpha = 0.5f))
                    .shadow(1.dp, RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                if (currentImageUrl.isNotBlank()) {
                    AsyncImage(
                        model = currentImageUrl,
                        contentDescription = "নির্বাচিত ছবি",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.Outlined.Image,
                        contentDescription = null,
                        tint = IslamicGreen,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        enabled = !isUploading,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = IslamicGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        if (isUploading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("আপলোড হচ্ছে...", fontSize = 12.sp)
                        } else {
                            Icon(
                                imageVector = Icons.Default.CloudUpload,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("গ্যালারি হতে আপলোড", fontSize = 12.sp)
                        }
                    }

                    OutlinedButton(
                        onClick = { showUrlDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Link,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = IslamicGreen
                        )
                    }
                }

                if (uploadError != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = uploadError ?: "",
                        color = ErrorRed,
                        fontSize = 11.sp
                    )
                }
            }
        }

        if (showUrlDialog) {
            AlertDialog(
                onDismissRequest = { showUrlDialog = false },
                title = { Text("ছবির লিঙ্ক (URL) দিন") },
                text = {
                    OutlinedTextField(
                        value = manualUrlInput,
                        onValueChange = { manualUrlInput = it },
                        placeholder = { Text("https://example.com/image.jpg") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            if (manualUrlInput.isNotBlank()) {
                                onImageUrlSelected(manualUrlInput.trim())
                            }
                            showUrlDialog = false
                        }
                    ) {
                        Text("সংরক্ষণ করুন")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showUrlDialog = false }) {
                        Text("বাতিল")
                    }
                }
            )
        }
    }
}

@Composable
fun OrganizationHeaderBar(
    onNotificationsClick: () -> Unit,
    onMessagesClick: () -> Unit,
    unreadNotificationsCount: Int = 0,
    isGuest: Boolean = false,
    onAuthClick: () -> Unit = {},
    onLogoClick: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding(),
        color = Color.White,
        shadowElevation = 2.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Organization Logo with Ornate Golden Ring
            Surface(
                shape = CircleShape,
                border = BorderStroke(1.5.dp, IslamicGold),
                shadowElevation = 2.dp,
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .clickable(onClick = onLogoClick)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.org_logo),
                    contentDescription = "K N Foundation Logo",
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "খতমে নবুয়াত ফাউন্ডেশন",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = IslamicGreenDark,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (isGuest) "অতিথি ভিজিটর" else "K N Foundation",
                    style = MaterialTheme.typography.labelSmall,
                    color = IslamicGold,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (isGuest) {
                // Prominent login chip for guests
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = IslamicGreenContainer,
                    border = BorderStroke(1.dp, IslamicGreen.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .clickable(onClick = onAuthClick)
                        .testTag("header_login_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Login,
                            contentDescription = "লগইন",
                            tint = IslamicGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "লগইন",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = IslamicGreen
                        )
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
            }

            // Message Action
            IconButton(
                onClick = onMessagesClick,
                modifier = Modifier.size(38.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Chat,
                    contentDescription = "বার্তা",
                    tint = IslamicGreen
                )
            }

            // Notification Action with Badge
            Box(contentAlignment = Alignment.TopEnd) {
                IconButton(
                    onClick = onNotificationsClick,
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = "বিজ্ঞপ্তি",
                        tint = IslamicGreen
                    )
                }
                if (unreadNotificationsCount > 0) {
                    Surface(
                        shape = CircleShape,
                        color = ErrorRed,
                        modifier = Modifier
                            .padding(top = 4.dp, end = 4.dp)
                            .size(16.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = if (unreadNotificationsCount > 9) "9+" else unreadNotificationsCount.toString(),
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}
