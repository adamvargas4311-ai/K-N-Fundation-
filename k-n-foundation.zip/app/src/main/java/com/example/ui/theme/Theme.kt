package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = IslamicGreen,
    onPrimary = SurfaceLight,
    primaryContainer = IslamicGreenContainer,
    onPrimaryContainer = IslamicGreenDark,
    secondary = IslamicGold,
    onSecondary = SurfaceLight,
    secondaryContainer = IslamicGoldContainer,
    onSecondaryContainer = IslamicGreenDark,
    tertiary = IslamicGreenLight,
    background = BackgroundLight,
    onBackground = TextPrimary,
    surface = SurfaceLight,
    onSurface = TextPrimary,
    surfaceVariant = SurfaceCard,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    error = ErrorRed,
    onError = SurfaceLight
)

private val DarkColorScheme = darkColorScheme(
    primary = IslamicGreenLight,
    onPrimary = SurfaceLight,
    primaryContainer = IslamicGreenDark,
    onPrimaryContainer = IslamicGreenContainer,
    secondary = IslamicGoldLight,
    onSecondary = SurfaceLight,
    secondaryContainer = IslamicGreenDark,
    onSecondaryContainer = IslamicGoldContainer,
    tertiary = IslamicGold,
    background = TextPrimary,
    onBackground = BackgroundLight,
    surface = IslamicGreenDark,
    onSurface = BackgroundLight,
    surfaceVariant = TextPrimary,
    onSurfaceVariant = TextMuted,
    outline = TextSecondary,
    error = ErrorRed,
    onError = SurfaceLight
)

@Composable
fun KNFoundationTheme(
    darkTheme: Boolean = false, // Enforce light theme only as per user request
    content: @Composable () -> Unit
) {
    // Always use LightColorScheme - white UI aesthetic only
    val colorScheme = LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window ?: return@SideEffect
            window.statusBarColor = SurfaceLight.toArgb()
            window.navigationBarColor = SurfaceLight.toArgb()
            val insetsController = WindowCompat.getInsetsController(window, view)
            insetsController.isAppearanceLightStatusBars = true
            insetsController.isAppearanceLightNavigationBars = true
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
