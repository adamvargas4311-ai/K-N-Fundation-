package com.example.data

import com.example.model.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseRepository {

    val auth: FirebaseAuth = FirebaseAuth.getInstance()
    val firestore: FirebaseFirestore = FirebaseFirestore.getInstance()

    companion object {
        const val SUPER_ADMIN_UID = "hgN2L87pd4OaKWQTTBQQNfTq4HZ2"
        const val ORG_ID = "kn_foundation"
    }

    val currentAuthUser: FirebaseUser?
        get() = auth.currentUser

    // Observe user authentication state
    fun observeAuthState(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { authInstance ->
            trySend(authInstance.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    // Observe current user profile from Firestore
    fun observeUserProfile(uid: String): Flow<UserProfile?> = callbackFlow {
        val docRef = firestore.collection("users").document(uid)
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(null)
                return@addSnapshotListener
            }
            if (snapshot != null && snapshot.exists()) {
                val profile = snapshot.toObject(UserProfile::class.java)
                // Enforce Super Admin UID check
                if (uid == SUPER_ADMIN_UID && profile?.role != "super_admin") {
                    trySend(profile?.copy(role = "super_admin"))
                } else {
                    trySend(profile)
                }
            } else {
                trySend(null)
            }
        }
        awaitClose { listener.remove() }
    }

    // Sign in with email and password
    suspend fun signIn(email: String, pass: String): Result<FirebaseUser> {
        return try {
            val result = auth.signInWithEmailAndPassword(email.trim(), pass).await()
            val user = result.user ?: throw Exception("ইউজার পাওয়া যায়নি")
            // Ensure profile document exists
            val doc = firestore.collection("users").document(user.uid).get().await()
            if (!doc.exists()) {
                val isSuperAdmin = user.uid == SUPER_ADMIN_UID
                val newProfile = UserProfile(
                    uid = user.uid,
                    name = user.displayName ?: email.substringBefore("@"),
                    email = user.email ?: email,
                    role = if (isSuperAdmin) "super_admin" else "member",
                    permissions = if (isSuperAdmin) listOf("all") else emptyList(),
                    status = "active",
                    organizationId = ORG_ID
                )
                firestore.collection("users").document(user.uid).set(newProfile).await()
            }
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Sign in with Google Auth ID Token
    suspend fun signInWithGoogleCredential(idToken: String): Result<FirebaseUser> {
        return try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val result = auth.signInWithCredential(credential).await()
            val user = result.user ?: throw Exception("Google সাইন ইন ব্যর্থ হয়েছে")
            val doc = firestore.collection("users").document(user.uid).get().await()
            if (!doc.exists()) {
                val isSuperAdmin = user.uid == SUPER_ADMIN_UID
                val newProfile = UserProfile(
                    uid = user.uid,
                    name = user.displayName?.takeIf { it.isNotBlank() } ?: (user.email?.substringBefore("@") ?: "সদস্য"),
                    email = user.email ?: "",
                    phone = user.phoneNumber ?: "",
                    photoURL = user.photoUrl?.toString() ?: "",
                    role = if (isSuperAdmin) "super_admin" else "member",
                    permissions = if (isSuperAdmin) listOf("all") else emptyList(),
                    status = "active",
                    organizationId = ORG_ID
                )
                firestore.collection("users").document(user.uid).set(newProfile).await()
            }
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Sign up new user. Role is ALWAYS 'member' unless matching Super Admin UID
    suspend fun signUp(
        name: String,
        email: String,
        pass: String,
        phone: String,
        photoUrl: String
    ): Result<FirebaseUser> {
        return try {
            val result = auth.createUserWithEmailAndPassword(email.trim(), pass).await()
            val user = result.user ?: throw Exception("অ্যাকাউন্ট তৈরিতে সমস্যা হয়েছে")
            val isSuperAdmin = user.uid == SUPER_ADMIN_UID
            val profile = UserProfile(
                uid = user.uid,
                name = name.trim(),
                email = email.trim(),
                phone = phone.trim(),
                photoURL = photoUrl.trim(),
                organizationId = ORG_ID,
                role = if (isSuperAdmin) "super_admin" else "member",
                permissions = if (isSuperAdmin) listOf("all") else emptyList(),
                status = "active",
                joiningDate = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date()),
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            firestore.collection("users").document(user.uid).set(profile).await()
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun signOut() {
        auth.signOut()
    }

    // Observe all members in organization
    fun observeMembers(): Flow<List<UserProfile>> = callbackFlow {
        val query = firestore.collection("users")
            .whereEqualTo("organizationId", ORG_ID)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(UserProfile::class.java) } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    // Super admin updates member role & permissions
    suspend fun updateMemberRoleAndPermissions(
        targetUid: String,
        newRole: String,
        newPermissions: List<String>
    ): Result<Unit> {
        return try {
            if (targetUid == SUPER_ADMIN_UID && newRole != "super_admin") {
                return Result.failure(Exception("সুপার অ্যাডমিনের পদবি পরিবর্তন করা সম্ভব নয়"))
            }
            firestore.collection("users").document(targetUid).update(
                mapOf(
                    "role" to newRole,
                    "permissions" to newPermissions,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Update member status (active / inactive)
    suspend fun updateMemberStatus(targetUid: String, newStatus: String): Result<Unit> {
        return try {
            firestore.collection("users").document(targetUid).update(
                mapOf(
                    "status" to newStatus,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Update user profile details
    suspend fun updateUserProfile(profile: UserProfile): Result<Unit> {
        return try {
            firestore.collection("users").document(profile.uid).update(
                mapOf(
                    "name" to profile.name,
                    "phone" to profile.phone,
                    "address" to profile.address,
                    "photoURL" to profile.photoURL,
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- CAPITAL CONTRIBUTIONS ----------------

    fun observeAllCapitalContributions(): Flow<List<CapitalContribution>> = callbackFlow {
        val query = firestore.collection("capitalContributions")
            .whereEqualTo("organizationId", ORG_ID)
            .orderBy("createdAt", Query.Direction.DESCENDING)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                // If orderBy fails due to missing index, fallback to basic query
                firestore.collection("capitalContributions")
                    .whereEqualTo("organizationId", ORG_ID)
                    .get()
                    .addOnSuccessListener { fallbackSnap ->
                        val list = fallbackSnap.documents.mapNotNull { it.toObject(CapitalContribution::class.java) }
                            .sortedByDescending { it.createdAt }
                        trySend(list)
                    }
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(CapitalContribution::class.java) } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    fun observeMemberCapitalContributions(memberId: String): Flow<List<CapitalContribution>> = callbackFlow {
        val query = firestore.collection("capitalContributions")
            .whereEqualTo("organizationId", ORG_ID)
            .whereEqualTo("memberId", memberId)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(CapitalContribution::class.java) }
                ?.sortedByDescending { it.createdAt } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun addCapitalContribution(contribution: CapitalContribution): Result<String> {
        return try {
            val docRef = firestore.collection("capitalContributions").document()
            val finalItem = contribution.copy(id = docRef.id, organizationId = ORG_ID, createdAt = System.currentTimeMillis())
            docRef.set(finalItem).await()

            // Update member's total capital in user document
            val userRef = firestore.collection("users").document(contribution.memberId)
            val userSnap = userRef.get().await()
            if (userSnap.exists()) {
                val currentTotal = userSnap.getDouble("totalCapitalContributed") ?: 0.0
                val newTotal = currentTotal + contribution.paidAmount
                userRef.update(
                    mapOf(
                        "totalCapitalContributed" to newTotal,
                        "currentCapitalBalance" to newTotal,
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
            }

            // Send notification to member
            sendNotification(
                userId = contribution.memberId,
                title = "মূলধন জমাদান প্রাপ্ত হয়েছে",
                body = "${contribution.monthYear} মাসের জন্য ৳${contribution.paidAmount.toInt()} মূলধন সফলভাবে জমা হয়েছে।",
                type = "capital",
                relatedId = docRef.id
            )

            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- BUSINESS PROJECTS ----------------

    fun observeProjects(): Flow<List<BusinessProject>> = callbackFlow {
        val query = firestore.collection("projects")
            .whereEqualTo("organizationId", ORG_ID)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(BusinessProject::class.java) }
                ?.sortedByDescending { it.createdAt } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun addProject(project: BusinessProject): Result<String> {
        return try {
            val docRef = firestore.collection("projects").document()
            val finalItem = project.copy(id = docRef.id, organizationId = ORG_ID, createdAt = System.currentTimeMillis())
            docRef.set(finalItem).await()

            // Broadcast notification to all members about new project
            broadcastNotification(
                title = "নতুন ব্যবসায়িক প্রকল্প",
                body = "ফাউন্ডেশনের নতুন প্রকল্প '${project.title}' চালু করা হয়েছে।",
                type = "project",
                relatedId = docRef.id
            )

            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateProject(project: BusinessProject): Result<Unit> {
        return try {
            firestore.collection("projects").document(project.id).set(project).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- EXPENSES ----------------

    fun observeExpenses(): Flow<List<OrganizationExpense>> = callbackFlow {
        val query = firestore.collection("expenses")
            .whereEqualTo("organizationId", ORG_ID)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(OrganizationExpense::class.java) }
                ?.sortedByDescending { it.createdAt } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun addExpense(expense: OrganizationExpense): Result<String> {
        return try {
            val docRef = firestore.collection("expenses").document()
            val finalItem = expense.copy(id = docRef.id, organizationId = ORG_ID, createdAt = System.currentTimeMillis())
            docRef.set(finalItem).await()
            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- PROFIT DISTRIBUTIONS ----------------

    fun observeProfitDistributions(): Flow<List<ProfitDistribution>> = callbackFlow {
        val query = firestore.collection("profitDistributions")
            .whereEqualTo("organizationId", ORG_ID)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(ProfitDistribution::class.java) }
                ?.sortedByDescending { it.createdAt } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun addProfitDistribution(distribution: ProfitDistribution): Result<String> {
        return try {
            val docRef = firestore.collection("profitDistributions").document()
            val finalItem = distribution.copy(id = docRef.id, organizationId = ORG_ID, createdAt = System.currentTimeMillis())
            docRef.set(finalItem).await()

            // Notify each receiving member
            distribution.memberShares.forEach { (memberUid, shareAmount) ->
                sendNotification(
                    userId = memberUid,
                    title = "মুনাফা বণ্টন প্রদান করা হয়েছে",
                    body = "${distribution.title} হতে আপনার অ্যাকাউন্টে ৳${shareAmount.toInt()} মুনাফা বরাদ্দ করা হয়েছে।",
                    type = "profit",
                    relatedId = docRef.id
                )
            }

            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- NOTICES & EVENTS ----------------

    fun observeNotices(): Flow<List<NoticeItem>> = callbackFlow {
        val query = firestore.collection("notices")
            .whereEqualTo("organizationId", ORG_ID)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(NoticeItem::class.java) }
                ?.sortedByDescending { it.createdAt } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun addNotice(notice: NoticeItem): Result<String> {
        return try {
            val docRef = firestore.collection("notices").document()
            val finalItem = notice.copy(id = docRef.id, organizationId = ORG_ID, createdAt = System.currentTimeMillis())
            docRef.set(finalItem).await()

            broadcastNotification(
                title = "নতুন ${notice.type}: ${notice.title}",
                body = if (notice.content.length > 80) notice.content.take(80) + "..." else notice.content,
                type = "notice",
                relatedId = docRef.id
            )

            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- INTERNAL MESSAGING (1-to-1) ----------------

    fun observeConversations(currentUserId: String): Flow<List<ConversationItem>> = callbackFlow {
        val query = firestore.collection("conversations")
            .whereArrayContains("participantIds", currentUserId)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(ConversationItem::class.java) }
                ?.sortedByDescending { it.lastTimestamp } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    fun observeMessages(conversationId: String): Flow<List<ChatMessage>> = callbackFlow {
        val query = firestore.collection("conversations")
            .document(conversationId)
            .collection("messages")
            .orderBy("timestamp", Query.Direction.ASCENDING)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(ChatMessage::class.java) } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun sendMessage(
        conversationId: String,
        senderId: String,
        senderName: String,
        receiverId: String,
        receiverName: String,
        text: String,
        imageUrl: String = ""
    ): Result<Unit> {
        return try {
            val convRef = firestore.collection("conversations").document(conversationId)
            val msgRef = convRef.collection("messages").document()

            val chatMsg = ChatMessage(
                id = msgRef.id,
                conversationId = conversationId,
                senderId = senderId,
                senderName = senderName,
                text = text,
                imageUrl = imageUrl,
                timestamp = System.currentTimeMillis(),
                seen = false
            )

            // Update conversation meta and add message in atomic/batch or sequential
            firestore.runBatch { batch ->
                batch.set(msgRef, chatMsg)
                batch.set(
                    convRef,
                    mapOf(
                        "id" to conversationId,
                        "participantIds" to listOf(senderId, receiverId),
                        "participantNames" to mapOf(senderId to senderName, receiverId to receiverName),
                        "lastMessage" to if (text.isNotBlank()) text else "📷 ছবি",
                        "lastTimestamp" to System.currentTimeMillis()
                    ),
                    com.google.firebase.firestore.SetOptions.merge()
                )
            }.await()

            // Send in-app notification to receiver
            sendNotification(
                userId = receiverId,
                title = "$senderName হতে নতুন বার্তা",
                body = if (text.isNotBlank()) text else "ছবি পাঠিয়েছেন",
                type = "message",
                relatedId = conversationId
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // Mark messages in conversation as seen
    suspend fun markMessagesAsSeen(conversationId: String, currentUserId: String) {
        try {
            val query = firestore.collection("conversations")
                .document(conversationId)
                .collection("messages")
                .whereNotEqualTo("senderId", currentUserId)
                .whereEqualTo("seen", false)
                .get().await()

            for (doc in query.documents) {
                doc.reference.update("seen", true)
            }
        } catch (_: Exception) {}
    }

    // Helper: generate consistent 1-to-1 conversation ID
    fun getConversationId(uid1: String, uid2: String): String {
        return if (uid1 < uid2) "${uid1}_${uid2}" else "${uid2}_${uid1}"
    }

    // ---------------- NOTIFICATIONS ----------------

    fun observeNotifications(userId: String): Flow<List<AppNotification>> = callbackFlow {
        val query = firestore.collection("notifications")
            .whereEqualTo("userId", userId)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(AppNotification::class.java) }
                ?.sortedByDescending { it.timestamp } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun sendNotification(
        userId: String,
        title: String,
        body: String,
        type: String,
        relatedId: String
    ) {
        try {
            val doc = firestore.collection("notifications").document()
            val notif = AppNotification(
                id = doc.id,
                userId = userId,
                title = title,
                body = body,
                type = type,
                relatedId = relatedId,
                isRead = false,
                timestamp = System.currentTimeMillis(),
                organizationId = ORG_ID
            )
            doc.set(notif).await()
        } catch (_: Exception) {}
    }

    suspend fun broadcastNotification(
        title: String,
        body: String,
        type: String,
        relatedId: String
    ) {
        try {
            val membersSnap = firestore.collection("users")
                .whereEqualTo("organizationId", ORG_ID)
                .get().await()
            for (doc in membersSnap.documents) {
                val memberUid = doc.id
                sendNotification(memberUid, title, body, type, relatedId)
            }
        } catch (_: Exception) {}
    }

    suspend fun markNotificationAsRead(notifId: String) {
        try {
            firestore.collection("notifications").document(notifId).update("isRead", true).await()
        } catch (_: Exception) {}
    }

    // ---------------- PAYMENT SETTINGS (ADMIN ONLY) ----------------

    fun observePaymentSettings(): Flow<PaymentSettings> = callbackFlow {
        val docRef = firestore.collection("app_settings").document("payment_settings")
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(PaymentSettings())
                return@addSnapshotListener
            }
            if (snapshot != null && snapshot.exists()) {
                val settings = snapshot.toObject(PaymentSettings::class.java) ?: PaymentSettings()
                trySend(settings)
            } else {
                // Return default initial setup: Bkash 01950-515296 active, Nagad blank, Rocket blank
                trySend(PaymentSettings())
            }
        }
        awaitClose { listener.remove() }
    }

    suspend fun updatePaymentSettings(settings: PaymentSettings, adminName: String): Result<Unit> {
        return try {
            val updated = settings.copy(
                updatedAt = System.currentTimeMillis(),
                updatedBy = adminName
            )
            firestore.collection("app_settings").document("payment_settings").set(updated).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- DEPOSIT APPROVAL LEDGER ----------------

    suspend fun submitMemberDeposit(contribution: CapitalContribution): Result<String> {
        return try {
            val docRef = firestore.collection("capitalContributions").document()
            val item = contribution.copy(
                id = docRef.id,
                organizationId = ORG_ID,
                status = "প্রক্রিয়াধীন", // Pending Admin Approval
                createdAt = System.currentTimeMillis()
            )
            docRef.set(item).await()

            // Notify admins
            sendNotification(
                userId = SUPER_ADMIN_UID,
                title = "নতুন জমা অনুমোদনের অপেক্ষায়",
                body = "${item.memberName} (${item.paymentMethod}) ৳${item.paidAmount.toInt()} জমা করেছেন। TrxID: ${item.transactionId}",
                type = "capital",
                relatedId = docRef.id
            )

            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun approveCapitalContribution(
        contributionId: String,
        memberId: String,
        amount: Double,
        adminName: String
    ): Result<Unit> {
        return try {
            val docRef = firestore.collection("capitalContributions").document(contributionId)
            docRef.update(
                mapOf(
                    "status" to "অনুমোদিত",
                    "approvedBy" to adminName,
                    "approvedAt" to System.currentTimeMillis()
                )
            ).await()

            // Update member total capital in user document
            val userRef = firestore.collection("users").document(memberId)
            val userSnap = userRef.get().await()
            if (userSnap.exists()) {
                val currentTotal = userSnap.getDouble("totalCapitalContributed") ?: 0.0
                val newTotal = currentTotal + amount
                userRef.update(
                    mapOf(
                        "totalCapitalContributed" to newTotal,
                        "currentCapitalBalance" to newTotal,
                        "updatedAt" to System.currentTimeMillis()
                    )
                ).await()
            }

            // Send notification to member
            sendNotification(
                userId = memberId,
                title = "মূলধন জমাদান অনুমোদিত হয়েছে",
                body = "আপনার ৳${amount.toInt()} মূলধন জমা অ্যাডমিন কর্তৃক সফলভাবে অনুমোদিত হয়েছে।",
                type = "capital",
                relatedId = contributionId
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun rejectCapitalContribution(
        contributionId: String,
        memberId: String,
        reason: String
    ): Result<Unit> {
        return try {
            val docRef = firestore.collection("capitalContributions").document(contributionId)
            docRef.update(
                mapOf(
                    "status" to "বাতিল",
                    "transactionNote" to "বাতিলের কারণ: $reason"
                )
            ).await()

            sendNotification(
                userId = memberId,
                title = "মূলধন জমাদান বাতিল করা হয়েছে",
                body = "আপনার জমাটি অনুমোদিত হয়নি। কারণ: $reason",
                type = "capital",
                relatedId = contributionId
            )

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- ADVANCED VOTING & DECISION-MAKING SYSTEM ----------------

    fun observeVotingPolls(): Flow<List<VotingPoll>> = callbackFlow {
        val query = firestore.collection("votingPolls")
            .whereEqualTo("organizationId", ORG_ID)
        val listener = query.addSnapshotListener { snapshot, error ->
            if (error != null) {
                trySend(emptyList())
                return@addSnapshotListener
            }
            val list = snapshot?.documents?.mapNotNull { it.toObject(VotingPoll::class.java) }
                ?.sortedByDescending { it.createdAt } ?: emptyList()
            trySend(list)
        }
        awaitClose { listener.remove() }
    }

    suspend fun createVotingPoll(poll: VotingPoll): Result<String> {
        return try {
            val docRef = firestore.collection("votingPolls").document()
            val finalPoll = poll.copy(
                id = docRef.id,
                organizationId = ORG_ID,
                createdAt = System.currentTimeMillis()
            )
            docRef.set(finalPoll).await()

            // Broadcast to all members
            broadcastNotification(
                title = "নতুন ভোট ও সিদ্ধান্ত গ্রহণ: ${finalPoll.title}",
                body = "সম্মানিত সদস্যরা ভোট দিয়ে যৌথ ব্যবসায়ীক সিদ্ধান্ত গ্রহণ করুন। সময়সীমা নির্ধারণ করা হয়েছে।",
                type = "notice",
                relatedId = docRef.id
            )

            Result.success(docRef.id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun castVote(
        pollId: String,
        memberUid: String,
        memberName: String,
        optionId: String
    ): Result<Unit> {
        return try {
            val docRef = firestore.collection("votingPolls").document(pollId)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                throw Exception("ভোট পাওয়া যায়নি")
            }

            val poll = snap.toObject(VotingPoll::class.java) ?: throw Exception("ভোট ডেটা ত্রুটি")

            // Strict Rules:
            // 1. Voting must be active (not closed manually and deadline not expired)
            if (!poll.isVotingActive()) {
                throw Exception("এই ভোটের সময়সীমা সমাপ্ত হয়েছে। আর ভোট দেওয়া যাবে না।")
            }

            // 2. Member can vote only ONCE per active poll. Cannot be changed.
            if (poll.hasVoted(memberUid)) {
                throw Exception("আপনি ইতিমধ্যে ভোট দিয়েছেন। ভোট পরিবর্তন বা প্রত্যাহারযোগ্য নয়।")
            }

            val updatedVotes = poll.votes.toMutableMap()
            updatedVotes[memberUid] = optionId

            val updatedVoterNames = poll.voterNames.toMutableMap()
            updatedVoterNames[memberUid] = memberName

            val updatedOptions = poll.options.map { opt ->
                val count = updatedVotes.values.count { it == opt.id }
                opt.copy(voteCount = count)
            }

            docRef.update(
                mapOf(
                    "votes" to updatedVotes,
                    "voterNames" to updatedVoterNames,
                    "options" to updatedOptions
                )
            ).await()

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun closeVotingPoll(pollId: String): Result<Unit> {
        return try {
            firestore.collection("votingPolls").document(pollId).update("isClosedManually", true).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- FINANCIAL OVERVIEW MANUAL EDIT & SETTINGS ----------------

    fun observeFinancialOverviewSettings(): Flow<FinancialOverview?> = callbackFlow {
        val docRef = firestore.collection("app_settings").document("financial_overview")
        val listener = docRef.addSnapshotListener { snapshot, error ->
            if (error != null || snapshot == null || !snapshot.exists()) {
                trySend(null)
                return@addSnapshotListener
            }
            trySend(snapshot.toObject(FinancialOverview::class.java))
        }
        awaitClose { listener.remove() }
    }

    suspend fun updateFinancialOverviewManual(overview: FinancialOverview, adminName: String): Result<Unit> {
        return try {
            val updated = overview.copy(
                lastUpdatedBy = adminName,
                lastUpdatedAt = System.currentTimeMillis()
            )
            firestore.collection("app_settings").document("financial_overview").set(updated).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
