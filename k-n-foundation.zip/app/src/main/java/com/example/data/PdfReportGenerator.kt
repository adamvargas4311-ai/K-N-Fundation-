package com.example.data

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.model.BusinessProject
import com.example.model.FinancialOverview
import com.example.model.UserProfile
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PdfReportGenerator {

    fun generateAndShareMonthlyReport(
        context: Context,
        overview: FinancialOverview,
        members: List<UserProfile>,
        projects: List<BusinessProject>
    ) {
        try {
            val pdfDoc = PdfDocument()
            val pageWidth = 595
            val pageHeight = 842
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDoc.startPage(pageInfo)
            val canvas: Canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }
            val currencyFormatter = NumberFormat.getNumberInstance(Locale.US)
            val currentDate = SimpleDateFormat("dd MMMM, yyyy", Locale.getDefault()).format(Date())
            val currentMonth = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())

            var y = 45f

            // Top Header Banner
            paint.color = Color.rgb(12, 90, 48) // Islamic Green
            canvas.drawRect(30f, y, (pageWidth - 30).toFloat(), y + 70f, paint)

            paint.color = Color.WHITE
            paint.textSize = 20f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("খতমে নবুয়াত ফাউন্ডেশন", (pageWidth / 2).toFloat(), y + 30f, paint)

            paint.textSize = 11f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            canvas.drawText("যৌথ মূলধনের ব্যবসায়ীক কার্যক্রম - মাসিক আর্থিক প্রতিবেদন", (pageWidth / 2).toFloat(), y + 50f, paint)

            y += 85f

            // Report Meta
            paint.color = Color.rgb(60, 60, 60)
            paint.textSize = 10f
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText("প্রতিবেদন মাস: $currentMonth", 35f, y, paint)
            paint.textAlign = Paint.Align.RIGHT
            canvas.drawText("তৈরির তারিখ: $currentDate", (pageWidth - 35).toFloat(), y, paint)

            y += 18f
            paint.color = Color.rgb(200, 215, 205)
            paint.strokeWidth = 1.5f
            canvas.drawLine(30f, y, (pageWidth - 30).toFloat(), y, paint)
            y += 20f

            // Section 1: Financial Summary
            paint.color = Color.rgb(8, 61, 32)
            paint.textSize = 14f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText("১. সার্বিক আর্থিক সারাংশ (Financial Summary)", 35f, y, paint)
            y += 16f

            paint.textSize = 10f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            paint.color = Color.DKGRAY

            fun drawRow(label: String, value: String, isBold: Boolean = false, valColor: Int = Color.BLACK) {
                paint.color = Color.DKGRAY
                paint.typeface = if (isBold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
                paint.textAlign = Paint.Align.LEFT
                canvas.drawText(label, 45f, y, paint)

                paint.color = valColor
                paint.textAlign = Paint.Align.RIGHT
                canvas.drawText(value, (pageWidth - 45).toFloat(), y, paint)
                y += 15f
            }

            drawRow("মোট সংগৃহীত মূলধন:", "৳ ${currencyFormatter.format(overview.totalCapitalCollected.toInt())}", false, Color.rgb(12, 90, 48))
            drawRow("মোট ব্যবসায়ীক ব্যয়:", "৳ ${currencyFormatter.format(overview.totalExpenses.toInt())}", false, Color.rgb(180, 40, 40))
            drawRow("মোট বণ্টিত মুনাফা:", "৳ ${currencyFormatter.format(overview.totalProfitDistributed.toInt())}", false, Color.rgb(197, 155, 39))
            drawRow("বর্তমান তহবিল ব্যালেন্স:", "৳ ${currencyFormatter.format(overview.currentBalance.toInt())}", true, Color.rgb(12, 90, 48))

            y += 12f

            // Section 2: Current Month's Activities
            paint.color = Color.rgb(232, 245, 233)
            canvas.drawRoundRect(30f, y, (pageWidth - 30).toFloat(), y + 90f, 8f, 8f, paint)

            paint.color = Color.rgb(8, 61, 32)
            paint.textSize = 13f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("২. চলতি মাসের কার্যক্রম ($currentMonth)", 45f, y + 22f, paint)

            y += 40f
            drawRow("১. চলতি মাসের মোট মূলধন জমা:", "৳ ${currencyFormatter.format(overview.monthlyCapitalCollection.toInt())}", true, Color.rgb(12, 90, 48))
            drawRow("২. চলতি মাসের মোট ব্যয়:", "৳ ${currencyFormatter.format(overview.monthlyExpenses.toInt())}", true, Color.rgb(180, 40, 40))
            drawRow("৩. চলতি মাসের মোট মুনাফা:", "৳ ${currencyFormatter.format(overview.currentMonthProfit.toInt())}", true, Color.rgb(197, 155, 39))

            y += 25f

            // Section 3: Member Capital Share Tracker
            paint.color = Color.rgb(8, 61, 32)
            paint.textSize = 13f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            paint.textAlign = Paint.Align.LEFT
            canvas.drawText("৩. সদস্য শেয়ার ও অংশীদারিত্ব বিবরণী (Member Capital Shares)", 35f, y, paint)
            y += 16f

            // Table Header
            paint.color = Color.rgb(240, 244, 242)
            canvas.drawRect(35f, y, (pageWidth - 35).toFloat(), y + 20f, paint)
            paint.color = Color.BLACK
            paint.textSize = 9f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("সদস্যের নাম", 45f, y + 14f, paint)
            canvas.drawText("মোবাইল", 220f, y + 14f, paint)
            canvas.drawText("জমা মূলধন", 350f, y + 14f, paint)
            canvas.drawText("শেয়ার (%)", 480f, y + 14f, paint)
            y += 24f

            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            val totalCap = if (overview.totalCapitalCollected > 0) overview.totalCapitalCollected else 1.0
            val sortedMembers = members.sortedByDescending { it.totalCapitalContributed }

            var rowCount = 0
            for (m in sortedMembers) {
                if (rowCount >= 12) break // fit neatly on single standard page
                val sharePercent = (m.totalCapitalContributed / totalCap) * 100

                paint.color = if (rowCount % 2 == 0) Color.rgb(252, 253, 253) else Color.WHITE
                canvas.drawRect(35f, y - 4f, (pageWidth - 35).toFloat(), y + 14f, paint)

                paint.color = Color.DKGRAY
                canvas.drawText(m.name.ifBlank { "সদস্য" }.take(22), 45f, y + 10f, paint)
                canvas.drawText(m.phone.ifBlank { "N/A" }, 220f, y + 10f, paint)
                canvas.drawText("৳ ${currencyFormatter.format(m.totalCapitalContributed.toInt())}", 350f, y + 10f, paint)
                canvas.drawText(String.format(Locale.US, "%.1f%%", sharePercent), 480f, y + 10f, paint)
                y += 16f
                rowCount++
            }

            y += 15f

            // Section 4: Projects Snapshot
            paint.color = Color.rgb(8, 61, 32)
            paint.textSize = 12f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("৪. চলমান ব্যবসা প্রকল্পসমূহ (${projects.size} টি)", 35f, y, paint)
            y += 15f

            paint.textSize = 9f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            for (p in projects.take(4)) {
                paint.color = Color.DKGRAY
                canvas.drawText("• ${p.title} | বিনিয়োগ: ৳${currencyFormatter.format(p.totalInvestment.toInt())} | অবস্থা: ${p.status}", 45f, y, paint)
                y += 13f
            }

            // Footer
            paint.color = Color.rgb(180, 190, 185)
            canvas.drawLine(35f, (pageHeight - 40).toFloat(), (pageWidth - 35).toFloat(), (pageHeight - 40).toFloat(), paint)

            paint.textSize = 8.5f
            paint.color = Color.GRAY
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("খতমে নবুয়াত ফাউন্ডেশন | শরীয়াহসম্মত ব্যবসায়ীক কার্যক্রম পরিচালনা উদ্দেশ্যে গঠিত সংগঠন", (pageWidth / 2).toFloat(), (pageHeight - 25).toFloat(), paint)

            pdfDoc.finishPage(page)

            // Save PDF to cache dir
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()
            val pdfFile = File(reportsDir, "KN_Foundation_Report_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(pdfFile)
            pdfDoc.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            pdfDoc.close()

            // Open / Share PDF via Intent
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "খতমে নবুয়াত ফাউন্ডেশন - মাসিক আর্থিক প্রতিবেদন")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(shareIntent, "প্রতিবেদন PDF শেয়ার বা প্রিন্ট করুন").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(chooser)
            Toast.makeText(context, "মাসিক আর্থিক প্রতিবেদন PDF সফলভাবে তৈরি হয়েছে", Toast.LENGTH_SHORT).show()

        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(context, "PDF তৈরিতে ত্রুটি: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
